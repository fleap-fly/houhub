# Agent Hub TypeScript SDK

`@houshan/agent-hub-sdk` is the TypeScript framework contract package for Agent
Hub core. It exports canonical Agent Hub types, session event helpers and
harness/coordinator contracts.

It does not export an HTTP client, a control service, UI code, persistence
adapters, billing logic, product workflows or host-specific integration code.
Control planes implement the Agent Hub contracts directly; they do not use this
package to call themselves.

```bash
npm install @houshan/agent-hub-sdk
```

```ts
import {
  PRIMARY_SESSION_THREAD_ID,
  comparePendingEvents,
  type SessionEvent,
  type SessionPendingEvent,
} from "@houshan/agent-hub-sdk";

const event: SessionEvent = {
  id: "evt_1",
  type: "user.message",
  session_thread_id: PRIMARY_SESSION_THREAD_ID,
  content: [{ type: "text", text: "hello" }],
  processed_at: null,
  created_at: new Date().toISOString(),
};

const pending: SessionPendingEvent = {
  id: "pend_1",
  type: "session_pending_event",
  session_id: "ses_1",
  event_id: event.id,
  pending_seq: 1,
  enqueued_at: Date.now(),
  event,
  session_thread_id: PRIMARY_SESSION_THREAD_ID,
  status: "queued",
  promoted_run_id: null,
  promoted_at: null,
  cancelled_at: null,
  created_at: event.created_at,
  updated_at: event.created_at,
};

console.log([... [pending]].sort(comparePendingEvents));
```

Use `@houshan/agent-hub-network-sdk`, a product BFF, service API client or
generated OpenAPI client outside this package when an application needs HTTP
transport.
