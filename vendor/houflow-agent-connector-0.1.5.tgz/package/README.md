# Houflow Agent Connector

Standalone connector package for external connected agents. It runs on a user-owned host, claims an Agent Hub connector enrollment, reports local agent availability, keeps the connector online through heartbeat, and polls Agent Hub for outbound commands.

Users who need a desktop GUI can install the Electron launcher from `services/agent-connector-launcher`. The launcher uses this package as its connector core and keeps Agent Hub Web as the control-plane SoT.

The connector talks only to Agent Hub public connector APIs:

- `GET /v1/connected-agent-connectors/releases/current`
- `GET /v1/connected-agent-connectors/packages/{artifactName}`
- `POST /v1/connected-agent-connectors/login/start`
- `POST /v1/connected-agent-connectors/login/poll`
- `POST /v1/connected-agent-connectors/claim`
- `POST /v1/connected-agent-connectors/{connectorId}/heartbeat`
- `POST /v1/connected-agent-connectors/{connectorId}/token/rotate`
- `POST /v1/connected-agent-connectors/{connectorId}/revoke`
- `POST /v1/connected-agent-connectors/{connectorId}/commands/poll`
- `POST /v1/connected-agent-connectors/{connectorId}/commands/{commandId}/events`

It does not import Agent Hub control-service internals and it does not make the browser call the user's `localhost` or LAN.

## Install

```sh
npm install -g @houflow/agent-connector@0.1.5
```

The primary connection path starts on the user's own computer. It opens Agent Hub in the browser, asks the signed-in user to approve this host, then stores only a dedicated connector token locally:

```sh
hou-agent-connector login \
  --control-url https://agent.houflow.com \
  --console-url https://agent.houflow.com \
  --name "Local development machine"

hou-agent-connector up
hou-agent-connector status
```

Use `--no-open` on headless hosts and copy the printed URL into a browser:

```sh
hou-agent-connector login --control-url https://agent.houflow.com --console-url https://agent.houflow.com --no-open
```

Scripted enrollment commands remain available for automation and CI-like hosts:

```sh
hou-agent-connector enroll \
  --control-url https://agent.example.com \
  --token hce_... \
  --install-target-id macos-arm64-0.1.5 \
  --platform macos \
  --package-ref https://agent.example.com/v1/connected-agent-connectors/packages/houflow-agent-connector-0.1.5.tgz \
  --connector-version 0.1.5

hou-agent-connector up
```

Interactive terminals print ordered setup steps. Automation can force JSON:

```sh
hou-agent-connector status --json
hou-agent-connector diagnose --json
hou-agent-connector version --json
```

Online update uses the Agent Hub release manifest and verifies the signed connector package before `npm install -g`:

```sh
hou-agent-connector update check
hou-agent-connector update
hou-agent-connector upgrade
```

## Local Agents

Configured local agents are reported to Agent Hub and can later be bound to external connected-agent records.

```sh
hou-agent-connector local-agent add \
  --ref pi:local-support \
  --provider pi \
  --name "Local Pi" \
  --runtime-provider pi \
  --runtime-runner \
  --skills-dir "$HOME/.houflow/agent-skills/pi"

hou-agent-connector local-agent reported
```

The connector also reports supported local runtimes found on `PATH`, plus API-only profiles that have saved runtime env. Built-in runner entries claim dispatch, workspace-message, and lifecycle capability without a custom shell command.

Built-in connector runners currently cover:

- CLI runners: `pi`, `codex`, `claude`, `gemini`, `cursor`, `opencode`, `openclaw`, `hermes`
- Direct API runners: `kimi`, `nanoclaw`

Discovery-only entries such as `cline`, `copilot`, `aider`, `amp`, `goose`, and `swebench` do not claim command capability until explicitly configured with a non-interactive local command.

Runtime install/uninstall can use the connector-managed provider registry when the local agent is configured with `--runtime-provider <ref>`:

```sh
hou-agent-connector runtime list
hou-agent-connector search codex
hou-agent-connector runtime ready codex
hou-agent-connector runtime env codex --set OPENAI_API_KEY=<key> --set OPENAI_BASE_URL=https://api.openai.com/v1
hou-agent-connector runtime install pi --version 0.78.1
hou-agent-connector runtime install codex --version 1.2.3
hou-agent-connector runtime uninstall codex
```

API-only runners do not install a local binary. Configure their env and verify readiness:

```sh
hou-agent-connector runtime env kimi --set KIMI_API_KEY=<key> --set KIMI_BASE_URL=https://api.moonshot.ai/v1 --set KIMI_MODEL=kimi-k2.6
hou-agent-connector runtime env nanoclaw --set OPENAI_API_KEY=<key> --set OPENAI_BASE_URL=https://api.openai.com/v1 --set NANOCLAW_MODEL=<model>
hou-agent-connector runtime ready kimi
hou-agent-connector runtime ready nanoclaw
```

Short aliases are supported for common local-agent and runtime operations:

```sh
hou-agent-connector create "Local Codex" --type codex --ref codex:local --runtime-provider codex --runtime-runner
hou-agent-connector list
hou-agent-connector remove codex:local
hou-agent-connector search codex
hou-agent-connector runtimes
hou-agent-connector install codex --version 1.2.3
hou-agent-connector uninstall codex
hou-agent-connector autostart --disable
```

These aliases stay inside the Agent Hub connector boundary. Agent Hub workspaces remain Hub control-plane resources, and external connector binding happens through Agent Hub connected-agent identities.

`runtime install <ref> --version <version>` is an idempotent ensure/update operation: it checks provider prerequisites, checks the runtime binary on `PATH`, skips npm when that exact version is already present, otherwise installs the requested package version, then verifies the runtime reports that version. `runtime uninstall <ref>` runs the package manager uninstall and verifies the binary is no longer present on `PATH`.

Pi Coding Agent follows its npm package engine requirement and requires Node.js `>=22.19.0` on `PATH`.

The bundled runtime registry is local to this connector package. Agent Hub does not maintain the user's machine-level runtime registry.

When Agent Hub queues work for a bound external connected agent, the connector receives it through the outbound poll channel and runs the configured local command or connector-managed runner for the requested action: `dispatch`, `workspace_message`, `runtime_install`, `runtime_uninstall`, `skill_install`, `skill_uninstall`, `agent_status`, `agent_stop`, or `agent_restart`.

`--runtime-provider <ref>` enables connector-managed runtime install/uninstall for that provider. `--runtime-runner` is a separate explicit switch. It enables dispatch, workspace-message, and lifecycle commands only for providers whose bundled registry declares a runner. Built-in runners store session ids under the connector state directory and reuse them for follow-up work where the underlying CLI supports resume. Providers without a declared runner must use explicit local commands and fail closed if `--runtime-runner` is requested.

Runner behavior is provider-specific but uses the same Hub command path:

- `codex`: `codex exec --json`, session resume, and OpenAI-compatible direct API fallback when `OPENAI_API_KEY + OPENAI_BASE_URL` are configured for a non-OpenAI endpoint.
- `claude`, `gemini`, and `cursor`: stream-json CLI mode with session resume.
- `opencode`, `openclaw`, and `hermes`: provider-native non-interactive CLI modes with parsed response output and session tracking.
- `kimi` and `nanoclaw`: OpenAI-compatible `/chat/completions` streaming direct API mode.

`dispatch` receives the message on stdin. Other custom command actions receive the command input JSON on stdin. Every custom command receives these environment variables:

```text
HOUFLOW_AGENT_CONNECTOR_ACTION
HOUFLOW_AGENT_CONNECTOR_COMMAND_ID
HOUFLOW_CONNECTED_AGENT_ID
HOUFLOW_LOCAL_AGENT_REF
HOUFLOW_AGENT_CONNECTOR_INPUT
```

stdout lines are reported back to Agent Hub as step events. Completion is reported as succeeded or failed.

The local host keeps a bounded command ledger for terminal inspection. It mirrors commands the connector actually received and events the Hub accepted; Agent Hub remains the command SoT.

```sh
hou-agent-connector commands list
hou-agent-connector commands show ccc_...
hou-agent-connector commands watch ccc_...
```

Skill install/uninstall can use the connector-managed skills directory when the local agent is configured with `--skills-dir <dir>`. `skill_install` requires a skill id plus `source_repo` (`owner/repo`) and optional `source_path` / `version`; the connector fetches the source with `git sparse-checkout` and verifies that `SKILL.md` exists before reporting success.

For custom implementations, use `--runtime-install-command`, `--runtime-uninstall-command`, `--skill-install-command`, or `--skill-uninstall-command` instead of `--runtime-provider` / `--skills-dir`. A local agent should not configure both managed and custom execution paths for the same action.

## Daemon

```sh
hou-agent-connector up
hou-agent-connector status
hou-agent-connector watch
hou-agent-connector diagnose
hou-agent-connector logs --lines 100
hou-agent-connector down
```

`up` starts a background daemon. `up --foreground` is used by service managers and by the daemon itself.

`watch` refreshes local connector status in the terminal. `diagnose` checks enrollment, daemon, heartbeat freshness, local agent inventory, dispatch readiness, and autostart state.

Connector events are stored locally:

```sh
hou-agent-connector notifications list
hou-agent-connector notifications test
hou-agent-connector notifications clear
```

Desktop notifications are explicit and local only:

```sh
hou-agent-connector notifications test --desktop
hou-agent-connector watch --desktop-notify
```

The connector does not send desktop notification state back to Agent Hub and does not create a browser-to-localhost control path.

Autostart is explicit:

```sh
hou-agent-connector autostart enable
hou-agent-connector autostart status
hou-agent-connector autostart disable
```

## Uninstall

```sh
hou-agent-connector down
hou-agent-connector autostart disable
hou-agent-connector connector revoke --reason "local uninstall"
npm uninstall -g @houflow/agent-connector
rm -rf "$HOME/.houflow/agent-connector"
```

On Windows PowerShell, remove local state with:

```powershell
Remove-Item -Recurse -Force "$env:USERPROFILE\.houflow\agent-connector" -ErrorAction SilentlyContinue
```

## State

Default state lives at:

```text
~/.houflow/agent-connector
```

Override with:

```sh
HOUFLOW_AGENT_CONNECTOR_HOME=/path/to/state hou-agent-connector status
```
