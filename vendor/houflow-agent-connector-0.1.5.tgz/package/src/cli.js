const { AgentHubClient } = require("./agent-hub-client.js");
const { ConnectorStore, defaultConfigDir, redactedState } = require("./config.js");
const { claimEnrollment, heartbeatOnce } = require("./heartbeat.js");
const { addLocalAgent, discoverCliAgents, removeLocalAgent, reportedLocalAgents } = require("./local-agents.js");
const { runForegroundDaemon, startDaemon, stopDaemon } = require("./daemon.js");
const { autostartStatus, disableAutostart, enableAutostart } = require("./autostart.js");
const { createReporter, clearScreen, formatAge } = require("./output.js");
const { appendNotification, clearNotifications, listNotifications, sendDesktopNotification } = require("./notifications.js");
const { connectorSnapshot, diagnoseConnector } = require("./status.js");
const { installRuntimeProvider, listRuntimeProviders, runtimeEnvForState, runtimeProviderReadiness, runtimeProviderStatus, setRuntimeEnv, uninstallRuntimeProvider } = require("./runtime-registry.js");
const { addWorkspace, bindLocalAgentWorkspace, listWorkspaces, removeWorkspace, unbindLocalAgentWorkspace } = require("./workspaces.js");
const { getCommandLedgerEntry, listCommandLedger } = require("./command-ledger.js");
const { loginConnector } = require("./login.js");
const { checkConnectorUpdate, updateConnector } = require("./update.js");

const packageInfo = require("../package.json");

async function runCli(argv, io = defaultIo()) {
  const { command, positional, flags } = parseArgs(argv);
  const store = new ConnectorStore(flags.config ? String(flags.config) : defaultConfigDir(io.env));
  const reporter = createReporter(io, flags);
  const cmd = command || "status";
  if (cmd === "help" || flags.help) return writeHelp(io.stdout);
  if (cmd === "version" || (!command && flags.version)) return cmdVersion(io, reporter);

  if (cmd === "enroll") return cmdEnroll(store, flags, io, reporter);
  if (cmd === "login" || cmd === "connect") return cmdLogin(store, flags, io, reporter);
  if (cmd === "heartbeat") return cmdHeartbeat(store, reporter);
  if (cmd === "up") return cmdUp(store, argv[1], flags, reporter);
  if (cmd === "down") return cmdDown(store, reporter);
  if (cmd === "status") return flags.watch ? cmdWatch(store, flags, io) : cmdStatus(store, io, reporter);
  if (cmd === "watch") return cmdWatch(store, flags, io);
  if (cmd === "logs") return cmdLogs(store, flags, io, reporter);
  if (cmd === "diagnose") return cmdDiagnose(store, io, reporter);
  if (cmd === "commands") return cmdCommands(store, positional, flags, io, reporter);
  if (cmd === "connector") return runConnectorCommand(store, positional, flags, io, reporter);
  if (cmd === "notifications") return cmdNotifications(store, positional, flags, io, reporter);
  if (cmd === "workspace" || cmd === "workspaces") return runWorkspaceCommand(store, positional, flags, io, reporter);
  if (cmd === "local-agent") return runLocalAgentCommand(store, positional, flags, io, reporter);
  if (cmd === "runtime") return runRuntimeCommand(store, positional, flags, io, reporter);
  if (cmd === "update" || cmd === "upgrade") return runUpdateCommand(store, positional, flags, io, reporter);
  if (cmd === "create") return cmdCreateAlias(store, positional, flags, io, reporter);
  if (cmd === "remove") return runLocalAgentCommand(store, ["remove", positional[0] || flags.ref], flags, io, reporter);
  if (cmd === "search") return runRuntimeCommand(store, ["search", ...positional], flags, io, reporter);
  if (cmd === "install") return runRuntimeCommand(store, ["install", ...positional], flags, io, reporter);
  if (cmd === "uninstall") return runRuntimeCommand(store, ["uninstall", ...positional], flags, io, reporter);
  if (cmd === "runtimes") return runRuntimeCommand(store, ["status"], flags, io, reporter);
  if (cmd === "list") return runLocalAgentCommand(store, ["list"], flags, io, reporter);
  if (cmd === "autostart") return runAutostartCommand(store, flags.disable === true ? "disable" : positional[0] || "status", argv[1], reporter);

  throw new Error(`unknown command: ${cmd}`);
}

async function cmdCreateAlias(store, positional, flags, io, reporter) {
  const name = positional[0] || optionalArg(flags, "name");
  if (!name) throw new Error("create requires a local agent name");
  const provider = optionalArg(flags, "type") || optionalArg(flags, "provider") || "openclaw";
  const runtimeProvider = optionalArg(flags, "runtime-provider") || (runtimeProviderExists(provider) ? provider : "");
  if (flags.install === true) {
    if (!runtimeProvider) throw new Error("create --install requires a connector-managed runtime provider; pass --runtime-provider <ref>");
    reporter.step(1, 2, "Install runtime", runtimeProvider);
    const result = await installRuntimeProvider({
      runtime_ref: runtimeProvider,
      version: optionalArg(flags, "version"),
      package_ref: optionalArg(flags, "package-ref"),
      working_directory: optionalArg(flags, "cwd"),
    }, io.env, (line) => reporter.line(line));
    if (result.exit_code !== 0) throw new Error(`runtime install failed for ${runtimeProvider}`);
    reporter.step(2, 2, "Runtime installed", runtimeProvider);
  }
  const localAgentRef = optionalArg(flags, "ref") || `${provider}:${slugValue(name)}`;
  const state = store.updateState((current) => addLocalAgent(current, {
    localAgentRef,
    provider,
    name,
    dispatchCommand: optionalArg(flags, "dispatch-command"),
    workspaceMessageCommand: optionalArg(flags, "workspace-message-command"),
    lifecycleCommand: optionalArg(flags, "lifecycle-command"),
    runtimeInstallCommand: optionalArg(flags, "runtime-install-command"),
    runtimeUninstallCommand: optionalArg(flags, "runtime-uninstall-command"),
    skillInstallCommand: optionalArg(flags, "skill-install-command"),
    skillUninstallCommand: optionalArg(flags, "skill-uninstall-command"),
    runtimeProvider,
    runtimeRunner: flags["runtime-runner"] === true,
    workingDirectory: optionalArg(flags, "cwd"),
    skillsDirectory: optionalArg(flags, "skills-dir"),
    capabilities: optionalArg(flags, "capabilities"),
  }));
  reporter.line(`Local agent ${localAgentRef} saved.`);
  reporter.write({ data: state.local_agents });
  return state.local_agents;
}

async function cmdEnroll(store, flags, io, reporter) {
  reporter.step(1, 4, "Validate enrollment command");
  const params = {
    controlUrl: requiredArg(flags, "control-url", io.env.HOUFLOW_AGENT_HUB_URL),
    token: requiredArg(flags, "token", io.env.HOUFLOW_AGENT_CONNECTOR_ENROLLMENT_TOKEN),
    installTargetId: requiredArg(flags, "install-target-id", io.env.HOUFLOW_AGENT_CONNECTOR_INSTALL_TARGET_ID),
    platform: requiredArg(flags, "platform", io.env.HOUFLOW_AGENT_CONNECTOR_PLATFORM),
    packageRef: requiredArg(flags, "package-ref", io.env.HOUFLOW_AGENT_CONNECTOR_PACKAGE_REF),
    packageSha256: requiredArg(flags, "package-sha256", io.env.HOUFLOW_AGENT_CONNECTOR_PACKAGE_SHA256),
    packageSignatureRef: requiredArg(flags, "package-signature-ref", io.env.HOUFLOW_AGENT_CONNECTOR_PACKAGE_SIGNATURE_REF),
    packageSignatureSha256: requiredArg(flags, "package-signature-sha256", io.env.HOUFLOW_AGENT_CONNECTOR_PACKAGE_SIGNATURE_SHA256),
    packageSignatureAlgorithm: requiredArg(flags, "package-signature-algorithm", io.env.HOUFLOW_AGENT_CONNECTOR_PACKAGE_SIGNATURE_ALGORITHM),
    connectorVersion: requiredArg(flags, "connector-version", io.env.HOUFLOW_AGENT_CONNECTOR_VERSION),
    name: optionalArg(flags, "name", io.env.HOUFLOW_AGENT_CONNECTOR_NAME),
  };
  reporter.step(2, 4, "Claim connector enrollment", params.installTargetId);
  const result = await claimEnrollment(store, params);
  reporter.step(3, 4, "Verify connector heartbeat", result.connector.id);
  const heartbeat = await heartbeatOnce(store);
  reporter.step(4, 4, "Connector ready", "Run hou-agent-connector status or hou-agent-connector watch");
  reporter.write({
    connector: redactedState(result.state).connector,
    heartbeat: { connector_id: heartbeat.id, status: heartbeat.status },
  });
  return result;
}

async function cmdLogin(store, flags, io, reporter) {
  const controlUrl = optionalArg(flags, "control-url", io.env.HOUFLOW_AGENT_HUB_URL) || "https://agent.houflow.com";
  reporter.step(1, 4, "Start browser login", controlUrl);
  const result = await loginConnector(store, {
    controlUrl,
    consoleUrl: optionalArg(flags, "console-url", io.env.HOUFLOW_AGENT_HUB_CONSOLE_URL),
    name: optionalArg(flags, "name", io.env.HOUFLOW_AGENT_CONNECTOR_NAME),
    platform: optionalArg(flags, "platform", io.env.HOUFLOW_AGENT_CONNECTOR_PLATFORM),
    arch: optionalArg(flags, "arch", io.env.HOUFLOW_AGENT_CONNECTOR_ARCH),
    installTargetId: optionalArg(flags, "install-target-id", io.env.HOUFLOW_AGENT_CONNECTOR_INSTALL_TARGET_ID),
    connectorVersion: optionalArg(flags, "connector-version", packageInfo.version),
    timeoutSeconds: positiveIntegerArg(flags.timeout || flags["timeout-seconds"], 300, "timeout"),
    intervalSeconds: flags.interval ? positiveIntegerArg(flags.interval, 2, "interval") : undefined,
    openBrowser: flags.open === false || flags["no-open"] === true ? false : true,
  }, {
    onStarted(login) {
      reporter.step(2, 4, "Authorize in browser", login.user_code || "");
      reporter.line(`Open: ${login.verification_uri_complete}`);
      if (login.user_code) reporter.line(`Code: ${login.user_code}`);
    },
    onBrowserOpened(opened) {
      if (!opened) reporter.line("Browser was not opened automatically; use the URL above.");
    },
    onPoll(response) {
      if (response.status === "pending") reporter.step(3, 4, "Waiting for approval");
      else reporter.line(`Login status: ${response.status}`);
    },
  });
  const heartbeat = await heartbeatOnce(store);
  reporter.step(4, 4, "Connector ready", "Run hou-agent-connector status or hou-agent-connector watch");
  reporter.write({
    login: redactedLogin(result.login),
    connector: redactedState(result.connector.state).connector,
    heartbeat: { connector_id: heartbeat.id, status: heartbeat.status },
  });
  return result;
}

async function runUpdateCommand(store, positional, flags, io, reporter) {
  const subcommand = positional[0] || (flags.check === true ? "check" : "install");
  const controlUrl = optionalArg(flags, "control-url", io.env.HOUFLOW_AGENT_HUB_URL);
  if (subcommand === "check" || subcommand === "status") {
    const result = await checkConnectorUpdate({ controlUrl, store }, io.env);
    reporter.write(result);
    if (!reporter.json) {
      reporter.line(`Current: ${result.current_version}`);
      reporter.line(`Latest: ${result.latest_version || "unknown"}`);
      reporter.line(result.update_available ? "Update available." : "Connector is up to date.");
    }
    return result;
  }
  if (subcommand === "install" || subcommand === "apply" || subcommand === "self") {
    reporter.step(1, 3, "Check connector release");
    const result = await updateConnector({ controlUrl, store, force: flags.force === true }, io.env, (line) => reporter.line(line));
    reporter.step(2, 3, result.changed ? "Install connector update" : "No update needed", result.latest_version || "");
    reporter.step(3, 3, "Update check complete", result.changed ? "Restart daemon if it was running" : "Already current");
    reporter.write(result);
    return result;
  }
  throw new Error(`unknown update command: ${subcommand}`);
}

async function runConnectorCommand(store, positional, flags, _io, reporter) {
  const subcommand = positional[0] || "status";
  if (subcommand === "rotate-token") {
    const state = store.loadState();
    if (!state.connector) throw new Error("connector is not enrolled");
    const client = new AgentHubClient(state.connector.control_url);
    const rotated = await client.rotateToken(state.connector.id, state.connector.token);
    if (!rotated.connector_token) throw new Error("Agent Hub token rotation response did not include connector_token");
    const next = store.updateState((current) => ({
      ...current,
      connector: current.connector ? {
        ...current.connector,
        token: rotated.connector_token,
        token_prefix: rotated.token_prefix || rotated.connector_token.slice(0, 12),
      } : null,
    }));
    reporter.line("Connector token rotated.");
    reporter.write({ connector: redactedState(next).connector });
    return next.connector;
  }
  if (subcommand === "revoke") {
    const state = store.loadState();
    if (!state.connector) throw new Error("connector is not enrolled");
    const client = new AgentHubClient(state.connector.control_url);
    const revoked = await client.revoke(state.connector.id, state.connector.token, { reason: optionalArg(flags, "reason") });
    const next = store.updateState((current) => ({ ...current, connector: null }));
    store.saveStatus({
      status: "revoked",
      connector_id: revoked.id || state.connector.id,
      reported_agent_count: 0,
      last_heartbeat_at: null,
      last_error: null,
      updated_at: new Date().toISOString(),
    });
    reporter.line("Connector revoked and local token removed.");
    reporter.write({ connector: redactedState(next).connector, revoked });
    return revoked;
  }
  throw new Error(`unknown connector command: ${subcommand}`);
}

function cmdVersion(io, reporter) {
  const result = { name: packageInfo.name, version: packageInfo.version };
  reporter.write(result);
  if (!reporter.json) io.stdout.write(`${result.name} v${result.version}\n`);
  return result;
}

async function cmdHeartbeat(store, reporter) {
  reporter.step(1, 2, "Load enrolled connector");
  reporter.step(2, 2, "Send heartbeat to Agent Hub");
  const connector = await heartbeatOnce(store);
  reporter.line(`Heartbeat accepted for connector ${connector.id}.`);
  reporter.write({ ok: true, connector_id: connector.id, status: connector.status });
  return connector;
}

async function cmdUp(store, cliPath, flags, reporter) {
  if (flags.foreground) {
    await runForegroundDaemon(store);
    return null;
  }
  if (!store.loadState().connector) throw new Error("connector is not enrolled; run hou-agent-connector enroll first");
  reporter.step(1, 3, "Check connector daemon");
  const result = startDaemon(store, cliPath, flags.config ? ["--config", String(flags.config)] : []);
  reporter.step(2, 3, result.started ? "Start background daemon" : "Daemon already running", `PID ${result.pid}`);
  reporter.step(3, 3, "Logs available", store.logFile);
  reporter.write(result);
  return result;
}

function cmdDown(store, reporter) {
  reporter.step(1, 2, "Read daemon PID");
  const result = stopDaemon(store);
  reporter.step(2, 2, result.stopped ? "Stop signal sent" : "Daemon is not running", result.pid ? `PID ${result.pid}` : "");
  reporter.write(result);
  return result;
}

function cmdStatus(store, io, reporter) {
  const snapshot = connectorSnapshot(store, io.env);
  reporter.write(snapshot);
  if (!reporter.json) renderStatus(snapshot, io.stdout);
  return snapshot;
}

async function cmdWatch(store, flags, io) {
  const intervalMs = positiveIntegerArg(flags.interval, 2000, "interval");
  let stopped = false;
  let previousKey = "";
  const stop = () => {
    stopped = true;
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  while (!stopped) {
    const snapshot = connectorSnapshot(store, io.env);
    const key = `${snapshot.running}:${snapshot.status?.status || "unknown"}:${snapshot.status?.last_error || ""}`;
    if (io.stdout.isTTY === true && flags["no-clear"] !== true) clearScreen(io.stdout);
    renderStatus(snapshot, io.stdout);
    io.stdout.write(`\nRefreshing every ${intervalMs}ms. Press Ctrl-C to stop.\n`);
    if (flags["desktop-notify"] === true && previousKey && previousKey !== key) {
      sendDesktopNotification({
        title: "Houflow Agent Connector status changed",
        message: `${snapshot.running ? "running" : "stopped"} / ${snapshot.status?.status || "unknown"}`,
      }, io.env);
    }
    previousKey = key;
    if (flags.once) break;
    await sleep(intervalMs);
  }
  return null;
}

async function cmdLogs(store, flags, io, reporter) {
  if (flags.follow === true && reporter.json) throw new Error("logs --follow requires human output");
  const lines = positiveIntegerArg(flags.lines || flags.n || 80, 80, "lines");
  const records = store.tailLog(lines);
  reporter.write({ data: records, log_file: store.logFile });
  if (!reporter.json) renderLogs(records, io.stdout);
  if (flags.follow === true) await followLogs(store, io);
  return records;
}

function cmdDiagnose(store, io, reporter) {
  const diagnosis = diagnoseConnector(store, io.env);
  reporter.write(diagnosis);
  if (!reporter.json) {
    io.stdout.write("Connector diagnostics\n\n");
    reporter.table(["CHECK", "STATUS", "MESSAGE"], diagnosis.checks.map((check) => [
      check.name,
      check.status.toUpperCase(),
      check.message,
    ]));
    const remediation = diagnosis.checks.filter((check) => check.remediation);
    if (remediation.length > 0) {
      io.stdout.write("\nNext steps\n");
      for (const check of remediation) io.stdout.write(`- ${check.name}: ${check.remediation}\n`);
    }
  }
  return diagnosis;
}

async function cmdCommands(store, positional, flags, io, reporter) {
  const subcommand = positional[0] || "list";
  if (subcommand === "list") {
    const data = listCommandLedger(store, positiveIntegerArg(flags.limit || flags.n || 20, 20, "limit"));
    reporter.write({ data, ledger_file: store.commandLedgerFile });
    if (!reporter.json) renderCommandList(data, io.stdout);
    return data;
  }
  if (subcommand === "show") {
    const commandId = positional[1] || flags.id;
    const entry = getCommandLedgerEntry(store, commandId);
    reporter.write(entry);
    if (!reporter.json) renderCommandDetail(entry, io.stdout);
    return entry;
  }
  if (subcommand === "watch") {
    if (reporter.json) throw new Error("commands watch requires human output");
    await cmdCommandWatch(store, positional[1] || flags.id, flags, io);
    return null;
  }
  throw new Error(`unknown commands command: ${subcommand}`);
}

async function cmdCommandWatch(store, commandId, flags, io) {
  const intervalMs = positiveIntegerArg(flags.interval, 1000, "interval");
  let stopped = false;
  const stop = () => {
    stopped = true;
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  while (!stopped) {
    if (io.stdout.isTTY === true && flags["no-clear"] !== true) clearScreen(io.stdout);
    if (commandId) renderCommandDetail(getCommandLedgerEntry(store, commandId), io.stdout);
    else renderCommandList(listCommandLedger(store, positiveIntegerArg(flags.limit || flags.n || 20, 20, "limit")), io.stdout);
    io.stdout.write(`\nRefreshing every ${intervalMs}ms. Press Ctrl-C to stop.\n`);
    if (flags.once) break;
    await sleep(intervalMs);
  }
}

function cmdNotifications(store, positional, flags, io, reporter) {
  const subcommand = positional[0] || "list";
  if (subcommand === "list") {
    const data = listNotifications(store, positiveIntegerArg(flags.limit || flags.n || 20, 20, "limit"));
    reporter.write({ data });
    if (!reporter.json) renderNotifications(data, io.stdout);
    return data;
  }
  if (subcommand === "clear") {
    const result = clearNotifications(store);
    reporter.line("Connector notifications cleared.");
    reporter.write(result);
    return result;
  }
  if (subcommand === "test") {
    const notification = appendNotification(store, {
      type: "test",
      level: "info",
      title: optionalArg(flags, "title") || "Houflow Agent Connector",
      message: optionalArg(flags, "message") || "Local connector notification test.",
    });
    const desktop = flags.desktop ? sendDesktopNotification(notification, io.env) : null;
    reporter.line(desktop ? `Desktop notification sent through ${desktop.provider}.` : "Test notification recorded.");
    reporter.write({ notification, desktop });
    return { notification, desktop };
  }
  throw new Error(`unknown notifications command: ${subcommand}`);
}

function runWorkspaceCommand(store, positional, flags, io, reporter) {
  const subcommand = positional[0] || "list";
  if (subcommand === "list") {
    const data = listWorkspaces(redactedState(store.loadState()));
    reporter.write({ data });
    if (!reporter.json) renderWorkspaces(data, io.stdout);
    return data;
  }
  if (subcommand === "add" || subcommand === "connect") {
    const state = store.updateState((current) => addWorkspace(current, {
      workspaceRef: requiredArg(flags, "ref"),
      name: requiredArg(flags, "name"),
      url: requiredArg(flags, "url"),
      token: requiredArg(flags, "token"),
      channelRef: optionalArg(flags, "channel") || optionalArg(flags, "channel-ref") || "workspace:general",
    }));
    const data = listWorkspaces(redactedState(state));
    reporter.line(`Workspace ${requiredArg(flags, "ref")} connected.`);
    reporter.write({ data });
    return data;
  }
  if (subcommand === "remove" || subcommand === "delete") {
    const workspaceRef = positional[1] || flags.ref;
    const state = store.updateState((current) => removeWorkspace(current, workspaceRef));
    const data = listWorkspaces(redactedState(state));
    reporter.line(`Workspace ${workspaceRef} removed.`);
    reporter.write({ data });
    return data;
  }
  if (subcommand === "bind") {
    const localAgentRef = optionalArg(flags, "agent") || optionalArg(flags, "local-agent");
    const workspaceRef = optionalArg(flags, "workspace") || optionalArg(flags, "ref");
    if (!localAgentRef) throw new Error("workspace bind requires --agent <local-agent-ref>");
    if (!workspaceRef) throw new Error("workspace bind requires --workspace <workspace-ref>");
    const state = store.updateState((current) => bindLocalAgentWorkspace(
      current,
      localAgentRef,
      workspaceRef,
    ));
    const data = state.local_agents;
    reporter.line(`Local agent ${localAgentRef} bound to workspace ${workspaceRef}.`);
    reporter.write({ data });
    return data;
  }
  if (subcommand === "unbind") {
    const localAgentRef = positional[1] || flags.agent || flags["local-agent"];
    const state = store.updateState((current) => unbindLocalAgentWorkspace(current, localAgentRef));
    const data = state.local_agents;
    reporter.line(`Local agent ${localAgentRef} unbound from workspace.`);
    reporter.write({ data });
    return data;
  }
  throw new Error(`unknown workspace command: ${subcommand}`);
}

function runLocalAgentCommand(store, positional, flags, io, reporter) {
  const subcommand = positional[0] || "list";
  if (subcommand === "list") {
    const data = store.loadState().local_agents;
    reporter.write({ data });
    if (!reporter.json) renderConfiguredAgents(data, io.stdout);
    return data;
  }
  if (subcommand === "reported") {
    const data = reportedLocalAgents(store.loadState(), io.env);
    reporter.write({ data });
    if (!reporter.json) renderReportedAgents(data, io.stdout);
    return data;
  }
  if (subcommand === "discover") {
    const data = discoverCliAgents(io.env, store.loadState());
    reporter.write({ data });
    if (!reporter.json) {
      if (data.length === 0) io.stdout.write("No known local agent CLIs found on PATH.\n");
      else reporter.table(["REF", "PROVIDER", "BINARY"], data.map((agent) => [agent.local_agent_ref, agent.provider, agent.binary]));
    }
    return data;
  }
  if (subcommand === "add") {
    const state = store.updateState((current) => addLocalAgent(current, {
      localAgentRef: requiredArg(flags, "ref"),
      provider: requiredArg(flags, "provider"),
      name: requiredArg(flags, "name"),
      dispatchCommand: optionalArg(flags, "dispatch-command"),
      workspaceMessageCommand: optionalArg(flags, "workspace-message-command"),
      lifecycleCommand: optionalArg(flags, "lifecycle-command"),
      runtimeInstallCommand: optionalArg(flags, "runtime-install-command"),
      runtimeUninstallCommand: optionalArg(flags, "runtime-uninstall-command"),
      skillInstallCommand: optionalArg(flags, "skill-install-command"),
      skillUninstallCommand: optionalArg(flags, "skill-uninstall-command"),
      runtimeProvider: optionalArg(flags, "runtime-provider"),
      runtimeRunner: flags["runtime-runner"] === true,
      workingDirectory: optionalArg(flags, "cwd"),
      skillsDirectory: optionalArg(flags, "skills-dir"),
      capabilities: optionalArg(flags, "capabilities"),
    }));
    reporter.line(`Local agent ${requiredArg(flags, "ref")} saved.`);
    reporter.write({ data: state.local_agents });
    return state.local_agents;
  }
  if (subcommand === "remove") {
    const ref = positional[1] || flags.ref;
    const state = store.updateState((current) => removeLocalAgent(current, ref));
    reporter.line(`Local agent ${ref} removed.`);
    reporter.write({ data: state.local_agents });
    return state.local_agents;
  }
  throw new Error(`unknown local-agent command: ${subcommand}`);
}

async function runRuntimeCommand(store, positional, flags, io, reporter) {
  const subcommand = positional[0] || "list";
  if (subcommand === "list" || subcommand === "status") {
    const state = store.loadState();
    const providers = listRuntimeProviders().map((provider) => runtimeProviderStatus(provider.id, io.env, state));
    reporter.write({ data: providers });
    if (!reporter.json) renderRuntimeProviders(providers, io.stdout);
    return providers;
  }
  if (subcommand === "search") {
    const query = String(positional[1] || flags.query || "").trim().toLowerCase();
    const state = store.loadState();
    const providers = listRuntimeProviders()
      .filter((provider) => !query || [provider.id, provider.provider, provider.label, provider.package_ref].some((value) => String(value || "").toLowerCase().includes(query)))
      .map((provider) => runtimeProviderStatus(provider.id, io.env, state));
    reporter.write({ data: providers });
    if (!reporter.json) renderRuntimeProviders(providers, io.stdout);
    return providers;
  }
  if (subcommand === "ready") {
    const runtimeRef = positional[1] || flags.runtime || flags.ref;
    if (!runtimeRef) throw new Error("runtime ready requires a runtime ref");
    const readiness = runtimeProviderReadiness(runtimeRef, io.env, store.loadState(), { deep: true });
    reporter.write(readiness);
    if (!reporter.json) renderRuntimeReadiness(readiness, io.stdout);
    return readiness;
  }
  if (subcommand === "env") {
    const runtimeRef = positional[1] || flags.runtime || flags.ref;
    if (!runtimeRef) throw new Error("runtime env requires a runtime ref");
    const setValues = parseEnvAssignments(arrayFlag(flags.set));
    const unsetValues = arrayFlag(flags.unset);
    const changed = Object.keys(setValues).length > 0 || unsetValues.length > 0;
    const state = changed
      ? store.updateState((current) => setRuntimeEnv(current, runtimeRef, setValues, unsetValues))
      : store.loadState();
    const env = runtimeEnvForState(state, runtimeRef);
    const result = { runtime_ref: runtimeRef, env: redactEnv(env), keys: Object.keys(env).sort(), changed };
    reporter.write(result);
    if (!reporter.json) renderRuntimeEnv(result, io.stdout);
    return result;
  }
  if (subcommand === "install" || subcommand === "uninstall") {
    const runtimeRef = positional[1] || flags.runtime || flags.ref;
    if (!runtimeRef) throw new Error(`runtime ${subcommand} requires a runtime ref`);
    const runner = subcommand === "install" ? installRuntimeProvider : uninstallRuntimeProvider;
    reporter.step(1, 2, `${subcommand === "install" ? "Install" : "Uninstall"} runtime`, runtimeRef);
    const result = await runner({
      runtime_ref: runtimeRef,
      version: optionalArg(flags, "version"),
      package_ref: optionalArg(flags, "package-ref"),
      working_directory: optionalArg(flags, "cwd"),
    }, io.env, (line) => reporter.line(line));
    reporter.step(2, 2, result.exit_code === 0 ? "Runtime command completed" : "Runtime command failed", `exit ${result.exit_code}`);
    reporter.write(result);
    return result;
  }
  throw new Error(`unknown runtime command: ${subcommand}`);
}

function runAutostartCommand(store, subcommand, cliPath, reporter) {
  if (subcommand === "enable") {
    if (!store.loadState().connector) throw new Error("connector is not enrolled; run hou-agent-connector enroll first");
    reporter.step(1, 2, "Write platform autostart entry");
    const result = enableAutostart(store, cliPath);
    reporter.step(2, 2, "Autostart enabled", result.path || result.method || "");
    reporter.write(result);
    return result;
  }
  if (subcommand === "disable") {
    const result = disableAutostart();
    reporter.line("Autostart disabled.");
    reporter.write(result);
    return result;
  }
  if (subcommand === "status") {
    const result = autostartStatus();
    reporter.line(result.enabled ? "Autostart is enabled." : "Autostart is disabled.");
    reporter.write(result);
    return result;
  }
  throw new Error(`unknown autostart command: ${subcommand}`);
}

function renderStatus(snapshot, stream) {
  stream.write("Houflow Agent Connector\n\n");
  stream.write(`State directory: ${snapshot.config_dir}\n`);
  stream.write(`Daemon: ${snapshot.running ? `running (PID ${snapshot.pid})` : "stopped"}\n`);
  stream.write(`Connector: ${snapshot.connector ? `${snapshot.connector.id} (${snapshot.connector.install_target_id})` : "not enrolled"}\n`);
  stream.write(`Heartbeat: ${snapshot.status?.last_heartbeat_at ? `${snapshot.status.status} (${formatAge(snapshot.status.last_heartbeat_at)})` : "not sent"}\n`);
  if (snapshot.status?.last_error) stream.write(`Last error: ${snapshot.status.last_error}\n`);
  stream.write(`Reported agents: ${snapshot.counts.reported_agents} total, ${snapshot.counts.command_agents} command-capable\n`);
  stream.write(`Autostart: ${snapshot.autostart.enabled ? "enabled" : "disabled"}\n`);
  if (snapshot.reported_agents.length > 0) {
    stream.write("\nAgents\n");
    renderReportedAgents(snapshot.reported_agents, stream);
  }
  if (snapshot.notifications.length > 0) {
    stream.write("\nRecent notifications\n");
    renderNotifications(snapshot.notifications.slice(-5), stream);
  }
  if (snapshot.recent_commands.length > 0) {
    stream.write("\nRecent commands\n");
    renderCommandList(snapshot.recent_commands, stream);
  }
}

function renderCommandList(commands, stream) {
  if (commands.length === 0) {
    stream.write("No connector commands have been received on this host.\n");
    return;
  }
  writeRows(stream, ["ID", "STATUS", "ACTION", "LOCAL AGENT", "UPDATED", "EVENTS"], commands.map((command) => [
    command.id,
    command.status,
    command.action,
    command.local_agent_ref,
    command.updated_at || command.received_at || "",
    String(command.events?.length || 0),
  ]));
}

function renderCommandDetail(command, stream) {
  stream.write(`Command ${command.id}\n\n`);
  stream.write(`Status: ${command.status}\n`);
  stream.write(`Action: ${command.action}\n`);
  stream.write(`Local agent: ${command.local_agent_ref}\n`);
  stream.write(`Connected agent: ${command.connected_agent_id || "-"}\n`);
  stream.write(`Received: ${command.received_at || "-"}\n`);
  stream.write(`Updated: ${command.updated_at || "-"}\n`);
  if (command.error) stream.write(`Error: ${command.error}\n`);
  if (Object.keys(command.output || {}).length > 0) {
    stream.write("\nOutput\n");
    renderCommandOutput(command.output, stream);
  }
  stream.write("\nEvents\n");
  if (!command.events || command.events.length === 0) {
    stream.write("No command events recorded yet.\n");
    return;
  }
  writeRows(stream, ["TIME", "TYPE", "LEVEL", "MESSAGE"], command.events.map((event) => [
    event.created_at,
    event.type,
    event.level,
    event.message || event.title,
  ]));
}

function renderCommandOutput(output, stream) {
  if (output.text) stream.write(`${String(output.text).trimEnd()}\n`);
  if (output.stderr) stream.write(`stderr: ${String(output.stderr).trimEnd()}\n`);
  if (output.exit_code !== undefined) stream.write(`exit_code: ${output.exit_code}\n`);
  const remaining = Object.entries(output).filter(([key]) => key !== "text" && key !== "stderr" && key !== "exit_code");
  for (const [key, value] of remaining) stream.write(`${key}: ${JSON.stringify(value)}\n`);
}

function renderConfiguredAgents(agents, stream) {
  if (agents.length === 0) {
    stream.write("No configured local agents.\n");
    return;
  }
  writeRows(stream, ["REF", "PROVIDER", "NAME", "ACTIONS"], agents.map((agent) => [
    agent.local_agent_ref,
    agent.provider,
    agent.name,
    capabilitySummary(agent.capabilities),
  ]));
}

function renderWorkspaces(workspaces, stream) {
  if (workspaces.length === 0) {
    stream.write("No workspaces connected on this computer.\n");
    return;
  }
  writeRows(stream, ["REF", "NAME", "CHANNEL", "URL", "TOKEN"], workspaces.map((workspace) => [
    workspace.workspace_ref,
    workspace.name,
    workspace.channel_ref,
    workspace.url,
    workspace.token_prefix || workspace.token,
  ]));
}

function renderRuntimeProviders(providers, stream) {
  if (providers.length === 0) {
    stream.write("No runtime providers in connector registry.\n");
    return;
  }
  writeRows(stream, ["REF", "PROVIDER", "BINARY", "INSTALLED", "READY", "EXECUTION", "PACKAGE"], providers.map((provider) => [
    provider.runtime_ref,
    provider.provider,
    provider.binary,
    provider.installed ? "yes" : "no",
    provider.ready ? "yes" : "no",
    provider.readiness?.execution_mode || "-",
    provider.package_ref,
  ]));
}

function renderRuntimeReadiness(readiness, stream) {
  stream.write(`${readiness.label}\n\n`);
  stream.write(`Runtime: ${readiness.runtime_ref}\n`);
  stream.write(`Installed: ${readiness.installed ? "yes" : "no"}\n`);
  stream.write(`Ready: ${readiness.ready ? "yes" : "no"}\n`);
  stream.write(`Message: ${readiness.message}\n`);
  stream.write(`Binary: ${readiness.binary_path || "-"}\n`);
  stream.write(`Auth: ${readiness.auth_mode || "-"}\n`);
  stream.write(`Execution: ${readiness.execution_mode || "-"}\n`);
  if (readiness.login_command) stream.write(`Login command: ${readiness.login_command}\n`);
  if (readiness.missing_env?.length) stream.write(`Missing env: ${readiness.missing_env.join(", ")}\n`);
}

function renderRuntimeEnv(result, stream) {
  stream.write(`Runtime env for ${result.runtime_ref}\n\n`);
  if (result.keys.length === 0) {
    stream.write("No saved runtime environment variables.\n");
    return;
  }
  writeRows(stream, ["KEY", "VALUE"], result.keys.map((key) => [key, result.env[key] || ""]));
}

function renderReportedAgents(agents, stream) {
  if (agents.length === 0) {
    stream.write("No reported local agents.\n");
    return;
  }
  writeRows(stream, ["REF", "PROVIDER", "STATUS", "SOURCE", "ACTIONS"], agents.map((agent) => [
    agent.local_agent_ref,
    agent.provider,
    agent.status,
    agent.metadata.source || "",
    capabilitySummary(agent.capabilities),
  ]));
}

function capabilitySummary(capabilities) {
  const labels = [
    capabilities.lifecycle && "lifecycle",
    capabilities.dispatch && "dispatch",
    capabilities.workspace_message && "workspace_message",
    capabilities.runtime_install && "runtime_install",
    capabilities.runtime_uninstall && "runtime_uninstall",
    capabilities.skill_install && "skill_install",
    capabilities.skill_uninstall && "skill_uninstall",
    capabilities.runtime_provider_projection && "runtime_provider_projection",
  ].filter(Boolean);
  return labels.length > 0 ? labels.join(",") : "-";
}

function renderLogs(records, stream) {
  if (records.length === 0) {
    stream.write("No connector logs yet.\n");
    return;
  }
  for (const record of records) {
    const timestamp = record.timestamp || "-";
    stream.write(`${timestamp} ${record.level.toUpperCase()} ${record.message}\n`);
  }
}

function renderNotifications(records, stream) {
  if (records.length === 0) {
    stream.write("No connector notifications.\n");
    return;
  }
  writeRows(stream, ["TIME", "LEVEL", "TYPE", "MESSAGE"], records.map((record) => [
    record.created_at,
    record.level,
    record.type,
    record.message,
  ]));
}

function writeRows(stream, headers, rows) {
  const tableIo = { stdout: stream };
  createReporter(tableIo, { human: true }).table(headers, rows);
}

function parseArgs(argv) {
  const args = argv.slice(2);
  const flags = {};
  const positional = [];
  for (let index = 0; index < args.length; index += 1) {
    const item = args[index];
    if (item.startsWith("--")) {
      const eq = item.indexOf("=");
      if (eq > 0) {
        pushFlag(flags, item.slice(2, eq), item.slice(eq + 1));
      } else if (args[index + 1] && !args[index + 1].startsWith("--")) {
        pushFlag(flags, item.slice(2), args[index + 1]);
        index += 1;
      } else {
        pushFlag(flags, item.slice(2), true);
      }
    } else {
      positional.push(item);
    }
  }
  return { command: positional[0] || "", positional: positional.slice(1), flags };
}

function pushFlag(flags, key, value) {
  if (flags[key] === undefined) {
    flags[key] = value;
    return;
  }
  flags[key] = Array.isArray(flags[key]) ? [...flags[key], value] : [flags[key], value];
}

function requiredArg(flags, key, envValue) {
  const value = optionalArg(flags, key, envValue);
  if (!value) throw new Error(`${key} is required`);
  return value;
}

function optionalArg(flags, key, envValue) {
  const raw = flags[key] === undefined ? envValue : flags[key];
  const value = Array.isArray(raw) ? raw[raw.length - 1] : raw;
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function arrayFlag(value) {
  if (value === undefined || value === null || value === true) return [];
  return (Array.isArray(value) ? value : [value]).map((item) => String(item || "").trim()).filter(Boolean);
}

function parseEnvAssignments(values) {
  const result = {};
  for (const value of values) {
    const index = value.indexOf("=");
    if (index <= 0) throw new Error(`runtime env --set must be KEY=VALUE: ${value}`);
    result[value.slice(0, index)] = value.slice(index + 1);
  }
  return result;
}

function redactEnv(env) {
  return Object.fromEntries(Object.entries(env).map(([key, value]) => [key, secretLikeKey(key) ? redactValue(value) : value]));
}

function secretLikeKey(key) {
  return /(?:KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)/i.test(key);
}

function redactValue(value) {
  const text = String(value || "");
  if (!text) return "";
  if (text.length <= 8) return "[redacted]";
  return `${text.slice(0, 4)}...${text.slice(-4)}`;
}

function redactedLogin(login) {
  const { device_code: _deviceCode, ...rest } = login || {};
  return rest;
}

function positiveIntegerArg(value, defaultValue, name) {
  if (value === undefined || value === null || value === "") return defaultValue;
  const parsed = Number(value);
  if (Number.isFinite(parsed) && parsed > 0) return Math.floor(parsed);
  throw new Error(`${name} must be a positive integer`);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function runtimeProviderExists(runtimeRef) {
  return listRuntimeProviders().some((provider) => provider.id === runtimeRef || provider.provider === runtimeRef);
}

function slugValue(value) {
  const slug = String(value || "").trim().toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "");
  return slug || "local";
}

function writeHelp(stream) {
  stream.write(`Houflow Agent Connector

Usage:
  hou-agent-connector <command> [options]

Global options:
  --config <dir>       Use a specific connector state directory.
  --json               Print machine-readable JSON.
  --human              Print human-readable output.

Commands:
  login [--control-url <url>] [--console-url <url>] [--no-open] [--name <name>]
  enroll --control-url <url> --token <token> --install-target-id <id> --platform <platform> --package-ref <pkg> --package-sha256 <sha256> --package-signature-ref <sig> --package-signature-sha256 <sha256> --package-signature-algorithm rsa-sha256 --connector-version <version>
  up [--foreground]
  down
  status [--watch]
  watch [--interval <ms>] [--desktop-notify]
  heartbeat
  version
  diagnose
  logs [--lines <n>]
  logs --follow [--lines <n>]
  commands list [--limit <n>]
  commands show <command-id>
  commands watch [command-id] [--interval <ms>]
  connector rotate-token
  connector revoke [--reason <text>]
  notifications list|clear|test [--desktop]
  local-agent list|reported|discover
  local-agent add --ref <ref> --provider <provider> --name <name> [--runtime-provider <ref>] [--runtime-runner] [--skills-dir <dir>] [--dispatch-command <command>] [--workspace-message-command <command>] [--lifecycle-command <command>] [--runtime-install-command <command>] [--runtime-uninstall-command <command>] [--skill-install-command <command>] [--skill-uninstall-command <command>] [--cwd <dir>] [--capabilities lifecycle,dispatch,workspace_message,runtime_install,runtime_uninstall,skill_install,skill_uninstall,log_tail,runtime_provider_projection]
  local-agent remove <ref>
  workspace list
  workspace add --ref <workspace-ref> --name <name> --url <url> --token <token> [--channel <channel-ref>]
  workspace remove <workspace-ref>
  workspace bind --agent <local-agent-ref> --workspace <workspace-ref>
  workspace unbind <local-agent-ref>
  create <name> [--type <provider>] [--install] [--ref <ref>] [local-agent options]
  remove <ref>                  Alias for local-agent remove.
  list                         Alias for local-agent list.
  search [query]                Search connector-managed runtime providers.
  runtime list|status|search [query]
  runtime ready <runtime-ref>
  runtime env <runtime-ref> [--set KEY=VALUE] [--unset KEY]
  runtime install|uninstall <runtime-ref> [--version <version>] [--package-ref <npm-package>]
  update check [--control-url <url>]
  update [install] [--control-url <url>] [--force]
  install <runtime-ref>         Alias for runtime install.
  uninstall <runtime-ref>       Alias for runtime uninstall.
  runtimes                      Alias for runtime status.
  autostart enable|disable|status
  autostart --disable           Alias for autostart disable.
`);
}

function defaultIo() {
  return {
    stdout: process.stdout,
    stderr: process.stderr,
    env: process.env,
    exit(code) {
      process.exitCode = code;
    },
  };
}

async function followLogs(store, io) {
  let stopped = false;
  let offset = store.logSize();
  const stop = () => {
    stopped = true;
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  io.stdout.write("\nFollowing connector logs. Press Ctrl-C to stop.\n");
  while (!stopped) {
    const result = store.readLogFromOffset(offset);
    if (result.records.length > 0) renderLogs(result.records, io.stdout);
    offset = result.offset;
    await sleep(1000);
  }
}

module.exports = { runCli };
