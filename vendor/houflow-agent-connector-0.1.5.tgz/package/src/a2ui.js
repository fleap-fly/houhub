function extractA2UISpec(content) {
  if (!content || typeof content !== "string") return { cleanContent: content, spec: null, specToolCallId: null };
  const match = content.match(/```a2ui\s*\n([\s\S]*?)\n```/);
  if (!match) return { cleanContent: content, spec: null, specToolCallId: null };
  let spec;
  try {
    spec = JSON.parse(match[1]);
  } catch {
    return { cleanContent: content, spec: null, specToolCallId: null };
  }
  const specToolCallId = spec && typeof spec === "object" && !Array.isArray(spec) && typeof spec.tool_call_id === "string" && spec.tool_call_id.trim()
    ? spec.tool_call_id.trim()
    : generatedToolCallId();
  if (spec && typeof spec === "object" && !Array.isArray(spec) && "tool_call_id" in spec) delete spec.tool_call_id;
  return { cleanContent: content.replace(match[0], "").trim(), spec, specToolCallId };
}

function a2uiPayload(spec, specToolCallId) {
  if (!spec) return {};
  return { spec, specToolCallId };
}

function createA2UIStreamExtractor(onText, onSpec) {
  let buffering = false;
  let buffer = [];
  return {
    line(line) {
      const text = typeof line === "string" ? line : String(line ?? "");
      if (!buffering) {
        const extracted = extractA2UISpec(text);
        if (extracted.spec) {
          const writes = [];
          if (extracted.cleanContent && extracted.cleanContent.trim()) writes.push(onText(extracted.cleanContent));
          writes.push(onSpec(extracted.spec, extracted.specToolCallId));
          return Promise.all(writes);
        }
      }
      if (!buffering && !/^```a2ui\s*$/.test(text.trim())) {
        return onText(text);
      }
      buffering = true;
      buffer.push(text);
      if (!/^```\s*$/.test(text.trim()) || buffer.length === 1) return undefined;
      const block = buffer.join("\n");
      buffering = false;
      buffer = [];
      const extracted = extractA2UISpec(block);
      if (extracted.spec) return onSpec(extracted.spec, extracted.specToolCallId);
      return onText(block);
    },
    flush() {
      if (!buffer.length) return undefined;
      const block = buffer.join("\n");
      buffering = false;
      buffer = [];
      return onText(block);
    },
  };
}

function generatedToolCallId() {
  return `tc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

module.exports = { extractA2UISpec, a2uiPayload, createA2UIStreamExtractor };
