const { spawn } = require("node:child_process");
const fs = require("node:fs");
const { AgentHubClient } = require("./agent-hub-client.js");
const { resolveLocalAgent } = require("./local-agents.js");
const { appendNotification } = require("./notifications.js");
const { stopCommandProcess, trackProcess } = require("./process-manager.js");
const { runProviderAction } = require("./provider-runner.js");
const { installRuntimeProvider, runtimeEffectiveEnv, uninstallRuntimeProvider } = require("./runtime-registry.js");
const { installSkill, uninstallSkill } = require("./skill-installer.js");
const { recordCommandEvent, recordCommandReceived, recordCommandSnapshot } = require("./command-ledger.js");
const { a2uiPayload, createA2UIStreamExtractor, extractA2UISpec } = require("./a2ui.js");

const MAX_CAPTURE_BYTES = 256 * 1024;
const MAX_STEP_LINES = 20;

async function pollAndRunCommand(store, env = process.env, options = {}) {
  const state = store.loadState();
  if (!state.connector) throw new Error("connector is not enrolled");
  const client = new AgentHubClient(state.connector.control_url);
  const response = await client.pollCommand(state.connector.id, state.connector.token);
  const command = response?.command ?? null;
  if (!command) return null;
  recordCommandReceived(store, command);
  if (command.status === "cancelled") {
    await handleCancelledCommand(store, client, state.connector, command);
    return command;
  }
  const run = runConnectorCommand(store, state, client, command, env);
  if (options.background === true) {
    run.catch((error) => {
      store.appendLog("error", "Connector command runner failed", {
        command_id: command.id,
        error: error instanceof Error ? error.message : String(error),
      });
    }).finally(() => {
      if (typeof options.onComplete === "function") options.onComplete(command);
    });
    return command;
  }
  await run;
  return command;
}

async function runConnectorCommand(store, state, client, command, env = process.env) {
  const connector = state.connector;
  const localAgent = resolveLocalAgent(state, command.local_agent_ref, env);
  let action;
  try {
    action = commandAction(command.action);
  } catch (error) {
    await reportFailed(store, client, connector, command, error instanceof Error ? error.message : String(error));
    return;
  }
  const spec = commandSpec(action);
  if (!localAgent) {
    await reportFailed(store, client, connector, command, `Local agent ${command.local_agent_ref} is not configured.`);
    return;
  }
  let runner;
  try {
    runner = commandRunner(store, localAgent, spec, action, command);
  } catch (error) {
    await reportFailed(store, client, connector, command, error instanceof Error ? error.message : String(error));
    return;
  }
  if (!runner) {
    await reportFailed(store, client, connector, command, `Local agent ${command.local_agent_ref} does not have a ${spec.label} command.`);
    return;
  }
  await reportCommandEvent(store, client, connector, command, {
    type: "started",
    title: `${spec.title} started`,
    message: `Running ${localAgent.name}`,
    payload: { action, local_agent_ref: localAgent.local_agent_ref, provider: localAgent.provider },
  });
  store.appendLog("info", "Connector command started", { command_id: command.id, action, local_agent_ref: command.local_agent_ref });
  appendNotification(store, {
    type: "command_started",
    level: "info",
    title: "Connector command started",
    message: `Started ${action} command ${command.id} for ${localAgent.name}.`,
    metadata: { command_id: command.id, action, local_agent_ref: command.local_agent_ref },
  });
  let result;
  const reportStep = serialStepReporter(store, client, connector, command, action);
  try {
    result = await runner.run(env, reportStep.line);
    await reportStep.drain();
  } catch (error) {
    await reportStep.drain().catch(() => {});
    if (wasCancelled(store, command.id)) return;
    await reportFailed(store, client, connector, command, error instanceof Error ? error.message : String(error));
    return;
  }
  if (result.exit_code === 0) {
    if (wasCancelled(store, command.id)) return;
    await reportCommandEvent(store, client, connector, command, {
      type: "notification",
      title: "Connector command completed",
      message: `Local agent ${localAgent.name} completed ${action} command ${command.id}.`,
      payload: { command_id: command.id, action },
    });
    await reportCommandEvent(store, client, connector, command, {
      type: "succeeded",
      title: `${spec.title} succeeded`,
      message: `Local agent completed ${action}.`,
      output: commandOutput(result),
    });
    store.appendLog("info", "Connector command succeeded", { command_id: command.id, action });
    appendNotification(store, {
      type: "command_succeeded",
      level: "info",
      title: "Connector command completed",
      message: `${action} command ${command.id} completed.`,
      metadata: { command_id: command.id, action },
    });
    return;
  }
  if (wasCancelled(store, command.id)) return;
  await reportFailed(store, client, connector, command, result.stderr || `Local agent exited with code ${result.exit_code}`, commandOutput(result));
}

function commandOutput(result) {
  const extracted = extractA2UISpec(result.stdout);
  return {
    text: extracted.cleanContent,
    stderr: result.stderr,
    exit_code: result.exit_code,
    ...a2uiPayload(extracted.spec, extracted.specToolCallId),
  };
}

async function runLocalAgentAction(store, params, env = process.env, onLine = () => {}) {
  const state = store.loadState();
  const action = commandAction(params.action);
  const spec = commandSpec(action);
  const localAgentRef = requiredText(params.local_agent_ref, "local_agent_ref");
  const localAgent = resolveLocalAgent(state, localAgentRef, env);
  if (!localAgent) throw new Error(`Local agent ${localAgentRef} is not configured.`);
  const command = localCommand(params, action, localAgentRef);
  const runner = commandRunner(store, localAgent, spec, action, command);
  if (!runner) throw new Error(`Local agent ${localAgentRef} does not have a ${spec.label} command.`);
  const startedAt = new Date().toISOString();
  store.appendLog("info", "Local connector action started", { action, local_agent_ref: localAgentRef, command_id: command.id });
  const result = await runner.run(env, onLine);
  store.appendLog(result.exit_code === 0 ? "info" : "error", "Local connector action completed", {
    action,
    local_agent_ref: localAgentRef,
    command_id: command.id,
    exit_code: String(result.exit_code),
  });
  return {
    ...result,
    action,
    local_agent_ref: localAgentRef,
    command_id: command.id,
    started_at: startedAt,
    completed_at: new Date().toISOString(),
  };
}

async function runLocalCommandProcess(store, localAgent, localCommand, action, command, env, onLine) {
  const state = store?.loadState ? store.loadState() : null;
  const runtimeEnv = localAgent.runtime_provider ? runtimeEffectiveEnv(localAgent.runtime_provider, state, env) : env;
  const child = trackProcess(localAgent.local_agent_ref, spawn(localCommand, {
    cwd: localAgent.working_directory || process.cwd(),
    env: {
      ...runtimeEnv,
      HOUFLOW_AGENT_CONNECTOR_ACTION: action,
      HOUFLOW_AGENT_CONNECTOR_COMMAND_ID: command.id,
      HOUFLOW_CONNECTED_AGENT_ID: command.connected_agent_id,
      HOUFLOW_LOCAL_AGENT_REF: command.local_agent_ref,
      HOUFLOW_AGENT_CONNECTOR_INPUT: JSON.stringify(commandInputForLocalProcess(command.input)),
    },
    shell: true,
    detached: process.platform !== "win32",
    windowsHide: true,
    stdio: ["pipe", "pipe", "pipe"],
  }), command.id);
  child.stdin.end(`${commandStdin(action, commandInputForLocalProcess(command.input))}\n`);
  let stdout = "";
  let stderr = "";
  let reportedLines = 0;
  const lineReports = [];
  child.stdout.on("data", (chunk) => {
    const text = String(chunk);
    stdout = appendLimited(stdout, text);
    if (reportedLines >= MAX_STEP_LINES) return;
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) {
      if (reportedLines >= MAX_STEP_LINES) break;
      reportedLines += 1;
      lineReports.push(Promise.resolve(onLine(line.slice(0, 1000))));
    }
  });
  child.stderr.on("data", (chunk) => {
    stderr = appendLimited(stderr, String(chunk));
  });
  const exitCode = await new Promise((resolve) => {
    child.on("error", () => resolve(127));
    child.on("close", (code) => resolve(Number.isInteger(code) ? code : 1));
  });
  await Promise.all(lineReports);
  return {
    exit_code: exitCode,
    stdout,
    stderr,
  };
}

function serialStepReporter(store, client, connector, command, action) {
  let pending = Promise.resolve();
  const report = (message, payload = {}) => {
    pending = pending.then(() => reportCommandEvent(store, client, connector, command, {
      type: "step",
      title: "Local agent output",
      message,
      payload: { action, local_agent_ref: command.local_agent_ref, ...jsonObject(payload) },
    }));
    return pending;
  };
  const stream = createA2UIStreamExtractor(
    (line) => report(line),
    (spec, specToolCallId) => report("A2UI spec", a2uiPayload(spec, specToolCallId)),
  );
  return {
    line(line, payload = {}) {
      if (Object.keys(jsonObject(payload)).length > 0) return report(line, payload);
      return stream.line(line);
    },
    drain() {
      stream.flush();
      return pending;
    },
  };
}

async function reportCommandEvent(store, client, connector, command, event) {
  const result = await client.commandEvent(connector.id, connector.token, command.id, event);
  if (result?.id === command.id) recordCommandSnapshot(store, result);
  else recordCommandEvent(store, command, event);
  if (result?.status === "cancelled") await stopCommandProcess(command.id);
  return result;
}

async function handleCancelledCommand(store, client, connector, command) {
  const event = {
    type: "cancelled",
    title: "Connector command cancelled",
    message: "Agent Hub cancelled this connector command.",
    level: "warning",
    payload: { command_id: command.id, local_agent_ref: command.local_agent_ref, source: "connector" },
  };
  recordCommandEvent(store, command, event);
  await stopCommandProcess(command.id);
  try {
    const result = await client.commandEvent(connector.id, connector.token, command.id, event);
    if (result?.id === command.id) recordCommandSnapshot(store, result);
    else recordCommandEvent(store, command, event);
  } catch {
    recordCommandEvent(store, command, event);
  }
  store.appendLog("warning", "Connector command cancelled", { command_id: command.id, local_agent_ref: command.local_agent_ref });
  appendNotification(store, {
    type: "command_cancelled",
    level: "warning",
    title: "Connector command cancelled",
    message: `Command ${command.id} was cancelled by Agent Hub.`,
    metadata: { command_id: command.id, local_agent_ref: command.local_agent_ref },
  });
}

function wasCancelled(store, commandId) {
  try {
    const entry = recordOnlyRead(store, commandId);
    return entry?.status === "cancelled";
  } catch {
    return false;
  }
}

function recordOnlyRead(store, commandId) {
  if (!fs.existsSync(store.commandLedgerFile)) return null;
  const parsed = JSON.parse(fs.readFileSync(store.commandLedgerFile, "utf8"));
  return Array.isArray(parsed.commands) ? parsed.commands.find((item) => item.id === commandId) ?? null : null;
}

function commandRunner(store, localAgent, spec, action, command) {
  if (action === "agent_status" || action === "agent_stop" || action === "agent_restart") {
    const hasRuntimeRunner = localAgent.runtime_runner === true;
    const hasCustomCommand = Boolean(localAgent.lifecycle_command);
    if (hasRuntimeRunner && hasCustomCommand) {
      throw new Error(`Local agent ${localAgent.local_agent_ref} has both runtime_runner and lifecycle_command.`);
    }
    if (hasRuntimeRunner) {
      return {
        run: (env, onLine) => runProviderAction(localAgent, action, command, env, onLine, store),
      };
    }
    if (hasCustomCommand) {
      return {
        run: (env, onLine) => runLocalCommandProcess(store, localAgent, localAgent.lifecycle_command, action, command, env, onLine),
      };
    }
  }
  if ((action === "dispatch" || action === "workspace_message") && localAgent.runtime_runner === true) {
    const localCommand = localAgent[spec.commandField];
    if (localCommand) {
      throw new Error(`Local agent ${localAgent.local_agent_ref} has both runtime_runner and ${spec.commandField}.`);
    }
    return {
      run: (env, onLine) => runProviderAction(localAgent, action, command, env, onLine, store),
    };
  }
  if (action === "runtime_install" || action === "runtime_uninstall") {
    const hasManagedRuntime = Boolean(localAgent.runtime_provider);
    const hasCustomCommand = Boolean(localAgent[spec.commandField]);
    if (hasManagedRuntime && hasCustomCommand) {
      throw new Error(`Local agent ${localAgent.local_agent_ref} has both runtime_provider and ${spec.commandField}.`);
    }
    if (hasManagedRuntime) {
      return {
        run: (env, onLine) => (action === "runtime_install" ? installRuntimeProvider : uninstallRuntimeProvider)({
          runtime_ref: command.input?.runtime_ref,
          package_ref: command.input?.package_ref,
          version: command.input?.version,
          command_id: command.id,
          expected_provider: localAgent.runtime_provider,
          working_directory: localAgent.working_directory,
        }, env, onLine),
      };
    }
  }
  if (action === "skill_install" || action === "skill_uninstall") {
    const hasManagedSkills = Boolean(localAgent.skills_directory);
    const hasCustomCommand = Boolean(localAgent[spec.commandField]);
    if (hasManagedSkills && hasCustomCommand) {
      throw new Error(`Local agent ${localAgent.local_agent_ref} has both skills_directory and ${spec.commandField}.`);
    }
    if (hasManagedSkills) {
      return {
        run: (env, onLine) => (action === "skill_install" ? installSkill : uninstallSkill)({
          skill: command.input?.skill,
          skills_directory: localAgent.skills_directory,
          command_id: command.id,
        }, env, onLine),
      };
    }
  }
  const localCommand = localAgent[spec.commandField];
  if (!localCommand) return null;
  return {
    run: (env, onLine) => runLocalCommandProcess(store, localAgent, localCommand, action, command, env, onLine),
  };
}

async function reportFailed(store, client, connector, command, message, output = {}) {
  await reportCommandEvent(store, client, connector, command, {
    type: "failed",
    title: "Connector command failed",
    message,
    error: message,
    output,
  });
}

function commandAction(value) {
  const action = typeof value === "string" && value.trim() ? value.trim() : "";
  if (
    action === "dispatch"
    || action === "workspace_message"
    || action === "runtime_install"
    || action === "runtime_uninstall"
    || action === "skill_install"
    || action === "skill_uninstall"
    || action === "agent_status"
    || action === "agent_stop"
    || action === "agent_restart"
  ) {
    return action;
  }
  throw new Error(`Unsupported connector command action: ${action}`);
}

function commandSpec(action) {
  if (action === "workspace_message") return { commandField: "workspace_message_command", label: "workspace message", title: "Workspace message" };
  if (action === "runtime_install") return { commandField: "runtime_install_command", label: "runtime install", title: "Runtime install" };
  if (action === "runtime_uninstall") return { commandField: "runtime_uninstall_command", label: "runtime uninstall", title: "Runtime uninstall" };
  if (action === "skill_install") return { commandField: "skill_install_command", label: "skill install", title: "Skill install" };
  if (action === "skill_uninstall") return { commandField: "skill_uninstall_command", label: "skill uninstall", title: "Skill uninstall" };
  if (action === "agent_status") return { commandField: "lifecycle_command", label: "agent status", title: "Agent status" };
  if (action === "agent_stop") return { commandField: "lifecycle_command", label: "agent stop", title: "Agent stop" };
  if (action === "agent_restart") return { commandField: "lifecycle_command", label: "agent restart", title: "Agent restart" };
  return { commandField: "dispatch_command", label: "dispatch", title: "Dispatch" };
}

function commandStdin(action, input) {
  if (action === "dispatch") return typeof input?.message === "string" ? input.message : "";
  return JSON.stringify(input || {});
}

function commandInputForLocalProcess(input) {
  return redactSecrets(jsonObject(input));
}

function localCommand(params, action, localAgentRef) {
  const input = jsonObject(params.input);
  return {
    id: textValue(params.command_id) || `local_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
    connector_id: textValue(params.connector_id),
    connected_agent_id: textValue(params.connected_agent_id) || "local-preview",
    local_agent_ref: localAgentRef,
    action,
    input,
  };
}

function jsonObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function redactSecrets(value) {
  if (!value || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map(redactSecrets);
  const next = {};
  for (const [key, item] of Object.entries(value)) {
    if (key === "api_key_value") {
      next[key] = "[redacted]";
    } else {
      next[key] = redactSecrets(item);
    }
  }
  return next;
}

function requiredText(value, field) {
  const text = textValue(value);
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function textValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function appendLimited(current, next) {
  const value = `${current}${next}`;
  if (Buffer.byteLength(value, "utf8") <= MAX_CAPTURE_BYTES) return value;
  return value.slice(-MAX_CAPTURE_BYTES);
}

module.exports = { pollAndRunCommand, runConnectorCommand, runLocalAgentAction };
