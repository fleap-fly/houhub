const { AgentHubNetworkClient, normalizeBaseUrl } = require("@houshan/agent-hub-network-sdk");

class AgentHubClient {
  constructor(controlUrl, options = {}) {
    this.controlUrl = normalizeControlUrl(controlUrl);
    this.network = new AgentHubNetworkClient({
      baseUrl: this.controlUrl,
      ...(options.fetch ? { fetch: options.fetch } : {}),
    });
  }

  claim(body) {
    return this.network.connectors.claim(body);
  }

  startLogin(body) {
    return this.network.connectors.startLogin(body);
  }

  releaseManifest() {
    return this.network.connectors.releaseManifest();
  }

  pollLogin(body) {
    return this.network.connectors.pollLogin(body);
  }

  heartbeat(connectorId, connectorToken, body) {
    return this.network.connectors.heartbeat(connectorId, connectorToken, body);
  }

  pollCommand(connectorId, connectorToken) {
    return this.network.connectors.pollCommand(connectorId, connectorToken);
  }

  commandEvent(connectorId, connectorToken, commandId, body) {
    return this.network.connectors.recordCommandEvent(connectorId, connectorToken, commandId, body);
  }

  rotateToken(connectorId, connectorToken) {
    return this.network.connectors.rotateToken(connectorId, connectorToken);
  }

  revoke(connectorId, connectorToken, body = {}) {
    return this.network.connectors.revoke(connectorId, connectorToken, body);
  }
}

function normalizeControlUrl(value) {
  try {
    return normalizeBaseUrl(value);
  } catch (error) {
    if (error instanceof Error && error.message === "baseUrl is required") {
      throw new Error("control URL is required");
    }
    if (error instanceof Error && error.message.includes("baseUrl must use")) {
      throw new Error(error.message.replace("baseUrl", "control URL"));
    }
    throw error;
  }
}

module.exports = { normalizeControlUrl, AgentHubClient };
