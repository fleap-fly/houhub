const { createHash, createVerify } = require("node:crypto");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawnSync } = require("node:child_process");
const { AgentHubClient } = require("./agent-hub-client.js");

const packageInfo = require("../package.json");

async function checkConnectorUpdate(params = {}, env = process.env) {
  const controlUrl = stringValue(params.controlUrl) || connectorControlUrl(params.store) || env.HOUFLOW_AGENT_HUB_URL || "https://agent.houflow.com";
  const manifest = await new AgentHubClient(controlUrl).releaseManifest();
  const current = packageInfo.version;
  const latest = stringValue(manifest.latest_connector_version);
  const platform = currentPlatform();
  const arch = currentArch();
  const installTarget = selectInstallTarget(manifest.install_targets || [], platform, arch);
  return {
    current_version: current,
    latest_version: latest,
    update_available: latest ? compareVersions(latest, current) > 0 : false,
    control_url: controlUrl,
    platform,
    arch,
    install_target: installTarget,
    manifest,
  };
}

async function updateConnector(params = {}, env = process.env, onLine = () => {}) {
  const info = await checkConnectorUpdate(params, env);
  if (!info.update_available && params.force !== true) {
    return { ...info, changed: false, exit_code: 0, message: "Connector is already up to date." };
  }
  const target = info.install_target;
  if (!target) throw new Error(`No connector install target for ${info.platform}/${info.arch}.`);
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "houflow-agent-connector-update-"));
  try {
    const pkgFile = path.join(tmpDir, "connector.tgz");
    const sigFile = path.join(tmpDir, "connector.tgz.sig");
    const keyFile = path.join(tmpDir, "signing-public.pem");
    onLine(`Downloading connector ${target.version} package...`);
    await downloadFile(target.package_ref, pkgFile);
    await downloadFile(target.package_signature_ref, sigFile);
    fs.writeFileSync(keyFile, target.package_signature_public_key_pem, { mode: 0o600 });
    assertSha256(pkgFile, target.package_sha256, "connector package");
    assertSha256(sigFile, target.package_signature_sha256, "connector package signature");
    assertSignature(pkgFile, sigFile, keyFile);
    const npm = findNpm(env);
    const args = ["install", "-g", pkgFile];
    onLine(`Installing connector ${target.version} with ${npm}...`);
    const result = spawnSync(npm, args, { stdio: "pipe", encoding: "utf8", env });
    const stdout = result.stdout || "";
    const stderr = result.stderr || "";
    if (stdout.trim()) onLine(stdout.trim());
    if (stderr.trim()) onLine(stderr.trim());
    if (result.status !== 0) throw new Error(`npm install failed with exit ${result.status}: ${stderr || stdout}`.trim());
    return { ...info, changed: true, exit_code: 0, installed_version: target.version, stdout, stderr };
  } finally {
    fs.rmSync(tmpDir, { recursive: true, force: true });
  }
}

function compareVersions(left, right) {
  const leftParts = versionParts(left);
  const rightParts = versionParts(right);
  for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
    const a = leftParts[index] ?? 0;
    const b = rightParts[index] ?? 0;
    if (a !== b) return a - b;
  }
  return 0;
}

function selectInstallTarget(targets, platform, arch) {
  const list = Array.isArray(targets) ? targets : [];
  return list.find((target) => target.platform === platform && target.arch === arch)
    || list.find((target) => target.platform === platform && target.arch === "universal")
    || list.find((target) => target.platform === platform)
    || null;
}

function connectorControlUrl(store) {
  try {
    return store?.loadState?.()?.connector?.control_url || "";
  } catch {
    return "";
  }
}

function currentPlatform() {
  if (process.platform === "darwin") return "macos";
  if (process.platform === "win32") return "windows";
  return "linux";
}

function currentArch() {
  const arch = os.arch();
  if (arch === "x64") return "x64";
  if (arch === "arm64") return "arm64";
  return arch;
}

function versionParts(value) {
  return String(value || "").split(/[.-]/).map((part) => Number.parseInt(part, 10)).map((part) => Number.isFinite(part) ? part : 0);
}

function assertSha256(filePath, expected, label) {
  const actual = createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
  if (actual !== expected) throw new Error(`${label} sha256 mismatch`);
}

function assertSignature(pkgFile, sigFile, keyFile) {
  const verifier = createVerify("RSA-SHA256");
  verifier.update(fs.readFileSync(pkgFile));
  verifier.end();
  if (!verifier.verify(fs.readFileSync(keyFile, "utf8"), fs.readFileSync(sigFile))) {
    throw new Error("connector package signature verification failed");
  }
}

async function downloadFile(url, filePath) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Download failed for ${url}: HTTP ${response.status}`);
  const arrayBuffer = await response.arrayBuffer();
  fs.writeFileSync(filePath, Buffer.from(arrayBuffer), { mode: 0o600 });
}

function findNpm(env) {
  const nodeDir = path.dirname(process.execPath);
  for (const name of process.platform === "win32" ? ["npm.cmd", "npm"] : ["npm"]) {
    const candidate = path.join(nodeDir, name);
    if (fs.existsSync(candidate)) return candidate;
  }
  const command = process.platform === "win32" ? "where" : "which";
  const result = spawnSync(command, ["npm"], { encoding: "utf8", env });
  return result.status === 0 ? result.stdout.trim().split(/\r?\n/)[0] || "npm" : "npm";
}

function stringValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

module.exports = { checkConnectorUpdate, updateConnector, compareVersions };
