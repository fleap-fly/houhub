const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const STATE_VERSION = 1;
const STATE_KEYS = Object.freeze(["version", "connector", "workspaces", "local_agents", "runtime_env", "heartbeat_interval_ms"]);
const CONNECTOR_KEYS = Object.freeze([
  "control_url",
  "id",
  "token",
  "token_prefix",
  "install_target_id",
  "platform",
  "package_ref",
  "package_sha256",
  "package_signature_ref",
  "package_signature_sha256",
  "package_signature_algorithm",
  "connector_version",
  "claimed_at",
]);
const LOCAL_AGENT_KEYS = Object.freeze([
  "local_agent_ref",
  "name",
  "provider",
  "runtime_provider",
  "runtime_runner",
  "dispatch_command",
  "workspace_message_command",
  "lifecycle_command",
  "runtime_install_command",
  "runtime_uninstall_command",
  "skill_install_command",
  "skill_uninstall_command",
  "working_directory",
  "skills_directory",
  "workspace_ref",
  "capabilities",
  "metadata",
]);
const WORKSPACE_KEYS = Object.freeze(["workspace_ref", "name", "url", "token", "channel_ref", "connected_at", "metadata"]);
const CAPABILITY_KEYS = Object.freeze([
  "lifecycle",
  "dispatch",
  "workspace_message",
  "runtime_install",
  "runtime_uninstall",
  "skill_install",
  "skill_uninstall",
  "log_tail",
  "artifact_upload",
  "runtime_provider_projection",
]);

class ConnectorStore {
  constructor(configDir = defaultConfigDir()) {
    this.configDir = configDir;
    this.stateFile = path.join(configDir, "state.json");
    this.statusFile = path.join(configDir, "status.json");
    this.pidFile = path.join(configDir, "daemon.pid");
    this.logFile = path.join(configDir, "daemon.log");
    this.notificationsFile = path.join(configDir, "notifications.jsonl");
    this.commandLedgerFile = path.join(configDir, "commands.json");
  }

  ensureDir() {
    fs.mkdirSync(this.configDir, { recursive: true });
  }

  loadState() {
    if (!fs.existsSync(this.stateFile)) return emptyState();
    const state = JSON.parse(fs.readFileSync(this.stateFile, "utf8"));
    return validateState(normalizeLoadedState(state));
  }

  saveState(state) {
    this.ensureDir();
    writeJsonFile(this.stateFile, validateState(state), 0o600);
  }

  updateState(mutator) {
    const next = mutator(this.loadState());
    this.saveState(next);
    return next;
  }

  loadStatus() {
    if (!fs.existsSync(this.statusFile)) return null;
    return JSON.parse(fs.readFileSync(this.statusFile, "utf8"));
  }

  saveStatus(status) {
    this.ensureDir();
    writeJsonFile(this.statusFile, status, 0o600);
  }

  appendLog(level, message, metadata = {}) {
    this.ensureDir();
    const record = {
      timestamp: new Date().toISOString(),
      level,
      message,
      metadata: logMetadata(metadata),
    };
    fs.appendFileSync(this.logFile, `${JSON.stringify(record)}\n`, { mode: 0o600 });
    return record;
  }

  tailLog(limit = 100) {
    if (!fs.existsSync(this.logFile)) return [];
    const lines = fs.readFileSync(this.logFile, "utf8").split(/\r?\n/).filter(Boolean);
    return lines.slice(-safePositiveInteger(limit, 100)).map(parseLogLine);
  }

  readLogFromOffset(offset = 0) {
    if (!fs.existsSync(this.logFile)) return { offset: 0, records: [] };
    const start = Math.max(0, Number(offset) || 0);
    const stat = fs.statSync(this.logFile);
    if (stat.size < start) return { offset: stat.size, records: [] };
    if (stat.size === start) return { offset: start, records: [] };
    const fd = fs.openSync(this.logFile, "r");
    try {
      const buffer = Buffer.alloc(stat.size - start);
      fs.readSync(fd, buffer, 0, buffer.length, start);
      const records = buffer.toString("utf8").split(/\r?\n/).filter(Boolean).map(parseLogLine);
      return { offset: stat.size, records };
    } finally {
      fs.closeSync(fd);
    }
  }

  logSize() {
    if (!fs.existsSync(this.logFile)) return 0;
    return fs.statSync(this.logFile).size;
  }

  readPid() {
    if (!fs.existsSync(this.pidFile)) return null;
    const pid = Number.parseInt(fs.readFileSync(this.pidFile, "utf8").trim(), 10);
    return Number.isFinite(pid) && pid > 0 ? pid : null;
  }

  writePid(pid) {
    this.ensureDir();
    fs.writeFileSync(this.pidFile, `${pid}\n`, { mode: 0o600 });
  }

  removePid(expectedPid = null) {
    if (expectedPid !== null && expectedPid !== undefined) {
      const currentPid = this.readPid();
      if (currentPid !== Number(expectedPid)) return false;
    }
    try {
      fs.unlinkSync(this.pidFile);
      return true;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
      return false;
    }
  }
}

function defaultConfigDir(env = process.env) {
  if (env.HOUFLOW_AGENT_CONNECTOR_HOME?.trim()) {
    return path.resolve(env.HOUFLOW_AGENT_CONNECTOR_HOME.trim());
  }
  return path.join(os.homedir(), ".houflow", "agent-connector");
}

function emptyState() {
  return {
    version: STATE_VERSION,
    connector: null,
    workspaces: [],
    local_agents: [],
    runtime_env: {},
    heartbeat_interval_ms: 15000,
  };
}

function normalizeLoadedState(state) {
  const record = plainRecord(state, "state");
  const next = { ...record };
  if (!Object.prototype.hasOwnProperty.call(next, "workspaces")) {
    next.workspaces = [];
  }
  if (Array.isArray(next.local_agents)) {
    next.local_agents = next.local_agents.map((agent) => {
      if (!agent || typeof agent !== "object" || Array.isArray(agent)) return agent;
      if (Object.prototype.hasOwnProperty.call(agent, "workspace_ref")) return agent;
      return { ...agent, workspace_ref: "" };
    });
  }
  return next;
}

function redactedState(state) {
  const next = validateState(state);
  return {
    ...next,
    workspaces: next.workspaces.map((workspace) => ({
      ...workspace,
      token: workspace.token ? "[redacted]" : "",
    })),
    runtime_env: redactedRuntimeEnv(next.runtime_env),
    connector: next.connector ? {
      control_url: next.connector.control_url,
      id: next.connector.id,
      token_prefix: next.connector.token_prefix,
      install_target_id: next.connector.install_target_id,
      platform: next.connector.platform,
      package_ref: next.connector.package_ref,
      package_sha256: next.connector.package_sha256,
      package_signature_ref: next.connector.package_signature_ref,
      package_signature_sha256: next.connector.package_signature_sha256,
      package_signature_algorithm: next.connector.package_signature_algorithm,
      connector_version: next.connector.connector_version,
      claimed_at: next.connector.claimed_at,
    } : null,
  };
}

function redactedRuntimeEnv(value) {
  const env = validateRuntimeEnv(value, "runtime_env");
  return Object.fromEntries(
    Object.entries(env).map(([runtimeRef, record]) => [
      runtimeRef,
      Object.fromEntries(Object.keys(record).sort().map((key) => [key, "[redacted]"])),
    ]),
  );
}

function validateState(value) {
  const record = plainRecord(value, "state");
  assertExactKeys(record, STATE_KEYS, "state");
  if (record.version !== STATE_VERSION) throw new Error(`state.version must be ${STATE_VERSION}`);
  return {
    version: STATE_VERSION,
    connector: record.connector === null ? null : validateConnector(record.connector),
    workspaces: arrayValue(record.workspaces, "state.workspaces").map((workspace, index) => validateWorkspace(workspace, `state.workspaces[${index}]`)),
    local_agents: arrayValue(record.local_agents, "state.local_agents").map((agent, index) => validateLocalAgent(agent, `state.local_agents[${index}]`)),
    runtime_env: validateRuntimeEnv(record.runtime_env, "state.runtime_env"),
    heartbeat_interval_ms: positiveInteger(record.heartbeat_interval_ms, "state.heartbeat_interval_ms"),
  };
}

function validateConnector(value) {
  const record = plainRecord(value, "state.connector");
  assertExactKeys(record, CONNECTOR_KEYS, "state.connector");
  return {
    control_url: requiredString(record.control_url, "state.connector.control_url"),
    id: requiredString(record.id, "state.connector.id"),
    token: requiredString(record.token, "state.connector.token"),
    token_prefix: requiredString(record.token_prefix, "state.connector.token_prefix"),
    install_target_id: requiredString(record.install_target_id, "state.connector.install_target_id"),
    platform: requiredString(record.platform, "state.connector.platform"),
    package_ref: requiredString(record.package_ref, "state.connector.package_ref"),
    package_sha256: requiredString(record.package_sha256, "state.connector.package_sha256"),
    package_signature_ref: requiredString(record.package_signature_ref, "state.connector.package_signature_ref"),
    package_signature_sha256: requiredString(record.package_signature_sha256, "state.connector.package_signature_sha256"),
    package_signature_algorithm: signatureAlgorithm(record.package_signature_algorithm),
    connector_version: requiredString(record.connector_version, "state.connector.connector_version"),
    claimed_at: requiredString(record.claimed_at, "state.connector.claimed_at"),
  };
}

function validateLocalAgent(value, field) {
  const record = plainRecord(value, field);
  assertExactKeys(record, LOCAL_AGENT_KEYS, field);
  return {
    local_agent_ref: requiredString(record.local_agent_ref, `${field}.local_agent_ref`),
    name: requiredString(record.name, `${field}.name`),
    provider: requiredString(record.provider, `${field}.provider`),
    runtime_provider: optionalString(record.runtime_provider, `${field}.runtime_provider`),
    runtime_runner: booleanValue(record.runtime_runner, `${field}.runtime_runner`),
    dispatch_command: optionalString(record.dispatch_command, `${field}.dispatch_command`),
    workspace_message_command: optionalString(record.workspace_message_command, `${field}.workspace_message_command`),
    lifecycle_command: optionalString(record.lifecycle_command, `${field}.lifecycle_command`),
    runtime_install_command: optionalString(record.runtime_install_command, `${field}.runtime_install_command`),
    runtime_uninstall_command: optionalString(record.runtime_uninstall_command, `${field}.runtime_uninstall_command`),
    skill_install_command: optionalString(record.skill_install_command, `${field}.skill_install_command`),
    skill_uninstall_command: optionalString(record.skill_uninstall_command, `${field}.skill_uninstall_command`),
    working_directory: optionalString(record.working_directory, `${field}.working_directory`),
    skills_directory: optionalString(record.skills_directory, `${field}.skills_directory`),
    workspace_ref: optionalString(record.workspace_ref, `${field}.workspace_ref`),
    capabilities: validateCapabilities(record.capabilities, `${field}.capabilities`),
    metadata: validateStringMap(record.metadata, `${field}.metadata`),
  };
}

function validateWorkspace(value, field) {
  const record = plainRecord(value, field);
  assertExactKeys(record, WORKSPACE_KEYS, field);
  return {
    workspace_ref: requiredString(record.workspace_ref, `${field}.workspace_ref`),
    name: requiredString(record.name, `${field}.name`),
    url: requiredUrl(record.url, `${field}.url`),
    token: requiredString(record.token, `${field}.token`),
    channel_ref: requiredString(record.channel_ref, `${field}.channel_ref`),
    connected_at: requiredString(record.connected_at, `${field}.connected_at`),
    metadata: validateStringMap(record.metadata, `${field}.metadata`),
  };
}

function writeJsonFile(file, value, mode) {
  const temp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { mode });
  fs.renameSync(temp, file);
  try {
    fs.chmodSync(file, mode);
  } catch {}
}

function validateCapabilities(value, field) {
  const record = plainRecord(value, field);
  assertExactKeys(record, CAPABILITY_KEYS, field);
  return Object.fromEntries(CAPABILITY_KEYS.map((key) => [key, booleanValue(record[key], `${field}.${key}`)]));
}

function validateStringMap(value, field) {
  const record = plainRecord(value, field);
  for (const [key, next] of Object.entries(record)) {
    if (typeof next !== "string") throw new Error(`${field}.${key} must be a string`);
  }
  return { ...record };
}

function logMetadata(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(Object.entries(value).map(([key, next]) => [key, String(next)]));
}

function validateRuntimeEnv(value, field) {
  const record = plainRecord(value, field);
  const result = {};
  for (const [runtimeRef, env] of Object.entries(record)) {
    if (!runtimeRef.trim()) throw new Error(`${field} contains an empty runtime ref`);
    result[runtimeRef] = validateStringMap(env, `${field}.${runtimeRef}`);
  }
  return result;
}

function plainRecord(value, field) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${field} must be an object`);
  return value;
}

function arrayValue(value, field) {
  if (!Array.isArray(value)) throw new Error(`${field} must be an array`);
  return value;
}

function assertExactKeys(record, expected, field) {
  const actual = Object.keys(record).sort();
  const canonical = [...expected].sort();
  const extra = actual.filter((key) => !canonical.includes(key));
  const missing = canonical.filter((key) => !actual.includes(key));
  if (extra.length > 0 || missing.length > 0) {
    const parts = [];
    if (missing.length > 0) parts.push(`missing ${missing.join(", ")}`);
    if (extra.length > 0) parts.push(`unknown ${extra.join(", ")}`);
    throw new Error(`${field} shape mismatch: ${parts.join("; ")}`);
  }
}

function signatureAlgorithm(value) {
  const algorithm = requiredString(value, "state.connector.package_signature_algorithm");
  if (algorithm !== "rsa-sha256") throw new Error("state.connector.package_signature_algorithm must be rsa-sha256");
  return algorithm;
}

function requiredUrl(value, field) {
  const text = requiredString(value, field);
  let parsed;
  try {
    parsed = new URL(text);
  } catch {
    throw new Error(`${field} must be a valid URL`);
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") throw new Error(`${field} must use http or https`);
  return text;
}

function booleanValue(value, field) {
  if (typeof value !== "boolean") throw new Error(`${field} must be a boolean`);
  return value;
}

function positiveInteger(value, field) {
  if (!Number.isInteger(value) || value <= 0) throw new Error(`${field} must be a positive integer`);
  return value;
}

function safePositiveInteger(value, defaultValue) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : defaultValue;
}

function parseLogLine(line) {
  try {
    const parsed = JSON.parse(line);
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      return {
        timestamp: optionalString(parsed.timestamp, "log.timestamp"),
        level: optionalString(parsed.level, "log.level") || "info",
        message: optionalString(parsed.message, "log.message"),
        metadata: parsed.metadata && typeof parsed.metadata === "object" && !Array.isArray(parsed.metadata) ? Object.fromEntries(Object.entries(parsed.metadata).map(([key, next]) => [key, String(next)])) : {},
      };
    }
  } catch {}
  return {
    timestamp: "",
    level: "info",
    message: line,
    metadata: {},
  };
}

function requiredString(value, field) {
  if (typeof value !== "string" || !value.trim()) throw new Error(`${field} is required`);
  return value;
}

function optionalString(value, field) {
  if (typeof value !== "string") throw new Error(`${field} must be a string`);
  return value;
}

module.exports = { defaultConfigDir, emptyState, redactedState, validateState, ConnectorStore };
