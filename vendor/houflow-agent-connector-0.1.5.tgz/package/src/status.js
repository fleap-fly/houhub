const { redactedState } = require("./config.js");
const { daemonStatus } = require("./daemon.js");
const { reportedLocalAgents } = require("./local-agents.js");
const { autostartStatus } = require("./autostart.js");
const { listNotifications } = require("./notifications.js");
const { listCommandLedger } = require("./command-ledger.js");

function connectorSnapshot(store, env = process.env, now = new Date()) {
  const state = store.loadState();
  const redacted = redactedState(state);
  const daemon = daemonStatus(store);
  const agents = reportedLocalAgents(state, env);
  const status = store.loadStatus();
  return {
    config_dir: store.configDir,
    log_file: store.logFile,
    notifications_file: store.notificationsFile,
    command_ledger_file: store.commandLedgerFile,
    running: daemon.running,
    pid: daemon.pid,
    status,
    connector: redacted.connector,
    reported_agents: agents,
    counts: {
      configured_agents: state.local_agents.length,
      discovered_agents: Math.max(0, agents.length - state.local_agents.length),
      reported_agents: agents.length,
      recent_commands: listCommandLedger(store, 10).length,
      dispatch_agents: agents.filter((agent) => agent.capabilities.dispatch === true).length,
      command_agents: agents.filter((agent) => agent.capabilities.lifecycle === true
        || agent.capabilities.dispatch === true
        || agent.capabilities.workspace_message === true
        || agent.capabilities.runtime_install === true
        || agent.capabilities.runtime_uninstall === true
        || agent.capabilities.skill_install === true
        || agent.capabilities.skill_uninstall === true).length,
    },
    heartbeat: heartbeatSummary(state, status, now),
    autostart: safeAutostartStatus(),
    notifications: listNotifications(store, 10),
    recent_commands: listCommandLedger(store, 5),
    state: redacted,
  };
}

function diagnoseConnector(store, env = process.env, now = new Date()) {
  const snapshot = connectorSnapshot(store, env, now);
  const checks = [
    checkStateDirectory(store),
    checkEnrollment(snapshot),
    checkDaemon(snapshot),
    checkHeartbeat(snapshot),
    checkLocalAgents(snapshot),
    checkDispatchAgents(snapshot),
    checkAutostart(snapshot),
  ];
  return {
    ok: checks.every((check) => check.status !== "error"),
    checks,
    snapshot,
  };
}

function heartbeatSummary(state, status, now) {
  if (!status?.last_heartbeat_at) {
    return { state: "missing", age_ms: null, stale: true };
  }
  const timestamp = new Date(status.last_heartbeat_at);
  if (Number.isNaN(timestamp.getTime())) {
    return { state: "invalid", age_ms: null, stale: true };
  }
  const ageMs = Math.max(0, now.getTime() - timestamp.getTime());
  return {
    state: status.status || "unknown",
    at: status.last_heartbeat_at,
    age_ms: ageMs,
    stale: ageMs > state.heartbeat_interval_ms * 3,
  };
}

function checkStateDirectory(store) {
  try {
    store.ensureDir();
    return ok("state_directory", `Writable: ${store.configDir}`);
  } catch (error) {
    return fail("state_directory", errorMessage(error), "Fix directory permissions or set HOUFLOW_AGENT_CONNECTOR_HOME.");
  }
}

function checkEnrollment(snapshot) {
  if (!snapshot.connector) {
    return fail("enrollment", "Connector is not enrolled.", "Run hou-agent-connector enroll with the Agent Hub enrollment command.");
  }
  return ok("enrollment", `Connector ${snapshot.connector.id} enrolled for ${snapshot.connector.install_target_id}.`);
}

function checkDaemon(snapshot) {
  if (!snapshot.connector) return warn("daemon", "Daemon is not required before enrollment.");
  if (!snapshot.running) return fail("daemon", "Daemon is not running.", "Run hou-agent-connector up.");
  return ok("daemon", `Daemon running with PID ${snapshot.pid}.`);
}

function checkHeartbeat(snapshot) {
  if (!snapshot.connector) return fail("heartbeat", "No enrolled connector can send heartbeat.");
  if (snapshot.status?.status === "error") {
    return fail("heartbeat", snapshot.status.last_error || "Last heartbeat failed.", "Run hou-agent-connector logs and fix the reported error.");
  }
  if (!snapshot.status?.last_heartbeat_at) {
    return warn("heartbeat", "No heartbeat has completed yet.", "Run hou-agent-connector heartbeat or wait for the daemon interval.");
  }
  if (snapshot.heartbeat.stale) {
    return fail("heartbeat", `Last heartbeat is stale: ${snapshot.status.last_heartbeat_at}.`, "Restart with hou-agent-connector down && hou-agent-connector up.");
  }
  return ok("heartbeat", `Last heartbeat at ${snapshot.status.last_heartbeat_at}.`);
}

function checkLocalAgents(snapshot) {
  if (snapshot.counts.reported_agents === 0) {
    return warn("local_agents", "No local agents are reported.", "Run hou-agent-connector local-agent discover or add a configured local agent.");
  }
  return ok("local_agents", `${snapshot.counts.reported_agents} local agent(s) reported.`);
}

function checkDispatchAgents(snapshot) {
  if (snapshot.counts.dispatch_agents === 0) {
    return warn("dispatch_agents", "No configured local agent has dispatch enabled.", "Add a local agent with --dispatch-command when it is ready for Agent Hub dispatch.");
  }
  return ok("dispatch_agents", `${snapshot.counts.dispatch_agents} dispatch-enabled local agent(s).`);
}

function checkAutostart(snapshot) {
  if (snapshot.autostart.error) return warn("autostart", snapshot.autostart.error, "Configure autostart manually or run hou-agent-connector autostart enable.");
  if (!snapshot.autostart.enabled) return warn("autostart", "Autostart is disabled.", "Run hou-agent-connector autostart enable when this host should stay connected after login.");
  return ok("autostart", "Autostart is enabled.");
}

function safeAutostartStatus() {
  try {
    return autostartStatus();
  } catch (error) {
    return { enabled: false, error: errorMessage(error) };
  }
}

function ok(name, message) {
  return { name, status: "ok", message, remediation: "" };
}

function warn(name, message, remediation = "") {
  return { name, status: "warning", message, remediation };
}

function fail(name, message, remediation = "") {
  return { name, status: "error", message, remediation };
}

function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

module.exports = { connectorSnapshot, diagnoseConnector };
