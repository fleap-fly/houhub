const { execFileSync } = require("node:child_process");

const ACTIVE_PROCESSES = new Map();
const ACTIVE_COMMAND_PROCESSES = new Map();
const ACTIVE_COMMAND_ABORTS = new Map();

function trackProcess(localAgentRef, child, commandId = "") {
  const ref = textValue(localAgentRef) || "unknown";
  const processes = ACTIVE_PROCESSES.get(ref) ?? new Set();
  processes.add(child);
  ACTIVE_PROCESSES.set(ref, processes);
  const commandRef = textValue(commandId);
  if (commandRef) {
    const commandProcesses = ACTIVE_COMMAND_PROCESSES.get(commandRef) ?? new Set();
    commandProcesses.add(child);
    ACTIVE_COMMAND_PROCESSES.set(commandRef, commandProcesses);
  }
  const remove = () => {
    processes.delete(child);
    if (processes.size === 0) ACTIVE_PROCESSES.delete(ref);
    if (commandRef) {
      const commandProcesses = ACTIVE_COMMAND_PROCESSES.get(commandRef);
      commandProcesses?.delete(child);
      if (commandProcesses && commandProcesses.size === 0) ACTIVE_COMMAND_PROCESSES.delete(commandRef);
    }
  };
  child.once("close", remove);
  child.once("error", remove);
  return child;
}

function activeProcessSnapshot(localAgentRef) {
  const processes = [...(ACTIVE_PROCESSES.get(textValue(localAgentRef)) ?? [])].filter((child) => child.exitCode === null);
  return {
    active_process_count: processes.length,
    pids: processes.map((child) => child.pid).filter((pid) => Number.isInteger(pid)),
  };
}

async function stopActiveProcesses(localAgentRef, timeoutMs = 5000) {
  const ref = textValue(localAgentRef);
  const processes = [...(ACTIVE_PROCESSES.get(ref) ?? [])].filter((child) => child.exitCode === null);
  for (const child of processes) stopProcess(child);
  await Promise.all(processes.map((child) => waitForExit(child, timeoutMs)));
  return {
    stopped: processes.length,
    active_process_count: activeProcessSnapshot(ref).active_process_count,
  };
}

async function stopCommandProcess(commandId, timeoutMs = 5000) {
  const ref = textValue(commandId);
  const aborts = [...(ACTIVE_COMMAND_ABORTS.get(ref) ?? [])];
  for (const abort of aborts) {
    try {
      abort();
    } catch {}
  }
  const processes = [...(ACTIVE_COMMAND_PROCESSES.get(ref) ?? [])].filter((child) => child.exitCode === null);
  for (const child of processes) stopProcess(child);
  await Promise.all(processes.map((child) => waitForExit(child, timeoutMs)));
  return {
    stopped: processes.length,
    active_process_count: [...(ACTIVE_COMMAND_PROCESSES.get(ref) ?? [])].filter((child) => child.exitCode === null).length,
  };
}

function registerCommandAbort(commandId, abort) {
  const ref = textValue(commandId);
  if (!ref || typeof abort !== "function") return () => {};
  const aborts = ACTIVE_COMMAND_ABORTS.get(ref) ?? new Set();
  aborts.add(abort);
  ACTIVE_COMMAND_ABORTS.set(ref, aborts);
  return () => {
    aborts.delete(abort);
    if (aborts.size === 0) ACTIVE_COMMAND_ABORTS.delete(ref);
  };
}

function stopProcess(child) {
  if (!child || child.exitCode !== null) return;
  try {
    if (process.platform === "win32" && child.pid) {
      execFileSync("taskkill", ["/F", "/T", "/PID", String(child.pid)], { stdio: "ignore", windowsHide: true });
      return;
    }
    if (child.pid) {
      try {
        process.kill(-child.pid, "SIGTERM");
      } catch {
        child.kill("SIGTERM");
      }
    }
  } catch {}
}

function waitForExit(child, timeoutMs) {
  if (!child || child.exitCode !== null) return Promise.resolve();
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      try {
        if (process.platform === "win32" && child.pid) {
          execFileSync("taskkill", ["/F", "/T", "/PID", String(child.pid)], { stdio: "ignore", windowsHide: true });
        } else if (child.pid) {
          try {
            process.kill(-child.pid, "SIGKILL");
          } catch {
            child.kill("SIGKILL");
          }
        }
      } catch {}
      resolve();
    }, timeoutMs);
    child.once("exit", () => {
      clearTimeout(timeout);
      resolve();
    });
  });
}

function textValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

module.exports = { trackProcess, activeProcessSnapshot, stopActiveProcesses, stopCommandProcess, registerCommandAbort };
