const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const SERVICE_LABEL = "com.houflow.agent-connector";
const SERVICE_NAME = "houflow-agent-connector";

function enableAutostart(store, cliPath) {
  if (process.platform === "darwin") return enableLaunchd(store, cliPath);
  if (process.platform === "linux") return enableSystemd(store, cliPath);
  if (process.platform === "win32") return enableWindowsTask(cliPath, store);
  throw new Error(`autostart is not supported on ${process.platform}`);
}

function disableAutostart() {
  if (process.platform === "darwin") return disableLaunchd();
  if (process.platform === "linux") return disableSystemd();
  if (process.platform === "win32") return disableWindowsTask();
  throw new Error(`autostart is not supported on ${process.platform}`);
}

function autostartStatus() {
  if (process.platform === "darwin") {
    return { enabled: fs.existsSync(path.join(os.homedir(), "Library", "LaunchAgents", `${SERVICE_LABEL}.plist`)) };
  }
  if (process.platform === "linux") {
    return { enabled: fs.existsSync(path.join(os.homedir(), ".config", "systemd", "user", `${SERVICE_NAME}.service`)) };
  }
  if (process.platform === "win32") {
    try {
      execFileSync("schtasks", ["/Query", "/TN", "Houflow Agent Connector"], { stdio: "ignore", windowsHide: true });
      return { enabled: true };
    } catch {
      return { enabled: false };
    }
  }
  return { enabled: false };
}

function enableLaunchd(store, cliPath) {
  const plistDir = path.join(os.homedir(), "Library", "LaunchAgents");
  fs.mkdirSync(plistDir, { recursive: true });
  const plistPath = path.join(plistDir, `${SERVICE_LABEL}.plist`);
  const plist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${SERVICE_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${escapeXml(process.execPath)}</string>
    <string>${escapeXml(cliPath)}</string>
    <string>up</string>
    <string>--foreground</string>
    <string>--config</string>
    <string>${escapeXml(store.configDir)}</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>${escapeXml(store.logFile)}</string>
  <key>StandardErrorPath</key>
  <string>${escapeXml(store.logFile)}</string>
</dict>
</plist>`;
  fs.writeFileSync(plistPath, plist, "utf8");
  try {
    execFileSync("launchctl", ["unload", plistPath], { stdio: "ignore" });
  } catch {}
  execFileSync("launchctl", ["load", "-w", plistPath], { stdio: "ignore" });
  return { enabled: true, path: plistPath };
}

function disableLaunchd() {
  const plistPath = path.join(os.homedir(), "Library", "LaunchAgents", `${SERVICE_LABEL}.plist`);
  if (fs.existsSync(plistPath)) {
    try {
      execFileSync("launchctl", ["unload", plistPath], { stdio: "ignore" });
    } catch {}
    fs.unlinkSync(plistPath);
  }
  return { enabled: false };
}

function enableSystemd(store, cliPath) {
  const unitDir = path.join(os.homedir(), ".config", "systemd", "user");
  fs.mkdirSync(unitDir, { recursive: true });
  const unitPath = path.join(unitDir, `${SERVICE_NAME}.service`);
  const unit = `[Unit]
Description=Houflow Agent Connector
After=network.target

[Service]
Type=simple
ExecStart=${systemdQuote(process.execPath)} ${systemdQuote(cliPath)} up --foreground --config ${systemdQuote(store.configDir)}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=default.target
`;
  fs.writeFileSync(unitPath, unit, "utf8");
  execFileSync("systemctl", ["--user", "daemon-reload"], { stdio: "ignore" });
  execFileSync("systemctl", ["--user", "enable", "--now", `${SERVICE_NAME}.service`], { stdio: "ignore" });
  return { enabled: true, path: unitPath };
}

function disableSystemd() {
  const unitPath = path.join(os.homedir(), ".config", "systemd", "user", `${SERVICE_NAME}.service`);
  try {
    execFileSync("systemctl", ["--user", "disable", "--now", `${SERVICE_NAME}.service`], { stdio: "ignore" });
  } catch {}
  if (fs.existsSync(unitPath)) fs.unlinkSync(unitPath);
  return { enabled: false };
}

function enableWindowsTask(cliPath, store) {
  execFileSync("schtasks", [
    "/Create",
    "/SC",
    "ONLOGON",
    "/TN",
    "Houflow Agent Connector",
    "/TR",
    `"${process.execPath}" "${cliPath}" up --foreground --config "${store.configDir}"`,
    "/F",
  ], { stdio: "ignore", windowsHide: true });
  return { enabled: true, method: "Task Scheduler" };
}

function disableWindowsTask() {
  try {
    execFileSync("schtasks", ["/Delete", "/TN", "Houflow Agent Connector", "/F"], { stdio: "ignore", windowsHide: true });
  } catch {}
  return { enabled: false };
}

function escapeXml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function systemdQuote(value) {
  return `"${String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}

module.exports = { enableAutostart, disableAutostart, autostartStatus };
