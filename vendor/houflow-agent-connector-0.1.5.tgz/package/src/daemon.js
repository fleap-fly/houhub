const fs = require("node:fs");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { heartbeatOnce } = require("./heartbeat.js");
const { appendNotification } = require("./notifications.js");
const { reportedLocalAgents } = require("./local-agents.js");
const { pollAndRunCommand } = require("./commands.js");
const { stopActiveProcesses } = require("./process-manager.js");

function createDaemonController(store, env = process.env) {
  let stopping = false;
  const runningCommands = new Map();
  return {
    stop() {
      stopping = true;
    },
    async run() {
      store.ensureDir();
      if (!store.loadState().connector) throw new Error("connector is not enrolled; run hou-agent-connector enroll first");
      store.writePid(process.pid);
      store.appendLog("info", "Connector daemon started", { pid: String(process.pid) });
      try {
        while (!stopping) {
          const state = store.loadState();
          try {
            await heartbeatOnce(store);
            const command = await pollAndRunCommand(store, env, {
              background: true,
              onComplete: (completed) => runningCommands.delete(completed.id),
            });
            if (command && command.status !== "cancelled") runningCommands.set(command.id, command);
          } catch (error) {
            const previousStatus = store.loadStatus();
            const message = error instanceof Error ? error.message : String(error);
            const status = error?.status === 410 ? "revoked" : error?.status === 401 ? "auth_error" : "error";
            if (status === "revoked") {
              store.updateState((current) => ({ ...current, connector: null }));
            }
            store.appendLog("error", "Heartbeat failed", { error: message });
            store.saveStatus({
              status,
              connector_id: state.connector?.id || null,
              reported_agent_count: reportedLocalAgents(state).length,
              last_heartbeat_at: previousStatus?.last_heartbeat_at || null,
              last_error: message,
              updated_at: new Date().toISOString(),
            });
            if (previousStatus?.status !== "error") {
              appendNotification(store, {
                type: "connector_error",
                level: "error",
                title: "Connector heartbeat failed",
                message,
                metadata: { connector_id: state.connector?.id || "" },
              });
            }
            if (status === "revoked" || status === "auth_error") stopping = true;
          }
          await sleep(state.heartbeat_interval_ms);
        }
      } finally {
        await Promise.allSettled([...runningCommands.values()].map((command) => {
          store.appendLog("warning", "Connector daemon stopped while command was still running", { command_id: command.id });
          return stopActiveProcesses(command.local_agent_ref);
        }));
        store.removePid(process.pid);
        store.appendLog("info", "Connector daemon stopped", { pid: String(process.pid) });
        appendNotification(store, {
          type: "daemon_stopped",
          level: "info",
          title: "Connector daemon stopped",
          message: `Connector daemon process ${process.pid} stopped.`,
          metadata: { pid: String(process.pid) },
        });
      }
    },
  };
}

async function runForegroundDaemon(store) {
  let stopping = false;
  const controller = createDaemonController(store, process.env);
  const stop = () => {
    stopping = true;
    controller.stop();
  };
  process.once("SIGINT", stop);
  process.once("SIGTERM", stop);
  try {
    await controller.run();
  } finally {
    if (!stopping) controller.stop();
  }
}

function startDaemon(store, cliPath, extraArgs = []) {
  const existingPid = store.readPid();
  if (existingPid && isProcessAlive(existingPid)) {
    return { started: false, pid: existingPid };
  }
  store.ensureDir();
  const logFd = fs.openSync(store.logFile, "a");
  const child = spawn(process.execPath, [cliPath, "up", "--foreground", ...extraArgs], {
    detached: true,
    stdio: ["ignore", logFd, logFd],
    cwd: store.configDir,
    windowsHide: true,
  });
  child.unref();
  store.writePid(child.pid);
  store.appendLog("info", "Connector daemon spawned", { pid: String(child.pid) });
  setTimeout(() => {
    try {
      fs.closeSync(logFd);
    } catch {}
  }, 1000);
  return { started: true, pid: child.pid };
}

function stopDaemon(store) {
  const pid = store.readPid();
  if (!pid) return { stopped: false, pid: null };
  if (isProcessAlive(pid)) {
    process.kill(pid, "SIGTERM");
  }
  store.removePid(pid);
  store.appendLog("info", "Connector daemon stop requested", { pid: String(pid) });
  appendNotification(store, {
    type: "daemon_stop_requested",
    level: "info",
    title: "Connector daemon stop requested",
    message: `Stop signal sent to connector daemon process ${pid}.`,
    metadata: { pid: String(pid) },
  });
  return { stopped: true, pid };
}

function daemonStatus(store) {
  const pid = store.readPid();
  return {
    running: Boolean(pid && isProcessAlive(pid)),
    pid,
    status: store.loadStatus(),
  };
}

function isProcessAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { createDaemonController, runForegroundDaemon, startDaemon, stopDaemon, daemonStatus };
