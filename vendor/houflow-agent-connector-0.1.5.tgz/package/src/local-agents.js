const { providerRunnerAvailable } = require("./provider-runner.js");
const { discoverRuntimeProviders, getRuntimeProvider, runtimeProviderReadiness } = require("./runtime-registry.js");

const EMPTY_COMMANDS = Object.freeze({
  dispatch_command: "",
  workspace_message_command: "",
  lifecycle_command: "",
  runtime_install_command: "",
  runtime_uninstall_command: "",
  skill_install_command: "",
  skill_uninstall_command: "",
});

function reportedLocalAgents(state, env = process.env) {
  const configured = state.local_agents.map((agent) => ({
    local_agent_ref: agent.local_agent_ref,
    name: agent.name,
    provider: agent.provider,
    status: "available",
    capabilities: effectiveCapabilities(agent),
    metadata: {
      ...agent.metadata,
      source: "configured",
      ...(agent.workspace_ref ? workspaceMetadata(agent.workspace_ref, state) : {}),
      ...(agent.runtime_provider ? { runtime_provider: agent.runtime_provider } : {}),
      ...(agent.runtime_runner ? { runtime_runner: "true" } : {}),
      ...(agent.runtime_provider ? runtimeMetadata(agent.runtime_provider, state, env, agent.runtime_runner === true) : {}),
      execution_mode: agent.runtime_runner === true ? "built_in_runner" : agent.capabilities?.dispatch ? "custom_command" : "not_configured",
    },
  }));
  const seen = new Set(configured.map((agent) => agent.local_agent_ref));
  const discovered = discoverCliAgents(env, state)
    .filter((agent) => !seen.has(agent.local_agent_ref))
    .map((agent) => ({
      local_agent_ref: agent.local_agent_ref,
      name: agent.name,
      provider: agent.provider,
      status: "available",
      capabilities: discoveredCapabilities(agent),
      metadata: {
        source: "cli_discovery",
        binary: agent.binary,
        runtime_provider: agent.id,
        ...(agent.runner ? { runtime_runner: "true" } : {}),
        ...runtimeMetadata(agent.id, state, env, Boolean(agent.runner)),
        execution_mode: agent.runner ? "built_in_runner" : "needs_dispatch_command",
      },
    }));
  return [...configured, ...discovered];
}

function resolveLocalAgent(state, localAgentRef, env = process.env) {
  const ref = requiredText(localAgentRef, "local agent ref");
  const configured = state.local_agents.find((agent) => agent.local_agent_ref === ref);
  if (configured) return configured;
  const discovered = discoverCliAgents(env, state).find((agent) => agent.local_agent_ref === ref);
  if (!discovered?.runner) return null;
  return discoveredLocalAgent(discovered);
}

function discoverCliAgents(env = process.env, state = null) {
  return discoverRuntimeProviders(env, state).map((runtime) => ({
    id: runtime.id,
    provider: runtime.provider,
    name: runtime.label,
    binary: runtime.binary,
    ready: runtime.readiness?.ready === true,
    runner: runtime.runner,
    local_agent_ref: runtime.local_agent_ref,
  }));
}

function discoveredCapabilities(agent) {
  const runner = Boolean(agent.runner);
  const runtimeProviderProjection = Boolean(agent.runner?.requires_runtime_provider_projection);
  return {
    lifecycle: runner,
    dispatch: runner,
    workspace_message: runner,
    runtime_install: false,
    runtime_uninstall: false,
    skill_install: false,
    skill_uninstall: false,
    log_tail: false,
    artifact_upload: false,
    runtime_provider_projection: runtimeProviderProjection,
  };
}

function discoveredLocalAgent(agent) {
  const capabilities = discoveredCapabilities(agent);
  return {
    local_agent_ref: agent.local_agent_ref,
    name: agent.name,
    provider: agent.provider,
    runtime_provider: agent.id,
    runtime_runner: true,
    ...EMPTY_COMMANDS,
    working_directory: "",
    skills_directory: "",
    capabilities,
    metadata: {
      source: "cli_discovery",
      binary: agent.binary,
      runtime_provider: agent.id,
      runtime_runner: "true",
      execution_mode: "built_in_runner",
    },
  };
}

function runtimeMetadata(runtimeProvider, state, env, runtimeRunner) {
  const readiness = runtimeProviderReadiness(runtimeProvider, env, state);
  return {
    runtime_installed: readiness.installed ? "true" : "false",
    runtime_ready: readiness.ready ? "true" : "false",
    runtime_binary_path: readiness.binary_path || "",
    runtime_version: readiness.version || "",
    runtime_ready_message: readiness.message || "",
    runtime_auth_mode: readiness.auth_mode || "",
    runtime_login_command: readiness.login_command || "",
    runtime_execution_mode: runtimeRunner ? "built_in_runner" : readiness.execution_mode || "unavailable",
    runtime_missing_env: (readiness.missing_env || []).join(","),
    runtime_saved_env_keys: (readiness.saved_env_keys || []).join(","),
  };
}

function workspaceMetadata(workspaceRef, state) {
  const workspace = state.workspaces.find((item) => item.workspace_ref === workspaceRef);
  if (!workspace) {
    return { workspace_ref: workspaceRef, workspace_status: "missing" };
  }
  return {
    workspace_ref: workspace.workspace_ref,
    workspace_status: "connected",
    workspace_name: workspace.name,
    workspace_url: workspace.url,
    workspace_channel_ref: workspace.channel_ref,
  };
}

function addLocalAgent(state, params) {
  const runtimeProvider = runtimeProviderValue(params.runtimeProvider);
  const runtimeRunner = booleanValue(params.runtimeRunner);
  assertRuntimeRunner(runtimeProvider, runtimeRunner);
  assertNoDuplicateExecutionPath("runtime_install", runtimeProvider, params.runtimeInstallCommand);
  assertNoDuplicateExecutionPath("runtime_uninstall", runtimeProvider, params.runtimeUninstallCommand);
  assertNoDuplicateExecutionPath("skill_install", params.skillsDirectory, params.skillInstallCommand);
  assertNoDuplicateExecutionPath("skill_uninstall", params.skillsDirectory, params.skillUninstallCommand);
  assertNoDuplicateExecutionPath("dispatch", runtimeRunner ? "runtime_runner" : "", params.dispatchCommand);
  assertNoDuplicateExecutionPath("workspace_message", runtimeRunner ? "runtime_runner" : "", params.workspaceMessageCommand);
  assertNoDuplicateExecutionPath("lifecycle", runtimeRunner ? "runtime_runner" : "", params.lifecycleCommand);
  const localAgent = {
    local_agent_ref: requiredText(params.localAgentRef, "local agent ref"),
    provider: requiredText(params.provider, "provider"),
    name: requiredText(params.name, "name"),
    runtime_provider: runtimeProvider,
    runtime_runner: runtimeRunner,
    dispatch_command: textValue(params.dispatchCommand),
    workspace_message_command: textValue(params.workspaceMessageCommand),
    lifecycle_command: textValue(params.lifecycleCommand),
    runtime_install_command: textValue(params.runtimeInstallCommand),
    runtime_uninstall_command: textValue(params.runtimeUninstallCommand),
    skill_install_command: textValue(params.skillInstallCommand),
    skill_uninstall_command: textValue(params.skillUninstallCommand),
    working_directory: textValue(params.workingDirectory),
    skills_directory: textValue(params.skillsDirectory),
    workspace_ref: textValue(params.workspaceRef),
    capabilities: capabilitiesFromParams(params),
    metadata: metadataFromParams(params.metadata),
  };
  return {
    ...state,
    local_agents: [
      ...state.local_agents.filter((agent) => agent.local_agent_ref !== localAgent.local_agent_ref),
      localAgent,
    ],
  };
}

function removeLocalAgent(state, localAgentRef) {
  const ref = requiredText(localAgentRef, "local agent ref");
  return {
    ...state,
    local_agents: state.local_agents.filter((agent) => agent.local_agent_ref !== ref),
  };
}

function capabilitiesFromParams(params) {
  const explicit = new Set(String(params.capabilities || "").split(",").map((item) => item.trim()).filter(Boolean));
  const runtimeRunner = booleanValue(params.runtimeRunner);
  const runner = runtimeRunner ? getRuntimeProvider(textValue(params.runtimeProvider))?.runner : null;
  const capabilities = {
    lifecycle: explicit.has("lifecycle"),
    dispatch: explicit.has("dispatch") || Boolean(textValue(params.dispatchCommand)) || booleanValue(params.runtimeRunner),
    workspace_message: explicit.has("workspace_message") || Boolean(textValue(params.workspaceMessageCommand)) || booleanValue(params.runtimeRunner),
    runtime_install: explicit.has("runtime_install") || Boolean(textValue(params.runtimeInstallCommand)) || Boolean(textValue(params.runtimeProvider)),
    runtime_uninstall: explicit.has("runtime_uninstall") || Boolean(textValue(params.runtimeUninstallCommand)) || Boolean(textValue(params.runtimeProvider)),
    skill_install: explicit.has("skill_install") || Boolean(textValue(params.skillInstallCommand)) || Boolean(textValue(params.skillsDirectory)),
    skill_uninstall: explicit.has("skill_uninstall") || Boolean(textValue(params.skillUninstallCommand)) || Boolean(textValue(params.skillsDirectory)),
    log_tail: explicit.has("log_tail"),
    artifact_upload: explicit.has("artifact_upload"),
    runtime_provider_projection: runtimeRunner ? Boolean(runner?.requires_runtime_provider_projection) : explicit.has("runtime_provider_projection"),
  };
  capabilities.lifecycle = capabilities.lifecycle || Boolean(textValue(params.lifecycleCommand)) || booleanValue(params.runtimeRunner);
  return capabilities;
}

function effectiveCapabilities(agent) {
  const capabilities = { ...agent.capabilities };
  if (agent.runtime_runner === true) {
    const runner = getRuntimeProvider(agent.runtime_provider)?.runner;
    capabilities.lifecycle = true;
    capabilities.dispatch = true;
    capabilities.workspace_message = true;
    capabilities.runtime_provider_projection = Boolean(runner?.requires_runtime_provider_projection);
  }
  return capabilities;
}

function runtimeProviderValue(value) {
  const runtimeProvider = textValue(value);
  if (!runtimeProvider) return "";
  if (!getRuntimeProvider(runtimeProvider)) throw new Error(`runtime provider is not in the connector registry: ${runtimeProvider}`);
  return runtimeProvider;
}

function assertRuntimeRunner(runtimeProvider, runtimeRunner) {
  if (!runtimeRunner) return;
  if (!runtimeProvider) throw new Error("runtime_runner requires runtime_provider");
  if (!providerRunnerAvailable(runtimeProvider)) {
    throw new Error(`runtime provider does not define a connector runner: ${runtimeProvider}`);
  }
}

function assertNoDuplicateExecutionPath(action, builtInValue, commandValue) {
  if (textValue(builtInValue) && textValue(commandValue)) {
    throw new Error(`${action} must use either a connector-managed path or a custom command, not both`);
  }
}

function metadataFromParams(value) {
  if (!value) return {};
  if (typeof value === "object" && !Array.isArray(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, next]) => [key, String(next)]));
  }
  return {};
}

function requiredText(value, field) {
  const text = textValue(value);
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function textValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function booleanValue(value) {
  return value === true || value === "true";
}

module.exports = { reportedLocalAgents, resolveLocalAgent, discoverCliAgents, addLocalAgent, removeLocalAgent };
