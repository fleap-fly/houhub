const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");

const DEFAULT_NOTIFICATION_LIMIT = 50;

function appendNotification(store, event) {
  store.ensureDir();
  const record = normalizeNotification(event);
  fs.appendFileSync(store.notificationsFile, `${JSON.stringify(record)}\n`, { mode: 0o600 });
  return record;
}

function listNotifications(store, limit = DEFAULT_NOTIFICATION_LIMIT) {
  if (!fs.existsSync(store.notificationsFile)) return [];
  const lines = fs.readFileSync(store.notificationsFile, "utf8").split(/\r?\n/).filter(Boolean);
  return lines
    .slice(-positiveInteger(limit, DEFAULT_NOTIFICATION_LIMIT))
    .map((line) => JSON.parse(line));
}

function clearNotifications(store) {
  store.ensureDir();
  fs.writeFileSync(store.notificationsFile, "", { mode: 0o600 });
  return { cleared: true };
}

function sendDesktopNotification({ title, message }, env = process.env) {
  const normalizedTitle = requiredText(title, "notification title");
  const normalizedMessage = requiredText(message, "notification message");
  if (process.platform === "darwin") {
    const osascript = findBinary("osascript", env);
    if (!osascript) throw new Error("desktop notifications require osascript on macOS");
    execFileSync(osascript, [
      "-e",
      `display notification ${appleScriptString(normalizedMessage)} with title ${appleScriptString(normalizedTitle)}`,
    ], { stdio: "ignore" });
    return { sent: true, provider: "osascript" };
  }
  if (process.platform === "linux") {
    const notifySend = findBinary("notify-send", env);
    if (!notifySend) throw new Error("desktop notifications require notify-send on Linux");
    execFileSync(notifySend, [normalizedTitle, normalizedMessage], { stdio: "ignore" });
    return { sent: true, provider: "notify-send" };
  }
  if (process.platform === "win32") {
    const powershell = findBinary("powershell.exe", env) || findBinary("powershell", env);
    if (!powershell) throw new Error("desktop notifications require PowerShell on Windows");
    execFileSync(powershell, [
      "-NoProfile",
      "-Command",
      `[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null;` +
        `$template = [Windows.UI.Notifications.ToastTemplateType]::ToastText02;` +
        `$xml = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent($template);` +
        `$texts = $xml.GetElementsByTagName("text");` +
        `$texts.Item(0).AppendChild($xml.CreateTextNode(${powerShellString(normalizedTitle)})) > $null;` +
        `$texts.Item(1).AppendChild($xml.CreateTextNode(${powerShellString(normalizedMessage)})) > $null;` +
        `$toast = [Windows.UI.Notifications.ToastNotification]::new($xml);` +
        `[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("Houflow Agent Connector").Show($toast);`,
    ], { stdio: "ignore", windowsHide: true });
    return { sent: true, provider: "powershell" };
  }
  throw new Error(`desktop notifications are not supported on ${process.platform}`);
}

function normalizeNotification(event) {
  return {
    id: event.id || `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`,
    type: requiredText(event.type, "notification type"),
    level: levelValue(event.level),
    title: requiredText(event.title, "notification title"),
    message: requiredText(event.message, "notification message"),
    created_at: event.created_at || new Date().toISOString(),
    metadata: metadataValue(event.metadata),
  };
}

function findBinary(binary, env) {
  const pathValue = env.PATH || "";
  const extensions = process.platform === "win32" ? ["", ".exe", ".cmd", ".bat"] : [""];
  for (const dir of pathValue.split(path.delimiter).filter(Boolean)) {
    for (const ext of extensions) {
      const candidate = path.join(dir, `${binary}${ext}`);
      try {
        if (fs.statSync(candidate).isFile()) return candidate;
      } catch {}
    }
  }
  return null;
}

function appleScriptString(value) {
  return `"${String(value).replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}

function powerShellString(value) {
  return `'${String(value).replace(/'/g, "''")}'`;
}

function levelValue(value) {
  if (value === "info" || value === "warning" || value === "error") return value;
  return "info";
}

function metadataValue(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(Object.entries(value).map(([key, next]) => [key, String(next)]));
}

function positiveInteger(value, defaultValue) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : defaultValue;
}

function requiredText(value, field) {
  const text = typeof value === "string" && value.trim() ? value.trim() : "";
  if (!text) throw new Error(`${field} is required`);
  return text;
}

module.exports = { appendNotification, listNotifications, clearNotifications, sendDesktopNotification };
