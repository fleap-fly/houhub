const { spawn } = require("node:child_process");
const os = require("node:os");
const { AgentHubClient } = require("./agent-hub-client.js");
const { aggregateCapabilities, hostInfo } = require("./heartbeat.js");
const { reportedLocalAgents } = require("./local-agents.js");
const { appendNotification } = require("./notifications.js");

async function loginConnector(store, params = {}, hooks = {}) {
  const controlUrl = requiredString(params.controlUrl, "control URL");
  const platform = stringValue(params.platform) || currentPlatform();
  const arch = stringValue(params.arch) || currentArch();
  const client = new AgentHubClient(controlUrl);
  const login = await client.startLogin({
    name: stringValue(params.name),
    platform,
    arch,
    install_target_id: stringValue(params.installTargetId),
    connector_version: stringValue(params.connectorVersion),
    console_url: stringValue(params.consoleUrl),
    host: hostInfo(),
    metadata: { source: "houflow_agent_connector_login" },
  });
  if (!login.device_code) throw new Error("Agent Hub login response did not include device_code");
  if (!login.verification_uri_complete) throw new Error("Agent Hub login response did not include verification_uri_complete");
  hooks.onStarted?.(login);
  if (params.openBrowser !== false) {
    const opened = openBrowser(login.verification_uri_complete, hooks.onBrowserError);
    hooks.onBrowserOpened?.(opened);
  }
  const connector = await pollUntilApproved(store, client, login, params, hooks);
  return { login, connector };
}

function saveLoginConnector(store, controlUrl, login, connector) {
  if (!connector.connector_token) throw new Error("Agent Hub login poll response did not include connector_token");
  const installTarget = login.install_target || {};
  const now = new Date().toISOString();
  const nextState = store.updateState((state) => ({
    ...state,
    connector: {
      control_url: controlUrl,
      id: connector.id,
      token: connector.connector_token,
      token_prefix: connector.token_prefix || connector.connector_token.slice(0, 12),
      install_target_id: connector.install_target_id || login.install_target_id,
      platform: connector.platform || login.platform,
      package_ref: connector.package_ref || installTarget.package_ref,
      package_sha256: connector.package_sha256 || installTarget.package_sha256,
      package_signature_ref: connector.package_signature_ref || installTarget.package_signature_ref,
      package_signature_sha256: connector.package_signature_sha256 || installTarget.package_signature_sha256,
      package_signature_algorithm: connector.package_signature_algorithm || installTarget.package_signature_algorithm || "rsa-sha256",
      connector_version: connector.connector_version || login.connector_version || installTarget.version,
      claimed_at: now,
    },
  }));
  store.saveStatus({
    status: "claimed",
    connector_id: connector.id,
    reported_agent_count: reportedLocalAgents(nextState).length,
    last_heartbeat_at: null,
    last_error: null,
    updated_at: now,
  });
  store.appendLog("info", "Connector browser login claimed", { connector_id: connector.id, login_id: login.id });
  appendNotification(store, {
    type: "connector_enrolled",
    level: "info",
    title: "Connector enrolled",
    message: `Connector ${connector.id} is enrolled with Agent Hub.`,
    created_at: now,
    metadata: { connector_id: connector.id, login_id: login.id },
  });
  return nextState;
}

async function pollUntilApproved(store, client, login, params, hooks) {
  const timeoutSeconds = positiveInteger(params.timeoutSeconds, 300);
  const intervalSeconds = positiveInteger(params.intervalSeconds, login.interval_seconds || 2);
  const deadline = Date.now() + timeoutSeconds * 1000;
  let lastStatus = "";
  while (Date.now() <= deadline) {
    const state = store.loadState();
    const agents = reportedLocalAgents(state);
    const response = await client.pollLogin({
      device_code: login.device_code,
      connector_version: stringValue(params.connectorVersion) || login.connector_version || login.install_target?.version,
      name: stringValue(params.name) || login.name,
      host: hostInfo(),
      capabilities: aggregateCapabilities(agents),
      reported_agents: agents,
      metadata: { source: "houflow_agent_connector_login" },
    });
    if (response.status !== lastStatus) {
      lastStatus = response.status;
      hooks.onPoll?.(response);
    }
    if (response.connector) {
      const nextState = saveLoginConnector(store, client.controlUrl, login, response.connector);
      return { ...response.connector, state: nextState };
    }
    if (response.status === "expired" || response.status === "revoked") {
      throw new Error(`connector login ${response.status}`);
    }
    await sleep(intervalSeconds * 1000);
  }
  throw new Error("connector login timed out waiting for browser approval");
}

function openBrowser(url, onError) {
  const command = browserCommand();
  if (!command) return false;
  try {
    const child = spawn(command.command, [...command.args, url], {
      detached: true,
      stdio: "ignore",
      shell: command.shell,
    });
    child.on("error", (error) => onError?.(error));
    child.unref();
    return true;
  } catch (error) {
    onError?.(error);
    return false;
  }
}

function browserCommand() {
  if (process.platform === "darwin") return { command: "open", args: [], shell: false };
  if (process.platform === "win32") return { command: "cmd", args: ["/c", "start", ""], shell: false };
  return { command: "xdg-open", args: [], shell: false };
}

function currentPlatform() {
  if (process.platform === "darwin") return "macos";
  if (process.platform === "win32") return "windows";
  return "linux";
}

function currentArch() {
  const arch = os.arch();
  if (arch === "x64") return "x64";
  if (arch === "arm64") return "arm64";
  return arch;
}

function requiredString(value, field) {
  const text = stringValue(value);
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function stringValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function positiveInteger(value, fallback) {
  if (value === undefined || value === null || value === "") return fallback;
  const parsed = Number(value);
  if (Number.isFinite(parsed) && parsed > 0) return Math.floor(parsed);
  return fallback;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { loginConnector, saveLoginConnector, openBrowser };
