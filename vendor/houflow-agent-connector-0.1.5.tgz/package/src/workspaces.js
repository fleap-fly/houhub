function listWorkspaces(state) {
  return [...state.workspaces].sort((left, right) => left.name.localeCompare(right.name));
}

function addWorkspace(state, params) {
  const workspace = {
    workspace_ref: requiredText(params.workspaceRef, "workspaceRef"),
    name: requiredText(params.name, "name"),
    url: requiredUrl(params.url, "url"),
    token: requiredText(params.token, "token"),
    channel_ref: requiredText(params.channelRef, "channelRef"),
    connected_at: new Date().toISOString(),
    metadata: metadataFromParams(params.metadata),
  };
  return {
    ...state,
    workspaces: [
      ...state.workspaces.filter((item) => item.workspace_ref !== workspace.workspace_ref),
      workspace,
    ],
  };
}

function removeWorkspace(state, workspaceRef) {
  const ref = requiredText(workspaceRef, "workspaceRef");
  const exists = state.workspaces.some((workspace) => workspace.workspace_ref === ref);
  if (!exists) throw new Error(`workspace is not configured: ${ref}`);
  return {
    ...state,
    workspaces: state.workspaces.filter((workspace) => workspace.workspace_ref !== ref),
    local_agents: state.local_agents.map((agent) => agent.workspace_ref === ref ? { ...agent, workspace_ref: "" } : agent),
  };
}

function bindLocalAgentWorkspace(state, localAgentRef, workspaceRef) {
  const agentRef = requiredText(localAgentRef, "localAgentRef");
  const ref = requiredText(workspaceRef, "workspaceRef");
  if (!state.workspaces.some((workspace) => workspace.workspace_ref === ref)) {
    throw new Error(`workspace is not configured: ${ref}`);
  }
  let updated = false;
  const localAgents = state.local_agents.map((agent) => {
    if (agent.local_agent_ref !== agentRef) return agent;
    updated = true;
    return { ...agent, workspace_ref: ref };
  });
  if (!updated) throw new Error(`local agent is not configured: ${agentRef}`);
  return { ...state, local_agents: localAgents };
}

function unbindLocalAgentWorkspace(state, localAgentRef) {
  const agentRef = requiredText(localAgentRef, "localAgentRef");
  let updated = false;
  const localAgents = state.local_agents.map((agent) => {
    if (agent.local_agent_ref !== agentRef) return agent;
    updated = true;
    return { ...agent, workspace_ref: "" };
  });
  if (!updated) throw new Error(`local agent is not configured: ${agentRef}`);
  return { ...state, local_agents: localAgents };
}

function requiredUrl(value, field) {
  const text = requiredText(value, field);
  let parsed;
  try {
    parsed = new URL(text);
  } catch {
    throw new Error(`${field} must be a valid URL`);
  }
  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new Error(`${field} must use http or https`);
  }
  return parsed.toString();
}

function requiredText(value, field) {
  const text = typeof value === "string" && value.trim() ? value.trim() : "";
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function metadataFromParams(value) {
  if (!value) return {};
  if (typeof value === "object" && !Array.isArray(value)) {
    return Object.fromEntries(Object.entries(value).map(([key, next]) => [key, String(next)]));
  }
  return {};
}

module.exports = { listWorkspaces, addWorkspace, removeWorkspace, bindLocalAgentWorkspace, unbindLocalAgentWorkspace };
