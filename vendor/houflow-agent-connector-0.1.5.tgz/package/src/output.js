function createReporter(io, flags = {}) {
  const json = wantsJson(io, flags);
  return {
    json,
    write(value) {
      if (json) writeJson(io.stdout, value);
    },
    line(message = "") {
      if (!json) io.stdout.write(`${message}\n`);
    },
    step(index, total, label, detail = "") {
      if (!json) {
        const suffix = detail ? ` - ${detail}` : "";
        io.stdout.write(`[${index}/${total}] ${label}${suffix}\n`);
      }
    },
    table(headers, rows) {
      if (json) return;
      writeTable(io.stdout, headers, rows);
    },
  };
}

function wantsJson(io, flags = {}) {
  if (flags.json === true || flags.output === "json") return true;
  if (flags.human === true || flags.output === "human") return false;
  return io.stdout?.isTTY !== true;
}

function writeJson(stream, value) {
  stream.write(`${JSON.stringify(value, null, 2)}\n`);
}

function writeTable(stream, headers, rows) {
  const normalizedRows = rows.map((row) => row.map((value) => String(value ?? "")));
  const widths = headers.map((header, index) => Math.max(
    String(header).length,
    ...normalizedRows.map((row) => row[index]?.length || 0),
  ));
  stream.write(`${headers.map((header, index) => String(header).padEnd(widths[index])).join("  ")}\n`);
  stream.write(`${widths.map((width) => "-".repeat(width)).join("  ")}\n`);
  for (const row of normalizedRows) {
    stream.write(`${row.map((value, index) => value.padEnd(widths[index])).join("  ")}\n`);
  }
}

function formatAge(isoValue, now = new Date()) {
  if (!isoValue) return "never";
  const then = new Date(isoValue);
  if (Number.isNaN(then.getTime())) return "invalid";
  const seconds = Math.max(0, Math.floor((now.getTime() - then.getTime()) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 48) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function clearScreen(stream) {
  stream.write("\x1Bc");
}

module.exports = { createReporter, wantsJson, writeJson, writeTable, formatAge, clearScreen };
