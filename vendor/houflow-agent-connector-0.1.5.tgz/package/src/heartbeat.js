const os = require("node:os");
const { AgentHubClient } = require("./agent-hub-client.js");
const { reportedLocalAgents } = require("./local-agents.js");
const { appendNotification } = require("./notifications.js");

async function claimEnrollment(store, params) {
  const controlUrl = requiredString(params.controlUrl, "control URL");
  const installTargetId = requiredString(params.installTargetId, "install target id");
  const platform = requiredString(params.platform, "platform");
  const packageRef = requiredString(params.packageRef, "package ref");
  const packageSha256 = requiredString(params.packageSha256, "package sha256");
  const packageSignatureRef = requiredString(params.packageSignatureRef, "package signature ref");
  const packageSignatureSha256 = requiredString(params.packageSignatureSha256, "package signature sha256");
  const packageSignatureAlgorithm = requiredString(params.packageSignatureAlgorithm, "package signature algorithm");
  const connectorVersion = requiredString(params.connectorVersion, "connector version");
  const client = new AgentHubClient(controlUrl);
  const body = {
    enrollment_token: requiredString(params.token, "enrollment token"),
    install_target_id: installTargetId,
    platform,
    package_ref: packageRef,
    package_sha256: packageSha256,
    package_signature_ref: packageSignatureRef,
    package_signature_sha256: packageSignatureSha256,
    package_signature_algorithm: packageSignatureAlgorithm,
    connector_version: connectorVersion,
    name: stringValue(params.name),
    host: hostInfo(),
    capabilities: aggregateCapabilities(reportedLocalAgents(store.loadState())),
    reported_agents: reportedLocalAgents(store.loadState()),
    metadata: { source: "houflow_agent_connector" },
  };
  const connector = await client.claim(body);
  if (!connector.connector_token) {
    throw new Error("Agent Hub claim response did not include connector_token");
  }
  const now = new Date().toISOString();
  const nextState = store.updateState((state) => ({
    ...state,
    connector: {
      control_url: controlUrl,
      id: connector.id,
      token: connector.connector_token,
      token_prefix: connector.token_prefix || connector.connector_token.slice(0, 12),
      install_target_id: installTargetId,
      platform,
      package_ref: packageRef,
      package_sha256: packageSha256,
      package_signature_ref: packageSignatureRef,
      package_signature_sha256: packageSignatureSha256,
      package_signature_algorithm: packageSignatureAlgorithm,
      connector_version: connectorVersion,
      claimed_at: now,
    },
  }));
  store.saveStatus({
    status: "claimed",
    connector_id: connector.id,
    reported_agent_count: reportedLocalAgents(nextState).length,
    last_heartbeat_at: null,
    last_error: null,
    updated_at: now,
  });
  store.appendLog("info", "Connector enrollment claimed", { connector_id: connector.id });
  appendNotification(store, {
    type: "connector_enrolled",
    level: "info",
    title: "Connector enrolled",
    message: `Connector ${connector.id} is enrolled with Agent Hub.`,
    created_at: now,
    metadata: { connector_id: connector.id },
  });
  return { connector, state: nextState };
}

async function heartbeatOnce(store) {
  const state = store.loadState();
  if (!state.connector) throw new Error("connector is not enrolled");
  const agents = reportedLocalAgents(state);
  const body = {
    host: hostInfo(),
    connector_version: state.connector.connector_version,
    capabilities: aggregateCapabilities(agents),
    reported_agents: agents,
    metadata: { source: "houflow_agent_connector" },
  };
  const client = new AgentHubClient(state.connector.control_url);
  const connector = await client.heartbeat(state.connector.id, state.connector.token, body);
  const now = new Date().toISOString();
  const previousStatus = store.loadStatus();
  store.saveStatus({
    status: "online",
    connector_id: connector.id,
    reported_agent_count: agents.length,
    last_heartbeat_at: now,
    last_error: null,
    updated_at: now,
  });
  if (previousStatus?.status !== "online") {
    store.appendLog("info", "Heartbeat restored connector online status", {
      connector_id: connector.id,
      reported_agent_count: agents.length,
    });
    appendNotification(store, {
      type: "connector_online",
      level: "info",
      title: "Connector online",
      message: `Connector ${connector.id} is reporting ${agents.length} local agent(s).`,
      created_at: now,
      metadata: { connector_id: connector.id, reported_agent_count: String(agents.length) },
    });
  }
  return connector;
}

function hostInfo() {
  return {
    hostname: os.hostname(),
    os: process.platform,
    arch: os.arch(),
  };
}

function aggregateCapabilities(agents) {
  return agents.reduce((next, agent) => ({
    lifecycle: next.lifecycle || agent.capabilities.lifecycle === true,
    dispatch: next.dispatch || agent.capabilities.dispatch === true,
    workspace_message: next.workspace_message || agent.capabilities.workspace_message === true,
    runtime_install: next.runtime_install || agent.capabilities.runtime_install === true,
    runtime_uninstall: next.runtime_uninstall || agent.capabilities.runtime_uninstall === true,
    skill_install: next.skill_install || agent.capabilities.skill_install === true,
    skill_uninstall: next.skill_uninstall || agent.capabilities.skill_uninstall === true,
    log_tail: next.log_tail || agent.capabilities.log_tail === true,
    artifact_upload: next.artifact_upload || agent.capabilities.artifact_upload === true,
    runtime_provider_projection: next.runtime_provider_projection || agent.capabilities.runtime_provider_projection === true,
  }), {
    lifecycle: false,
    dispatch: false,
    workspace_message: false,
    runtime_install: false,
    runtime_uninstall: false,
    skill_install: false,
    skill_uninstall: false,
    log_tail: false,
    artifact_upload: false,
    runtime_provider_projection: false,
  });
}

function requiredString(value, field) {
  const text = stringValue(value);
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function stringValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

module.exports = { claimEnrollment, heartbeatOnce, hostInfo, aggregateCapabilities };
