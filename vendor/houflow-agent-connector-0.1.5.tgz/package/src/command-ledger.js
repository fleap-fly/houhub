const fs = require("node:fs");

const LEDGER_VERSION = 1;
const MAX_COMMANDS = 200;
const MAX_EVENTS_PER_COMMAND = 200;
const TERMINAL_STATUSES = new Set(["succeeded", "failed", "cancelled"]);

function recordCommandReceived(store, command, now = new Date()) {
  return updateCommandLedger(store, (ledger) => upsertCommandFields(ledger, command, {
    status: normalizeStatus(command.status) || "leased",
    received_at: now.toISOString(),
    updated_at: now.toISOString(),
  }));
}

function recordCommandSnapshot(store, command, now = new Date()) {
  return updateCommandLedger(store, (ledger) => upsertCommandSnapshot(ledger, command, now.toISOString()));
}

function recordCommandEvent(store, command, event, now = new Date()) {
  return updateCommandLedger(store, (ledger) => {
    const timestamp = now.toISOString();
    const existing = ledger.commands.find((item) => item.id === command.id);
    const next = existing || commandSnapshot(command, timestamp);
    const normalizedEvent = eventSnapshot(event, timestamp);
    const nextStatus = statusAfterEvent(next.status, normalizedEvent.type);
    const withoutExisting = ledger.commands.filter((item) => item.id !== command.id);
    withoutExisting.push({
      ...next,
      status: nextStatus,
      output: normalizeOutputForEvent(next.output, event),
      error: normalizedEvent.type === "failed" || normalizedEvent.type === "cancelled" ? normalizedEvent.message : next.error,
      events: [...(next.events || []), normalizedEvent].slice(-MAX_EVENTS_PER_COMMAND),
      updated_at: timestamp,
      started_at: normalizedEvent.type === "started" && !next.started_at ? timestamp : next.started_at,
      completed_at: TERMINAL_STATUSES.has(nextStatus) ? timestamp : next.completed_at,
    });
    return pruneLedger({ ...ledger, commands: withoutExisting });
  });
}

function listCommandLedger(store, limit = 20) {
  return loadCommandLedger(store).commands
    .slice()
    .sort((a, b) => String(b.updated_at || "").localeCompare(String(a.updated_at || "")))
    .slice(0, safeLimit(limit));
}

function getCommandLedgerEntry(store, commandId) {
  const id = typeof commandId === "string" ? commandId.trim() : "";
  if (!id) throw new Error("command id is required");
  const entry = loadCommandLedger(store).commands.find((item) => item.id === id);
  if (!entry) throw new Error(`command ${id} was not found in the local connector ledger`);
  return entry;
}

function loadCommandLedger(store) {
  if (!fs.existsSync(store.commandLedgerFile)) return emptyLedger();
  return normalizeLedger(JSON.parse(fs.readFileSync(store.commandLedgerFile, "utf8")));
}

function updateCommandLedger(store, mutator) {
  store.ensureDir();
  const next = pruneLedger(mutator(loadCommandLedger(store)));
  writeLedgerFile(store.commandLedgerFile, next);
  return next;
}

function upsertCommandFields(ledger, command, fields) {
  const existing = ledger.commands.find((item) => item.id === command.id);
  const withoutExisting = ledger.commands.filter((item) => item.id !== command.id);
  withoutExisting.push({
    ...(existing || commandSnapshot(command, fields.updated_at || new Date().toISOString())),
    ...fields,
  });
  return pruneLedger({ ...ledger, commands: withoutExisting });
}

function upsertCommandSnapshot(ledger, command, timestamp) {
  const existing = ledger.commands.find((item) => item.id === command.id);
  const withoutExisting = ledger.commands.filter((item) => item.id !== command.id);
  const snapshot = commandSnapshot(command, timestamp);
  if (existing && TERMINAL_STATUSES.has(existing.status) && snapshot.status !== existing.status) {
    withoutExisting.push(existing);
    return pruneLedger({ ...ledger, commands: withoutExisting });
  }
  withoutExisting.push({
    ...snapshot,
    received_at: existing?.received_at || snapshot.received_at,
  });
  return pruneLedger({ ...ledger, commands: withoutExisting });
}

function commandSnapshot(command, timestamp) {
  return {
    id: requiredString(command.id, "command.id"),
    connector_id: stringValue(command.connector_id),
    connected_agent_id: stringValue(command.connected_agent_id),
    local_agent_ref: requiredString(command.local_agent_ref, "command.local_agent_ref"),
    action: requiredString(command.action, "command.action"),
    status: normalizeStatus(command.status) || "leased",
    input: redactSecrets(jsonObject(command.input)),
    output: redactSecrets(jsonObject(command.output)),
    error: stringValue(command.error),
    events: Array.isArray(command.events) ? command.events.map((event) => eventSnapshot(event, timestamp)).slice(-MAX_EVENTS_PER_COMMAND) : [],
    created_at: stringValue(command.created_at) || timestamp,
    updated_at: stringValue(command.updated_at) || timestamp,
    received_at: timestamp,
    started_at: stringValue(command.started_at),
    completed_at: stringValue(command.completed_at),
  };
}

function eventSnapshot(event, timestamp) {
  return {
    type: requiredString(event.type, "event.type"),
    title: stringValue(event.title) || defaultEventTitle(event.type),
    message: stringValue(event.message),
    level: event.level === "warning" || event.level === "error" ? event.level : "info",
    payload: redactSecrets(jsonObject(event.payload)),
    output: redactSecrets(jsonObject(event.output)),
    created_at: stringValue(event.created_at) || timestamp,
  };
}

function normalizeLedger(value) {
  const record = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const commands = Array.isArray(record.commands) ? record.commands.map(normalizeCommandEntry) : [];
  return pruneLedger({ version: LEDGER_VERSION, commands });
}

function normalizeCommandEntry(value) {
  const record = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    id: requiredString(record.id, "command.id"),
    connector_id: stringValue(record.connector_id),
    connected_agent_id: stringValue(record.connected_agent_id),
    local_agent_ref: requiredString(record.local_agent_ref, "command.local_agent_ref"),
    action: requiredString(record.action, "command.action"),
    status: normalizeStatus(record.status) || "leased",
    input: redactSecrets(jsonObject(record.input)),
    output: redactSecrets(jsonObject(record.output)),
    error: stringValue(record.error),
    events: Array.isArray(record.events) ? record.events.map((event) => eventSnapshot(event, stringValue(record.updated_at))).slice(-MAX_EVENTS_PER_COMMAND) : [],
    created_at: stringValue(record.created_at),
    updated_at: stringValue(record.updated_at),
    received_at: stringValue(record.received_at),
    started_at: stringValue(record.started_at),
    completed_at: stringValue(record.completed_at),
  };
}

function pruneLedger(ledger) {
  return {
    version: LEDGER_VERSION,
    commands: ledger.commands
      .slice()
      .sort((a, b) => String(b.updated_at || b.received_at || "").localeCompare(String(a.updated_at || a.received_at || "")))
      .slice(0, MAX_COMMANDS),
  };
}

function statusAfterEvent(currentStatus, eventType) {
  if (TERMINAL_STATUSES.has(currentStatus)) return currentStatus;
  if (eventType === "started") return "running";
  if (eventType === "succeeded") return "succeeded";
  if (eventType === "failed") return "failed";
  if (eventType === "cancelled") return "cancelled";
  return normalizeStatus(currentStatus) || "running";
}

function normalizeOutputForEvent(currentOutput, event) {
  if (event.type !== "succeeded" && event.type !== "failed") return currentOutput;
  return redactSecrets(jsonObject(event.output));
}

function normalizeStatus(value) {
  const status = stringValue(value);
  if (["queued", "leased", "running", "succeeded", "failed", "cancelled"].includes(status)) return status;
  return "";
}

function jsonObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function redactSecrets(value) {
  if (!value || typeof value !== "object") return value;
  if (Array.isArray(value)) return value.map(redactSecrets);
  const next = {};
  for (const [key, item] of Object.entries(value)) {
    if (key === "api_key_value") {
      next[key] = "[redacted]";
    } else {
      next[key] = redactSecrets(item);
    }
  }
  return next;
}

function safeLimit(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 20;
}

function writeLedgerFile(file, value) {
  const temp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(temp, file);
  try {
    fs.chmodSync(file, 0o600);
  } catch {}
}

function emptyLedger() {
  return { version: LEDGER_VERSION, commands: [] };
}

function requiredString(value, field) {
  const text = stringValue(value);
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function stringValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function defaultEventTitle(type) {
  if (type === "started") return "Started";
  if (type === "step") return "Step";
  if (type === "notification") return "Notification";
  if (type === "succeeded") return "Succeeded";
  return "Failed";
}

module.exports = { recordCommandReceived, recordCommandSnapshot, recordCommandEvent, listCommandLedger, getCommandLedgerEntry, loadCommandLedger };
