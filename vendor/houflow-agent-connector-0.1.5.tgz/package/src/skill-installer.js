const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { registerCommandAbort, trackProcess } = require("./process-manager.js");

const MAX_CAPTURE_BYTES = 256 * 1024;

async function installSkill(params, env = process.env, onLine = () => {}, fetcher = fetchSkillFromGitHub) {
  const skill = normalizeInstallSkill(params.skill);
  const skillsDir = requiredDirectory(params.skills_directory, "skills_directory");
  const destDir = safeSkillDir(skillsDir, skill.id);
  fs.mkdirSync(destDir, { recursive: true });
  emptyDirectory(destDir);
  onLine(`Installing skill ${skill.id}`);
  await fetcher({ skill, destDir, env, onLine, commandId: textValue(params.command_id) });
  const skillMd = findSkillMd(destDir);
  if (!skillMd) {
    throw new Error(`Skill ${skill.id} install produced no SKILL.md.`);
  }
  return {
    exit_code: 0,
    stdout: `Installed skill ${skill.id}\n`,
    stderr: "",
    skill_id: skill.id,
  };
}

async function uninstallSkill(params, _env = process.env, onLine = () => {}) {
  const skill = normalizeSkillIdentity(params.skill);
  const skillsDir = requiredDirectory(params.skills_directory, "skills_directory");
  const destDir = safeSkillDir(skillsDir, skill.id);
  const removed = fs.existsSync(destDir);
  if (removed) fs.rmSync(destDir, { recursive: true, force: true });
  onLine(removed ? `Removed skill ${skill.id}` : `Skill ${skill.id} was not installed`);
  return {
    exit_code: 0,
    stdout: removed ? `Uninstalled skill ${skill.id}\n` : `Skill ${skill.id} was not installed\n`,
    stderr: "",
    skill_id: skill.id,
    removed,
  };
}

function listInstalledSkills(skillsDirectory) {
  const skillsDir = requiredDirectory(skillsDirectory, "skills_directory");
  let entries = [];
  try {
    entries = fs.readdirSync(skillsDir, { withFileTypes: true });
  } catch {
    return [];
  }
  return entries
    .filter((entry) => entry.isDirectory())
    .map((entry) => ({ id: entry.name, path: path.join(skillsDir, entry.name), skill_md: findSkillMd(path.join(skillsDir, entry.name)) }))
    .filter((entry) => Boolean(entry.skill_md));
}

async function fetchSkillFromGitHub({ skill, destDir, env, onLine, commandId = "" }) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), `houflow-skill-${skill.id}-`));
  try {
    const archive = path.join(tmp, "source.tgz");
    const extractDir = path.join(tmp, "extract");
    fs.mkdirSync(extractDir, { recursive: true });
    const ref = skill.version || "HEAD";
    await downloadFile(`https://codeload.github.com/${skill.source_repo}/tar.gz/${encodeURIComponent(ref)}`, archive, { onLine, commandId });
    await runProcess("tar", ["-xzf", archive, "-C", extractDir, "--strip-components=1"], { cwd: process.cwd(), env, onLine, commandId });
    const sourcePath = skill.source_path || ".";
    const srcDir = path.resolve(extractDir, sourcePath);
    if (!srcDir.startsWith(path.resolve(extractDir))) {
      throw new Error(`Skill source_path escapes clone directory: ${skill.source_path}`);
    }
    if (!fs.existsSync(srcDir)) {
      throw new Error(`Skill source_path not found: ${skill.source_path || "."}`);
    }
    copyDirectory(srcDir, destDir);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

async function downloadFile(url, destFile, options) {
  options.onLine(`$ download ${url}`);
  const controller = new AbortController();
  const unregister = registerCommandAbort(options.commandId, () => controller.abort());
  try {
    const response = await fetch(url, { signal: controller.signal });
    if (!response.ok) throw new Error(`download failed with ${response.status}: ${url}`);
    const arrayBuffer = await response.arrayBuffer();
    fs.writeFileSync(destFile, Buffer.from(arrayBuffer), { mode: 0o600 });
    options.onLine(`Downloaded ${Buffer.byteLength(Buffer.from(arrayBuffer))} byte(s).`);
  } catch (error) {
    if (error?.name === "AbortError") throw new Error("download cancelled");
    throw error;
  } finally {
    unregister();
  }
}

function normalizeInstallSkill(value) {
  const skill = normalizeSkillIdentity(value);
  const record = objectValue(value);
  const sourceRepo = textValue(record.source_repo);
  if (!sourceRepo) throw new Error("skill.source_repo is required for skill_install.");
  if (!/^[a-z0-9._-]+\/[a-z0-9._-]+$/i.test(sourceRepo)) {
    throw new Error(`Invalid skill.source_repo: ${sourceRepo}`);
  }
  const sourcePath = textValue(record.source_path);
  assertSafeSourcePath(sourcePath);
  const version = textValue(record.version);
  if (version && !/^[a-z0-9][a-z0-9._/-]{0,127}$/i.test(version)) {
    throw new Error(`Invalid skill.version: ${version}`);
  }
  return {
    ...skill,
    source_repo: sourceRepo,
    source_path: sourcePath,
    version,
  };
}

function normalizeSkillIdentity(value) {
  const record = objectValue(value);
  const id = textValue(record.id);
  if (!/^[a-z0-9][a-z0-9._-]{0,127}$/i.test(id)) throw new Error(`Invalid skill.id: ${id || "<empty>"}`);
  return { id };
}

function assertSafeSourcePath(value) {
  if (!value) return;
  const normalized = value.replace(/^\/+|\/+$/g, "");
  for (const segment of normalized.split("/")) {
    if (!/^[a-z0-9][a-z0-9._-]{0,127}$/i.test(segment)) {
      throw new Error(`Invalid skill.source_path: ${value}`);
    }
  }
}

function safeSkillDir(skillsDirectory, skillId) {
  const root = path.resolve(skillsDirectory);
  const dest = path.resolve(root, skillId);
  if (dest !== path.join(root, skillId) || !dest.startsWith(`${root}${path.sep}`)) {
    throw new Error(`Refusing to write outside skills directory: ${dest}`);
  }
  return dest;
}

function requiredDirectory(value, field) {
  const text = textValue(value);
  if (!text) throw new Error(`${field} is required`);
  return path.resolve(text);
}

function emptyDirectory(dir) {
  for (const entry of fs.readdirSync(dir)) {
    fs.rmSync(path.join(dir, entry), { recursive: true, force: true });
  }
}

function copyDirectory(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    if (entry.name === ".git") continue;
    const source = path.join(src, entry.name);
    const target = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDirectory(source, target);
    else if (entry.isFile()) fs.copyFileSync(source, target);
  }
}

function findSkillMd(dir) {
  for (const name of ["SKILL.md", "skill.md", "Skill.md"]) {
    const file = path.join(dir, name);
    if (fs.existsSync(file)) return file;
  }
  return null;
}

async function runProcess(command, args, options) {
  options.onLine(`$ ${[command, ...args].join(" ")}`);
  const child = trackProcess("skill-installer", spawn(command, args, {
    cwd: options.cwd,
    env: options.env,
    shell: false,
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"],
  }), options.commandId);
  let stderr = "";
  child.stdout.on("data", (chunk) => {
    for (const line of String(chunk).split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  child.stderr.on("data", (chunk) => {
    stderr = appendLimited(stderr, String(chunk));
    for (const line of String(chunk).split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  const exitCode = await new Promise((resolve) => {
    child.on("error", () => resolve(127));
    child.on("close", (code) => resolve(Number.isInteger(code) ? code : 1));
  });
  if (exitCode !== 0) throw new Error(`${command} exited with code ${exitCode}${stderr ? `: ${stderr.trim().slice(-1000)}` : ""}`);
}

function appendLimited(current, next) {
  const value = `${current}${next}`;
  if (Buffer.byteLength(value, "utf8") <= MAX_CAPTURE_BYTES) return value;
  return value.slice(-MAX_CAPTURE_BYTES);
}

function objectValue(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function textValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

module.exports = { installSkill, uninstallSkill, listInstalledSkills, fetchSkillFromGitHub };
