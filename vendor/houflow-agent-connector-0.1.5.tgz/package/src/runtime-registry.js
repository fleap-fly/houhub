const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { spawn, spawnSync } = require("node:child_process");
const { trackProcess } = require("./process-manager.js");

const MAX_CAPTURE_BYTES = 256 * 1024;
const STATUS_TIMEOUT_MS = 5000;
const DEFAULT_SUPPORT = Object.freeze({ install: true, workspace: false, collaboration: false });

const RUNTIME_PROVIDERS = [
  provider({
    id: "claude",
    label: "Claude Code",
    description: "Anthropic's CLI coding agent.",
    homepage: "https://claude.ai/claude-code",
    tags: ["coding", "cli", "anthropic"],
    featured: true,
    order: 1,
    binary: "claude",
    local_agent_ref: "claude:cli",
    package_manager: "npm",
    package_ref: "@anthropic-ai/claude-code",
    install: platformInstall("npm install -g @anthropic-ai/claude-code", ["nodejs", "git"]),
    uninstall: platformInstall("npm uninstall -g @anthropic-ai/claude-code"),
    support: { install: true, workspace: true, collaboration: true },
    check_ready: {
      env_vars: ["ANTHROPIC_API_KEY"],
      creds_file: "~/.claude/sessions",
      keychain_service: "Claude Code-credentials",
      status_command: "claude --print hi",
      login_command: "claude login",
      not_ready_message: "Not logged in. Run: claude login",
    },
    runner: { kind: "stream-json-cli", command: "claude", args: ["-p", "{prompt}", "--output-format", "stream-json", "--verbose"], session_flag: "--resume", requires_runtime_provider_projection: false },
    execution: runnerExecution("Claude"),
  }),
  provider({
    id: "openclaw",
    label: "OpenClaw CLI",
    description: "Open-source coding agent with multi-model support.",
    homepage: "https://github.com/openclaw/openclaw",
    tags: ["coding", "cli", "open-source"],
    featured: true,
    order: 2,
    binary: "openclaw",
    local_agent_ref: "openclaw:cli",
    package_manager: "npm",
    package_ref: "openclaw",
    install: platformInstall("npm install -g openclaw@latest", ["nodejs>=22", "git"]),
    uninstall: platformInstall("npm uninstall -g openclaw"),
    support: { install: true, workspace: true, collaboration: true },
    env_config: [
      envField("LLM_API_KEY", "API key", { required: true, password: true }),
      envField("LLM_BASE_URL", "OpenAI-compatible base URL", { placeholder: "https://api.openai.com/v1" }),
      envField("LLM_MODEL", "Model name", { placeholder: "gpt-4o, claude-sonnet-4, deepseek-chat" }),
    ],
    check_ready: {
      env_vars: ["ANTHROPIC_API_KEY", "OPENAI_API_KEY", "LLM_API_KEY"],
      saved_env_key: "LLM_API_KEY",
      not_ready_message: "Not configured. Set LLM_API_KEY or provider-specific credentials.",
    },
    resolve_env: {
      rules: [
        { from: "LLM_API_KEY", to: "OPENAI_API_KEY", unless_base_url_contains: "anthropic" },
        { from: "LLM_API_KEY", to: "ANTHROPIC_API_KEY", if_base_url_contains: "anthropic" },
        { from: "LLM_BASE_URL", to: "OPENAI_BASE_URL" },
        { from: "LLM_MODEL", to: "OPENCLAW_MODEL" },
      ],
    },
    runner: { kind: "openclaw-json", command: "openclaw", session: true, requires_runtime_provider_projection: false },
    execution: runnerExecution("OpenClaw"),
  }),
  provider({
    id: "codex",
    label: "OpenAI Codex CLI",
    description: "OpenAI's coding agent for the terminal.",
    homepage: "https://github.com/openai/codex",
    tags: ["coding", "cli", "openai"],
    featured: true,
    order: 3,
    binary: "codex",
    local_agent_ref: "codex:cli",
    package_manager: "npm",
    package_ref: "@openai/codex",
    install: platformInstall("npm install -g @openai/codex", ["nodejs"]),
    uninstall: platformInstall("npm uninstall -g @openai/codex"),
    support: { install: true, workspace: true, collaboration: true },
    env_config: [
      envField("OPENAI_API_KEY", "OpenAI API key", { password: true }),
      envField("OPENAI_BASE_URL", "OpenAI-compatible base URL"),
      envField("CODEX_MODEL", "Codex model"),
    ],
    check_ready: {
      env_all: ["OPENAI_API_KEY", "OPENAI_BASE_URL"],
      saved_env_all: ["OPENAI_API_KEY", "OPENAI_BASE_URL"],
      status_command: "codex login status",
      login_command: "codex login",
      not_ready_message: "Not configured. Set OPENAI_API_KEY + OPENAI_BASE_URL, or run: codex login",
    },
    resolve_env: {
      rules: [
        { from: "LLM_API_KEY", to: "OPENAI_API_KEY" },
        { from: "LLM_BASE_URL", to: "OPENAI_BASE_URL" },
        { from: "LLM_MODEL", to: "CODEX_MODEL" },
      ],
    },
    runner: { kind: "cli-jsonl", command: "codex", args: ["exec", "--json", "--skip-git-repo-check", "-"], session: true, requires_runtime_provider_projection: false },
    execution: { mode: "built_in_runner", label: "Built-in Codex runner", dispatch_command_example: "connector-managed", description: "Can execute Agent Hub dispatch and workspace-message commands with Codex CLI without a custom shell command." },
  }),
  provider({
    id: "cline",
    label: "Cline",
    description: "Autonomous coding agent extension for VS Code.",
    homepage: "https://github.com/cline/cline",
    tags: ["coding", "vscode", "extension"],
    binary: "code",
    local_agent_ref: "cline:vscode",
    package_manager: "shell",
    install: {
      binary: "code",
      verify: "code --list-extensions 2>/dev/null | grep -qi claude-dev",
      verify_win: "code --list-extensions 2>nul | findstr /i claude-dev",
      macos: "code --install-extension saoudrizwan.claude-dev",
      linux: "code --install-extension saoudrizwan.claude-dev",
      windows: "code --install-extension saoudrizwan.claude-dev",
    },
    uninstall: platformInstall("code --uninstall-extension saoudrizwan.claude-dev"),
    check_ready: {
      status_command: "code --list-extensions 2>/dev/null | grep -qi claude-dev",
      status_command_win: "code --list-extensions 2>nul | findstr /i claude-dev",
      not_ready_message: "VS Code CLI is not available or the Cline extension is not installed.",
    },
    execution: discoveryExecution("custom VS Code extension workflow"),
  }),
  provider({
    id: "copilot",
    label: "GitHub Copilot CLI",
    description: "GitHub Copilot command line extension.",
    homepage: "https://github.com/features/copilot",
    tags: ["coding", "github", "cli"],
    binary: "gh",
    local_agent_ref: "copilot:cli",
    package_manager: "shell",
    install: {
      binary: "gh",
      verify: "gh copilot --version >/dev/null 2>&1",
      verify_win: "gh copilot --version >nul 2>nul",
      macos: "gh extension install github/gh-copilot",
      linux: "gh extension install github/gh-copilot",
      windows: "gh extension install github/gh-copilot",
    },
    uninstall: platformInstall("gh extension remove github/gh-copilot"),
    check_ready: {
      status_command: "gh copilot --version",
      not_ready_message: "GitHub CLI or the gh-copilot extension is not installed.",
    },
    execution: discoveryExecution("gh copilot"),
  }),
  provider({
    id: "cursor",
    label: "Cursor Agent",
    description: "Cursor's agent-mode command line interface.",
    homepage: "https://cursor.com",
    tags: ["coding", "editor", "cli"],
    featured: true,
    order: 4,
    binary: "cursor-agent",
    binary_aliases: ["agent"],
    local_agent_ref: "cursor:cli",
    package_manager: "shell",
    install: {
      binary: "cursor-agent",
      binary_aliases: ["agent"],
      macos: "curl https://cursor.com/install -fsSL | bash",
      linux: "curl https://cursor.com/install -fsSL | bash",
      windows: "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Invoke-RestMethod -UseBasicParsing 'https://cursor.com/install?win32=true' | Invoke-Expression\"",
    },
    env_config: [envField("CURSOR_API_KEY", "Cursor API key", { password: true }), envField("CURSOR_MODEL", "Model name")],
    check_ready: { binary: "agent", env_vars: ["CURSOR_API_KEY"], saved_env_key: "CURSOR_API_KEY", not_ready_message: "Cursor CLI not found or not configured." },
    resolve_env: { rules: [{ from: "LLM_API_KEY", to: "CURSOR_API_KEY" }, { from: "LLM_MODEL", to: "CURSOR_MODEL" }] },
    runner: { kind: "stream-json-cli", command: "cursor-agent", args: ["-p", "{prompt}", "--output-format", "stream-json", "--trust", "--force"], session_flag: "--resume", model_env: "CURSOR_MODEL", model_flag: "--model", workspace_flag: "--workspace", requires_runtime_provider_projection: false },
    execution: runnerExecution("Cursor"),
  }),
  provider({
    id: "opencode",
    label: "OpenCode CLI",
    description: "Terminal-native AI coding agent.",
    homepage: "https://opencode.ai",
    tags: ["coding", "cli", "open-source"],
    featured: true,
    order: 5,
    binary: "opencode",
    local_agent_ref: "opencode:cli",
    package_manager: "npm",
    package_ref: "opencode-ai",
    install: platformInstall("npm install -g opencode-ai@latest", ["nodejs"]),
    uninstall: platformInstall("npm uninstall -g opencode-ai"),
    env_config: [
      envField("LLM_API_KEY", "API key", { required: true, password: true }),
      envField("LLM_BASE_URL", "OpenAI-compatible base URL", { placeholder: "https://api.openai.com/v1" }),
      envField("LLM_MODEL", "Model name"),
    ],
    check_ready: { env_vars: ["OPENAI_API_KEY", "ANTHROPIC_API_KEY", "LLM_API_KEY"], saved_env_key: "LLM_API_KEY", not_ready_message: "Not configured. Set LLM_API_KEY or provider-specific credentials." },
    resolve_env: { rules: [{ from: "LLM_API_KEY", to: "OPENAI_API_KEY" }, { from: "LLM_BASE_URL", to: "OPENAI_BASE_URL" }, { from: "LLM_MODEL", to: "OPENCODE_MODEL" }] },
    runner: { kind: "opencode-json", command: "opencode", session: true, requires_runtime_provider_projection: false },
    execution: runnerExecution("OpenCode"),
  }),
  provider({
    id: "hermes",
    label: "Hermes Agent",
    description: "Nous Hermes Agent with tools, profiles, memory, and messaging.",
    homepage: "https://github.com/NousResearch/hermes-agent",
    tags: ["coding", "agent", "python"],
    featured: true,
    order: 6,
    binary: "hermes",
    local_agent_ref: "hermes:cli",
    package_manager: "shell",
    install: {
      binary: "hermes",
      requires: ["python3"],
      macos: "curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash -s -- --skip-setup",
      linux: "curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash -s -- --skip-setup",
      windows: "echo Hermes currently requires WSL2 on Windows. See https://github.com/NousResearch/hermes-agent",
    },
    support: { install: true, workspace: true, collaboration: true },
    check_ready: { creds_file: "~/.hermes/config.yaml", status_command: "hermes status", login_command: "hermes setup", not_ready_message: "Hermes is not configured. Run: hermes setup" },
    runner: { kind: "text-cli", command: "hermes", args: ["chat", "-q", "{prompt}", "-Q", "--source", "houflow", "--max-turns", "20"], session_flag: "--resume", session_regex: "session_id:\\s*(\\S+)", requires_runtime_provider_projection: false },
    execution: runnerExecution("Hermes"),
  }),
  provider({
    id: "kimi",
    label: "Kimi",
    description: "Kimi agent using Moonshot's OpenAI-compatible API.",
    homepage: "https://platform.moonshot.ai",
    tags: ["coding", "api", "moonshot"],
    featured: true,
    order: 7,
    binary: "kimi",
    local_agent_ref: "kimi:api",
    package_manager: "api-only",
    install: apiOnlyInstall("kimi", "KIMI_API_KEY"),
    support: { install: true, workspace: true, collaboration: true },
    env_config: [
      envField("KIMI_API_KEY", "Moonshot/Kimi API key", { required: true, password: true }),
      envField("KIMI_BASE_URL", "Kimi API base URL", { placeholder: "https://api.moonshot.ai/v1" }),
      envField("KIMI_MODEL", "Kimi model", { placeholder: "kimi-k2.6" }),
    ],
    check_ready: { env_vars: ["KIMI_API_KEY", "MOONSHOT_API_KEY", "LLM_API_KEY", "OPENAI_API_KEY"], saved_env_key: "KIMI_API_KEY", not_ready_message: "No API key. Configure KIMI_API_KEY." },
    resolve_env: { rules: [{ from: "LLM_API_KEY", to: "KIMI_API_KEY" }, { from: "LLM_BASE_URL", to: "KIMI_BASE_URL" }, { from: "LLM_MODEL", to: "KIMI_MODEL" }] },
    runner: { kind: "direct-openai-chat", api_key_env: ["KIMI_API_KEY", "MOONSHOT_API_KEY", "LLM_API_KEY", "OPENAI_API_KEY"], base_url_env: ["KIMI_BASE_URL", "LLM_BASE_URL", "OPENAI_BASE_URL"], default_base_url: "https://api.moonshot.ai/v1", model_env: ["KIMI_MODEL", "LLM_MODEL"], default_model: "kimi-k2.6", requires_runtime_provider_projection: false },
    execution: runnerExecution("Kimi"),
  }),
  provider({
    id: "pi",
    label: "Pi Coding Agent",
    description: "Connector-managed runtime runner for Agent Hub dispatch, workspace messages, lifecycle, runtime install, and skills.",
    homepage: "https://www.npmjs.com/package/@earendil-works/pi-coding-agent",
    tags: ["coding", "runner", "agent-hub"],
    featured: true,
    order: 8,
    binary: "pi",
    local_agent_ref: "pi:cli",
    package_manager: "npm",
    package_ref: "@earendil-works/pi-coding-agent",
    install: platformInstall("npm install -g @earendil-works/pi-coding-agent", ["nodejs>=22.19.0"]),
    uninstall: platformInstall("npm uninstall -g @earendil-works/pi-coding-agent"),
    minimum_node_version: "22.19.0",
    support: { install: true, workspace: true, collaboration: true },
    runner: { kind: "pi-json", requires_runtime_provider_projection: true },
    check_ready: { not_ready_message: "Pi is not installed or not on PATH." },
    execution: runnerExecution("Agent Hub"),
  }),
  provider({
    id: "gemini",
    label: "Gemini CLI",
    description: "Google's open-source AI agent for the command line.",
    homepage: "https://github.com/google-gemini/gemini-cli",
    tags: ["coding", "cli", "google"],
    binary: "gemini",
    local_agent_ref: "gemini:cli",
    package_manager: "npm",
    package_ref: "@google/gemini-cli",
    install: platformInstall("npm install -g @google/gemini-cli", ["nodejs"]),
    uninstall: platformInstall("npm uninstall -g @google/gemini-cli"),
    support: { install: true, workspace: true, collaboration: true },
    check_ready: { status_command: "gemini --version", login_command: "gemini", not_ready_message: "Not logged in. Run: gemini" },
    runner: { kind: "stream-json-cli", command: "gemini", args: ["-p", "{prompt}", "-y", "-o", "stream-json"], session_flag: "-r", requires_runtime_provider_projection: false },
    execution: runnerExecution("Gemini"),
  }),
  provider({
    id: "aider",
    label: "Aider",
    description: "AI pair programming in your terminal.",
    homepage: "https://aider.chat",
    tags: ["coding", "pair-programming", "open-source"],
    binary: "aider",
    local_agent_ref: "aider:cli",
    package_manager: "shell",
    install: { binary: "aider", macos: "curl -LsSf https://aider.chat/install.sh | sh", linux: "curl -LsSf https://aider.chat/install.sh | sh", windows: "powershell -c \"irm https://aider.chat/install.ps1 | iex\"" },
    execution: discoveryExecution("aider --message"),
  }),
  provider({
    id: "amp",
    label: "Amp",
    description: "Sourcegraph's AI coding agent for CLI and VS Code.",
    homepage: "https://ampcode.com",
    tags: ["coding", "sourcegraph", "cli"],
    binary: "amp",
    local_agent_ref: "amp:cli",
    package_manager: "shell",
    install: { binary: "amp", macos: "curl -fsSL https://ampcode.com/install.sh | bash", linux: "curl -fsSL https://ampcode.com/install.sh | bash", windows: "powershell -c \"irm https://ampcode.com/install.ps1 | iex\"" },
    execution: discoveryExecution("amp"),
  }),
  provider({
    id: "goose",
    label: "Goose",
    description: "Open-source AI developer agent by Block.",
    homepage: "https://github.com/block/goose",
    tags: ["coding", "cli", "open-source"],
    binary: "goose",
    local_agent_ref: "goose:cli",
    package_manager: "shell",
    install: { binary: "goose", macos: "curl -fsSL https://github.com/block/goose/releases/download/stable/download_cli.sh | bash", linux: "curl -fsSL https://github.com/block/goose/releases/download/stable/download_cli.sh | bash", windows: "powershell -c \"irm https://raw.githubusercontent.com/block/goose/main/download_cli.ps1 | iex\"" },
    execution: discoveryExecution("goose run"),
  }),
  provider({
    id: "swebench",
    label: "SWE-bench Agent",
    description: "SWE-bench style local coding agent runner.",
    homepage: "https://github.com/SWE-agent/SWE-agent",
    tags: ["coding", "benchmark", "python"],
    binary: "sweagent",
    local_agent_ref: "swebench:cli",
    package_manager: "shell",
    install: { binary: "sweagent", requires: ["python3", "pip"], macos: "pip install sweagent", linux: "pip install sweagent", windows: "pip install sweagent" },
    uninstall: platformInstall("pip uninstall -y sweagent"),
    execution: discoveryExecution("sweagent"),
  }),
  provider({
    id: "nanoclaw",
    label: "NanoClaw",
    description: "Lightweight API-driven coding agent profile.",
    homepage: "https://agent.houflow.com/docs",
    tags: ["coding", "api"],
    binary: "nanoclaw",
    local_agent_ref: "nanoclaw:api",
    package_manager: "api-only",
    install: apiOnlyInstall("nanoclaw", "OPENAI_API_KEY"),
    support: { install: true, workspace: true, collaboration: true },
    env_config: [envField("OPENAI_API_KEY", "API key for LLM inference", { required: true, password: true }), envField("OPENAI_BASE_URL", "OpenAI-compatible base URL", { placeholder: "https://api.openai.com/v1" }), envField("NANOCLAW_MODEL", "Model name")],
    check_ready: { env_vars: ["OPENAI_API_KEY", "LLM_API_KEY"], saved_env_key: "OPENAI_API_KEY", not_ready_message: "No API key. Configure OPENAI_API_KEY." },
    resolve_env: { rules: [{ from: "LLM_API_KEY", to: "OPENAI_API_KEY" }, { from: "LLM_BASE_URL", to: "OPENAI_BASE_URL" }, { from: "LLM_MODEL", to: "NANOCLAW_MODEL" }] },
    runner: { kind: "direct-openai-chat", api_key_env: ["OPENAI_API_KEY", "LLM_API_KEY"], base_url_env: ["OPENAI_BASE_URL", "LLM_BASE_URL"], default_base_url: "https://api.openai.com/v1", model_env: ["NANOCLAW_MODEL", "OPENCLAW_MODEL", "LLM_MODEL"], default_model: "gpt-4o", requires_runtime_provider_projection: false },
    execution: runnerExecution("NanoClaw"),
  }),
];

function listRuntimeProviders() {
  return sortedProviders().map((provider) => publicRuntimeProvider(provider));
}

function getRuntimeProvider(runtimeRef) {
  const ref = textValue(runtimeRef);
  return sortedProviders().find((provider) => provider.id === ref || provider.provider === ref) ?? null;
}

function discoverRuntimeProviders(env = process.env, state = null) {
  return sortedProviders()
    .filter((provider) => {
      if (!provider.install?.api_only) return Boolean(whichRuntimeBinary(provider, env));
      const savedEnv = runtimeEnvForState(state, provider.id);
      const effectiveEnv = runtimeEffectiveEnv(provider.id, state, env);
      return runtimeHasAnyCredential(provider, effectiveEnv, savedEnv);
    })
    .map((provider) => ({
      ...publicRuntimeProvider(provider),
      detected_binary: provider.install?.api_only ? null : whichRuntimeBinary(provider, env),
      readiness: runtimeProviderReadiness(provider.id, env, state),
    }));
}

function runtimeProviderStatus(runtimeRef, env = process.env, state = null) {
  const provider = requiredRuntimeProvider(runtimeRef);
  const readiness = runtimeProviderReadiness(provider.id, env, state);
  return {
    ...publicRuntimeProvider(provider),
    binary_path: readiness.binary_path,
    installed: readiness.installed,
    installed_version: readiness.version,
    ready: readiness.ready,
    readiness,
  };
}

function runtimeProviderReadiness(runtimeRef, env = process.env, state = null, options = {}) {
  const provider = requiredRuntimeProvider(runtimeRef);
  const savedEnv = runtimeEnvForState(state, provider.id);
  const effectiveEnv = runtimeEffectiveEnv(provider.id, state, env);
  const binaryPath = provider.install?.api_only ? null : whichRuntimeBinary(provider, env);
  const verifiedInstall = options.deep === true ? verifyRuntimeInstall(provider, env, Boolean(binaryPath)) : null;
  const installed = provider.install?.api_only ? runtimeHasAnyCredential(provider, effectiveEnv, savedEnv) : (verifiedInstall === null ? Boolean(binaryPath) : verifiedInstall);
  const probe = options.deep === true && !provider.install?.api_only && binaryPath
    ? probeRuntimeProviderSync(provider, env, binaryPath)
    : { version_output: "", detected_version: null };
  const credential = readinessFromEnv(provider, effectiveEnv, savedEnv);
  const status = options.deep === true ? checkStatusReadiness(provider, effectiveEnv, Boolean(binaryPath)) : { ready: false, auth_mode: null, execution_mode: null };
  const creds = checkCredsReadiness(provider);
  const hasReadyRule = Boolean(provider.check_ready);
  const ready = Boolean(installed && (credential.ready || status.ready || creds.ready || !hasReadyRule));
  const reasons = [];
  if (!installed) {
    if (provider.install?.api_only) reasons.push("saved environment is missing");
    else if (binaryPath && verifiedInstall === false) reasons.push(provider.check_ready?.not_ready_message || `${provider.label} install verification failed`);
    else reasons.push(`${provider.binary} is not on PATH`);
  }
  if (installed && !ready) reasons.push(provider.check_ready?.not_ready_message || "runtime is not configured");
  return {
    runtime_ref: provider.id,
    provider: provider.provider,
    label: provider.label,
    binary: provider.binary,
    binary_path: binaryPath,
    installed,
    version: probe.detected_version,
    version_output: probe.version_output,
    ready,
    auth_mode: credential.auth_mode || status.auth_mode || creds.auth_mode || null,
    execution_mode: provider.runner ? "built_in_runner" : ready ? (status.execution_mode || credential.execution_mode || creds.execution_mode || "subprocess") : "unavailable",
    message: ready ? "Ready" : reasons.join("; ") || "Not ready",
    login_command: provider.check_ready?.login_command || "",
    status_command: platformStatusCommand(provider.check_ready),
    missing_env: credential.missing_env,
    configured_env: credential.configured_env,
    saved_env_keys: Object.keys(savedEnv),
    required_env: runtimeRequiredEnv(provider),
  };
}

function runtimeEffectiveEnv(runtimeRef, state = null, baseEnv = process.env) {
  const provider = requiredRuntimeProvider(runtimeRef);
  const saved = runtimeEnvForState(state, provider.id);
  const direct = { ...baseEnv, ...saved };
  const resolved = { ...direct };
  for (const rule of provider.resolve_env?.rules || []) {
    const value = textValue(direct[rule.from]);
    if (!value) continue;
    const baseUrl = textValue(direct.LLM_BASE_URL || direct.OPENAI_BASE_URL || direct.KIMI_BASE_URL).toLowerCase();
    if (rule.if_base_url_contains && !baseUrl.includes(String(rule.if_base_url_contains).toLowerCase())) continue;
    if (rule.unless_base_url_contains && baseUrl.includes(String(rule.unless_base_url_contains).toLowerCase())) continue;
    if (!textValue(resolved[rule.to])) resolved[rule.to] = value;
  }
  return resolved;
}

function runtimeEnvForState(state, runtimeRef) {
  const provider = getRuntimeProvider(runtimeRef);
  const key = provider?.id || textValue(runtimeRef);
  if (!key || state === null || state === undefined) return {};
  if (!state.runtime_env || typeof state.runtime_env !== "object" || Array.isArray(state.runtime_env)) {
    throw new Error("state.runtime_env must be an object");
  }
  const value = state.runtime_env[key];
  if (value === undefined) return {};
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`state.runtime_env.${key} must be an object`);
  for (const [envKey, envValue] of Object.entries(value)) {
    if (typeof envValue !== "string") throw new Error(`state.runtime_env.${key}.${envKey} must be a string`);
  }
  return { ...value };
}

function setRuntimeEnv(state, runtimeRef, values = {}, unset = []) {
  const provider = requiredRuntimeProvider(runtimeRef);
  const current = runtimeEnvForState(state, provider.id);
  const next = { ...current };
  for (const [key, value] of Object.entries(values || {})) {
    const envKey = envKeyValue(key);
    if (!envKey) throw new Error("runtime env key is required");
    next[envKey] = String(value);
  }
  for (const key of unset || []) {
    const envKey = envKeyValue(key);
    if (!envKey) throw new Error("runtime env unset key is required");
    delete next[envKey];
  }
  return { ...state, runtime_env: { ...state.runtime_env, [provider.id]: next } };
}

async function installRuntimeProvider(params, env = process.env, onLine = () => {}) {
  const provider = requiredRuntimeProvider(params.runtime_ref);
  assertExpectedProvider(provider, params.expected_provider);
  if (provider.install?.api_only) {
    const message = `${provider.label} does not require a connector-managed binary. Configure runtime env instead.`;
    onLine(message);
    return apiOnlyRuntimeResult(provider, message, true);
  }
  if (provider.package_manager === "shell") return installShellRuntimeProvider(provider, params, env, onLine);
  if (provider.package_manager !== "npm") {
    throw new Error(`Runtime provider ${provider.id} does not have a connector-managed installer. Use this command manually: ${installCommandForPlatform(provider) || "see provider docs"}`);
  }
  await assertRuntimePrerequisites(provider, env);
  const requestedVersion = textValue(params.version);
  const packageRef = packageSpec(provider.package_ref, params.package_ref, params.version);
  const before = await probeRuntimeProvider(provider, env);
  if (requestedVersion && runtimeVersionMatches(before.version_output, requestedVersion)) {
    const message = `${provider.label} ${requestedVersion} is already installed at ${before.binary_path}.`;
    onLine(message);
    return {
      exit_code: 0,
      stdout: `${message}\n`,
      stderr: "",
      runtime_ref: provider.id,
      package_ref: packageRef,
      binary_path: before.binary_path,
      requested_version: requestedVersion,
      installed_version: requestedVersion,
      changed: false,
    };
  }
  if (requestedVersion && before.installed) {
    onLine(`${provider.label} ${before.detected_version || "unknown"} is installed; installing ${requestedVersion}.`);
  }
  const result = await runProcess("npm", ["install", "-g", packageRef], {
    cwd: workingDirectory(params.working_directory),
    env,
    commandId: textValue(params.command_id),
    onLine,
    output: { runtime_ref: provider.id, package_ref: packageRef, requested_version: requestedVersion || null, changed: true },
  });
  if (result.exit_code !== 0) return result;
  return verifyInstalledRuntime(provider, requestedVersion, result, env, onLine);
}

async function uninstallRuntimeProvider(params, env = process.env, onLine = () => {}) {
  const provider = requiredRuntimeProvider(params.runtime_ref);
  assertExpectedProvider(provider, params.expected_provider);
  if (provider.install?.api_only) {
    const message = `${provider.label} does not install a connector-managed binary. Remove saved runtime env if needed.`;
    onLine(message);
    return apiOnlyRuntimeResult(provider, message, false);
  }
  if (provider.package_manager === "shell") return uninstallShellRuntimeProvider(provider, params, env, onLine);
  if (provider.package_manager !== "npm") {
    throw new Error(`Runtime provider ${provider.id} does not have a connector-managed uninstaller. Remove it using its installer or OS package manager.`);
  }
  const packageRef = uninstallPackageRef(provider.package_ref, params.package_ref);
  const result = await runProcess("npm", ["uninstall", "-g", packageRef], {
    cwd: workingDirectory(params.working_directory),
    env,
    commandId: textValue(params.command_id),
    onLine,
    output: { runtime_ref: provider.id, package_ref: packageRef, changed: true },
  });
  if (result.exit_code !== 0) return result;
  const after = await probeRuntimeProvider(provider, env);
  if (after.installed) return failedRuntimeResult(result, `Runtime binary ${provider.binary} is still present at ${after.binary_path} after uninstall.`);
  const message = `${provider.label} is not installed on PATH.`;
  onLine(message);
  return { ...result, stdout: appendLimited(result.stdout, `${message}\n`), binary_path: null, installed_version: null };
}

function whichBinary(binary, env = process.env) {
  const name = textValue(binary);
  if (!name) return null;
  const pathValue = env.PATH || "";
  const extensions = process.platform === "win32" ? ["", ".exe", ".cmd", ".bat"] : [""];
  for (const dir of pathValue.split(path.delimiter).filter(Boolean)) {
    for (const ext of extensions) {
      const candidate = path.join(dir, `${name}${ext}`);
      try {
        const stat = fs.statSync(candidate);
        if (stat.isFile()) return candidate;
      } catch {}
    }
  }
  return null;
}

function whichRuntimeBinary(provider, env) {
  return [provider.binary, ...(provider.binary_aliases || [])].map((binary) => whichBinary(binary, env)).find(Boolean) || null;
}

async function verifyInstalledRuntime(provider, requestedVersion, result, env, onLine) {
  const after = await probeRuntimeProvider(provider, env);
  if (!after.installed) return failedRuntimeResult(result, `Runtime binary ${provider.binary} was not found on PATH after installation.`);
  if (requestedVersion && !runtimeVersionMatches(after.version_output, requestedVersion)) {
    return failedRuntimeResult(result, `Runtime binary ${provider.binary} did not report installed version ${requestedVersion}.`);
  }
  const installedVersion = requestedVersion || after.detected_version || null;
  const message = installedVersion ? `${provider.label} ${installedVersion} is installed at ${after.binary_path}.` : `${provider.label} is installed at ${after.binary_path}.`;
  onLine(message);
  return { ...result, stdout: appendLimited(result.stdout, `${message}\n`), binary_path: after.binary_path, installed_version: installedVersion };
}

async function installShellRuntimeProvider(provider, params, env, onLine) {
  if (textValue(params.version) || textValue(params.package_ref)) {
    throw new Error(`Runtime provider ${provider.id} uses an official installer command; --version and --package-ref are only supported for npm runtimes.`);
  }
  const command = installCommandForPlatform(provider);
  if (!command) throw new Error(`Runtime provider ${provider.id} has no install command for this platform.`);
  await assertRuntimePrerequisites(provider, env);
  const before = await probeRuntimeProvider(provider, env);
  if (runtimeInstallVerified(provider, env, before.installed)) {
    const message = `${provider.label} is already installed at ${before.binary_path}.`;
    onLine(message);
    return {
      exit_code: 0,
      stdout: `${message}\n`,
      stderr: "",
      runtime_ref: provider.id,
      package_ref: provider.package_ref || "",
      binary_path: before.binary_path,
      requested_version: null,
      installed_version: before.detected_version || null,
      changed: false,
    };
  }
  const result = await runShellProcess(command, {
    cwd: workingDirectory(params.working_directory),
    env,
    commandId: textValue(params.command_id),
    onLine,
    output: { runtime_ref: provider.id, package_ref: provider.package_ref || "", requested_version: null, changed: true },
  });
  if (result.exit_code !== 0) return result;
  const after = await probeRuntimeProvider(provider, env);
  if (!runtimeInstallVerified(provider, env, after.installed)) {
    const message = `${provider.label} install command completed. ${provider.binary} was not found on PATH yet; restart the terminal or update PATH, then run hou-agent-connector runtime ready ${provider.id}.`;
    onLine(message);
    return { ...result, stdout: appendLimited(result.stdout, `${message}\n`), binary_path: null, installed_version: null };
  }
  const message = `${provider.label} is installed at ${after.binary_path}.`;
  onLine(message);
  return { ...result, stdout: appendLimited(result.stdout, `${message}\n`), binary_path: after.binary_path, installed_version: after.detected_version || null };
}

async function uninstallShellRuntimeProvider(provider, params, env, onLine) {
  if (textValue(params.version) || textValue(params.package_ref)) {
    throw new Error(`Runtime provider ${provider.id} uses an official uninstall command; --version and --package-ref are only supported for npm runtimes.`);
  }
  const command = uninstallCommandForPlatform(provider);
  if (!command) throw new Error(`Runtime provider ${provider.id} does not publish a connector-managed uninstall command. Remove it using its installer or OS package manager.`);
  const result = await runShellProcess(command, {
    cwd: workingDirectory(params.working_directory),
    env,
    commandId: textValue(params.command_id),
    onLine,
    output: { runtime_ref: provider.id, package_ref: provider.package_ref || "", changed: true },
  });
  if (result.exit_code !== 0) return result;
  const after = await probeRuntimeProvider(provider, env);
  const message = after.installed
    ? `${provider.label} uninstall command completed. ${provider.binary} is still visible at ${after.binary_path}; run readiness check or remove it from PATH if needed.`
    : `${provider.label} is not installed on PATH.`;
  onLine(message);
  return { ...result, stdout: appendLimited(result.stdout, `${message}\n`), binary_path: after.binary_path, installed_version: after.detected_version || null };
}

async function assertRuntimePrerequisites(provider, env) {
  for (const requirement of provider.install?.requires || []) {
    const parsed = parseRequirement(requirement);
    if (!parsed.name) continue;
    if (parsed.name === "nodejs") {
      const minimumVersion = provider.minimum_node_version || parsed.minimumVersion;
      const node = await probeNodeVersion(env);
      if (!node.binary_path) throw new Error(`Runtime provider ${provider.id} requires Node.js${minimumVersion ? ` >=${minimumVersion}` : ""} on PATH.`);
      if (minimumVersion && (!node.version || compareVersions(node.version, minimumVersion) < 0)) {
        throw new Error(`Runtime provider ${provider.id} requires Node.js >=${minimumVersion} on PATH; found ${node.raw_version || "unknown"} at ${node.binary_path}.`);
      }
      continue;
    }
    const binaryName = parsed.name === "pip" ? (whichBinary("pip", env) ? "pip" : "pip3") : parsed.name;
    if (!whichBinary(binaryName, env)) throw new Error(`Runtime provider ${provider.id} requires ${parsed.name} on PATH.`);
  }
  if (provider.minimum_node_version && !(provider.install?.requires || []).some((item) => parseRequirement(item).name === "nodejs")) {
    const node = await probeNodeVersion(env);
    if (!node.binary_path) throw new Error(`Runtime provider ${provider.id} requires Node.js >=${provider.minimum_node_version} on PATH.`);
    if (!node.version || compareVersions(node.version, provider.minimum_node_version) < 0) {
      throw new Error(`Runtime provider ${provider.id} requires Node.js >=${provider.minimum_node_version} on PATH; found ${node.raw_version || "unknown"} at ${node.binary_path}.`);
    }
  }
}

function parseRequirement(value) {
  const match = /^([a-z0-9._-]+)(?:>=([0-9][0-9.]*))?$/i.exec(textValue(value));
  return { name: match?.[1]?.toLowerCase() || "", minimumVersion: match?.[2] || "" };
}

async function probeNodeVersion(env) {
  const binaryPath = whichBinary("node", env);
  if (!binaryPath) return { binary_path: null, version: null, raw_version: "" };
  const result = await runVersionCommand(binaryPath, env);
  const rawVersion = `${result.stdout}${result.stderr}`.trim();
  const match = /^v?(\d+\.\d+\.\d+)/.exec(rawVersion);
  return { binary_path: binaryPath, version: match?.[1] || null, raw_version: rawVersion };
}

async function probeRuntimeProvider(provider, env) {
  const binaryPath = whichRuntimeBinary(provider, env);
  if (!binaryPath) return { installed: false, binary_path: null, version_output: "", detected_version: null };
  const version = await runVersionCommand(binaryPath, env);
  const versionOutput = `${version.stdout}${version.stderr}`.trim();
  return { installed: true, binary_path: binaryPath, version_output: versionOutput, detected_version: detectedVersion(versionOutput) };
}

function probeRuntimeProviderSync(_provider, env, binaryPath) {
  const result = spawnSync(binaryPath, ["--version"], { env, shell: false, windowsHide: true, encoding: "utf8", timeout: STATUS_TIMEOUT_MS });
  const versionOutput = `${result.stdout || ""}${result.stderr || ""}`.trim();
  return { version_output: versionOutput, detected_version: detectedVersion(versionOutput) };
}

function runVersionCommand(binaryPath, env) {
  const child = spawn(binaryPath, ["--version"], { env, shell: false, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  let stdout = "";
  let stderr = "";
  child.stdout.on("data", (chunk) => { stdout = appendLimited(stdout, String(chunk)); });
  child.stderr.on("data", (chunk) => { stderr = appendLimited(stderr, String(chunk)); });
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      try { child.kill(); } catch {}
      resolve({ exit_code: 124, stdout, stderr });
    }, STATUS_TIMEOUT_MS);
    timer.unref?.();
    child.on("error", () => { clearTimeout(timer); resolve({ exit_code: 127, stdout, stderr }); });
    child.on("close", (code) => { clearTimeout(timer); resolve({ exit_code: Number.isInteger(code) ? code : 1, stdout, stderr }); });
  });
}

async function runShellProcess(command, options) {
  const finalCommand = textValue(command);
  options.onLine(`$ ${finalCommand}`);
  const child = trackProcess("runtime-installer", spawn(finalCommand, [], {
    cwd: options.cwd,
    env: options.env,
    shell: true,
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"],
  }), options.commandId);
  let stdout = "";
  let stderr = "";
  child.stdout.on("data", (chunk) => {
    const text = String(chunk);
    stdout = appendLimited(stdout, text);
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  child.stderr.on("data", (chunk) => {
    const text = String(chunk);
    stderr = appendLimited(stderr, text);
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  const exitCode = await new Promise((resolve) => {
    child.on("error", () => resolve(127));
    child.on("close", (code) => resolve(Number.isInteger(code) ? code : 1));
  });
  return { exit_code: exitCode, stdout, stderr, ...options.output };
}

async function runProcess(command, args, options) {
  options.onLine(`$ ${[command, ...args].join(" ")}`);
  const child = trackProcess("runtime-installer", spawn(command, args, {
    cwd: options.cwd,
    env: options.env,
    shell: false,
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"],
  }), options.commandId);
  let stdout = "";
  let stderr = "";
  child.stdout.on("data", (chunk) => {
    const text = String(chunk);
    stdout = appendLimited(stdout, text);
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  child.stderr.on("data", (chunk) => {
    const text = String(chunk);
    stderr = appendLimited(stderr, text);
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  const exitCode = await new Promise((resolve) => {
    child.on("error", () => resolve(127));
    child.on("close", (code) => resolve(Number.isInteger(code) ? code : 1));
  });
  return { exit_code: exitCode, stdout, stderr, ...options.output };
}

function provider(value) {
  return { provider: value.id, env_config: [], support: DEFAULT_SUPPORT, package_ref: "", ...value };
}

function platformInstall(command, requires = []) {
  return { requires, macos: command, linux: command, windows: command };
}

function apiOnlyInstall(binary, envName) {
  const text = `No local binary required. Configure ${envName} in the connector.`;
  return { binary, api_only: true, macos: text, linux: text, windows: text };
}

function envField(name, description, options = {}) {
  return {
    name,
    description,
    required: options.required === true,
    password: options.password === true,
    ...(options.placeholder ? { placeholder: options.placeholder } : {}),
    ...(options.default ? { default: options.default } : {}),
  };
}

function discoveryExecution(command) {
  return {
    mode: "discovery",
    label: "PATH discovery",
    dispatch_command_example: command,
    description: "Connector can report this CLI when it is on PATH. Configure a dispatch command to let Agent Hub send work to it.",
  };
}

function runnerExecution(label) {
  return {
    mode: "built_in_runner",
    label: `Built-in ${label} runner`,
    dispatch_command_example: "connector-managed",
    description: "Can execute Agent Hub dispatch and workspace-message commands without a custom shell command.",
  };
}

function sortedProviders() {
  return [...RUNTIME_PROVIDERS].sort((left, right) => {
    const leftFeatured = left.featured ? 1 : 0;
    const rightFeatured = right.featured ? 1 : 0;
    if (leftFeatured !== rightFeatured) return rightFeatured - leftFeatured;
    if (leftFeatured && rightFeatured) return (left.order || 999) - (right.order || 999);
    return left.label.localeCompare(right.label);
  });
}

function publicRuntimeProvider(provider) {
  return {
    id: provider.id,
    runtime_ref: provider.id,
    provider: provider.provider,
    label: provider.label,
    description: provider.description || "",
    homepage: provider.homepage || "",
    tags: [...(provider.tags || [])],
    featured: provider.featured === true,
    order: provider.order || 999,
    binary: provider.binary,
    binary_aliases: [...(provider.binary_aliases || [])],
    local_agent_ref: provider.local_agent_ref,
    package_manager: provider.package_manager || "shell",
    package_ref: provider.package_ref || "",
    install: installInfo(provider),
    uninstall: uninstallInfo(provider),
    support: { ...DEFAULT_SUPPORT, ...(provider.support || {}) },
    runner: provider.runner ? { ...provider.runner } : null,
    env_config: (provider.env_config || []).map((field) => ({ ...field })),
    resolve_env: provider.resolve_env ? { rules: (provider.resolve_env.rules || []).map((rule) => ({ ...rule })) } : null,
    check_ready: provider.check_ready ? publicCheckReady(provider.check_ready) : null,
    execution: provider.execution ? { ...provider.execution } : discoveryExecution(""),
  };
}

function installInfo(provider) {
  const install = provider.install || {};
  return {
    binary: install.binary || provider.binary,
    binary_aliases: [...(install.binary_aliases || provider.binary_aliases || [])],
    api_only: install.api_only === true,
    requires: [...(install.requires || [])],
    macos: textValue(install.macos),
    linux: textValue(install.linux),
    windows: textValue(install.windows),
    current_platform: installCommandForPlatform(provider),
  };
}

function uninstallInfo(provider) {
  const uninstall = provider.uninstall || {};
  return {
    macos: textValue(uninstall.macos),
    linux: textValue(uninstall.linux),
    windows: textValue(uninstall.windows),
    current_platform: platformCommand(uninstall),
  };
}

function publicCheckReady(checkReady) {
  return {
    env_vars: [...(checkReady.env_vars || [])],
    env_all: [...(checkReady.env_all || [])],
    saved_env_key: textValue(checkReady.saved_env_key),
    saved_env_all: [...(checkReady.saved_env_all || [])],
    status_command: textValue(checkReady.status_command || checkReady.alt_check),
    login_command: textValue(checkReady.login_command),
    not_ready_message: textValue(checkReady.not_ready_message),
  };
}

function runtimeRequiredEnv(provider) {
  return (provider.env_config || []).filter((field) => field.required === true);
}

function runtimeHasAnyCredential(provider, env, savedEnv) {
  const check = provider.check_ready || {};
  return [...(check.env_vars || []), ...(check.env_all || []), ...(check.saved_env_all || []), check.saved_env_key]
    .filter(Boolean)
    .some((key) => textValue(env[key]) || textValue(savedEnv[key]));
}

function readinessFromEnv(provider, env, savedEnv) {
  const check = provider.check_ready || {};
  const configured = new Set();
  for (const key of [...(check.env_vars || []), ...(check.env_all || []), ...(check.saved_env_all || []), check.saved_env_key].filter(Boolean)) {
    if (textValue(env[key]) || textValue(savedEnv[key])) configured.add(key);
  }
  const allKeys = check.env_all || [];
  const savedAllKeys = check.saved_env_all || [];
  const allReady = allKeys.length > 0 && allKeys.every((key) => textValue(env[key]));
  const savedAllReady = savedAllKeys.length > 0 && savedAllKeys.every((key) => textValue(savedEnv[key] || env[key]));
  const anyReady = (check.env_vars || []).some((key) => textValue(env[key]));
  const savedReady = check.saved_env_key ? textValue(savedEnv[check.saved_env_key] || env[check.saved_env_key]) : "";
  const required = runtimeRequiredEnv(provider);
  const missing = required.filter((field) => !textValue(env[field.name]));
  const ready = Boolean(allReady || savedAllReady || anyReady || savedReady || (required.length > 0 && missing.length === 0));
  return {
    ready,
    auth_mode: ready ? "api_key" : null,
    execution_mode: ready ? "direct" : null,
    configured_env: [...configured].sort(),
    missing_env: missing.map((field) => field.name),
  };
}

function checkStatusReadiness(provider, env, hasBinary) {
  const command = platformStatusCommand(provider.check_ready);
  if (!command || !hasBinary) return { ready: false, auth_mode: null, execution_mode: null };
  const result = spawnSync(command, [], {
    shell: true,
    env,
    windowsHide: true,
    stdio: ["ignore", "ignore", "ignore"],
    timeout: STATUS_TIMEOUT_MS,
  });
  return result.status === 0
    ? { ready: true, auth_mode: "cli_login", execution_mode: "subprocess" }
    : { ready: false, auth_mode: null, execution_mode: null };
}

function runtimeInstallVerified(provider, env, hasBinary) {
  const verified = verifyRuntimeInstall(provider, env, hasBinary);
  return verified === null ? hasBinary : verified;
}

function verifyRuntimeInstall(provider, env, hasBinary) {
  const command = platformVerifyCommand(provider.install);
  if (!command) return null;
  if (!hasBinary && !provider.install?.api_only) return false;
  const result = spawnSync(command, [], {
    shell: true,
    env,
    windowsHide: true,
    stdio: ["ignore", "ignore", "ignore"],
    timeout: STATUS_TIMEOUT_MS,
  });
  return result.status === 0;
}

function checkCredsReadiness(provider) {
  const check = provider.check_ready || {};
  if (check.creds_file) {
    try {
      const credsPath = expandHome(check.creds_file);
      if (fs.existsSync(credsPath)) {
        const stat = fs.statSync(credsPath);
        if (stat.isDirectory() ? fs.readdirSync(credsPath).length > 0 : stat.size > 0) {
          return { ready: true, auth_mode: "cli_login", execution_mode: "subprocess" };
        }
      }
    } catch {}
  }
  if (check.keychain_service && process.platform === "darwin") {
    const result = spawnSync("security", ["find-generic-password", "-s", check.keychain_service, "-w"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"], timeout: STATUS_TIMEOUT_MS });
    if (result.status === 0 && textValue(result.stdout)) return { ready: true, auth_mode: "cli_login", execution_mode: "subprocess" };
  }
  return { ready: false, auth_mode: null, execution_mode: null };
}

function requiredRuntimeProvider(runtimeRef) {
  const found = getRuntimeProvider(runtimeRef);
  if (!found) throw new Error(`Unknown runtime provider: ${textValue(runtimeRef) || "<empty>"}`);
  return found;
}

function assertExpectedProvider(provider, expectedProvider) {
  const expected = textValue(expectedProvider);
  if (expected && expected !== provider.id && expected !== provider.provider) throw new Error(`Local agent is configured for runtime provider ${expected}, not ${provider.id}.`);
}

function packageSpec(defaultPackageRef, packageRef, version) {
  const ref = textValue(packageRef) || defaultPackageRef;
  assertPackageRef(ref);
  const requestedVersion = textValue(version);
  if (!requestedVersion) return ref;
  assertPackageVersion(requestedVersion);
  if (hasVersionSuffix(ref)) throw new Error("package_ref must not include a version when version is set.");
  return `${ref}@${requestedVersion}`;
}

function uninstallPackageRef(defaultPackageRef, packageRef) {
  const ref = textValue(packageRef) || defaultPackageRef;
  assertPackageRef(ref);
  if (hasVersionSuffix(ref)) throw new Error("runtime uninstall package_ref must be a package name without a version.");
  return ref;
}

function assertPackageRef(value) {
  if (!/^(?:@[a-z0-9._-]+\/)?[a-z0-9._-]+(?:@[a-z0-9._+~-]+)?$/i.test(value)) throw new Error(`Invalid npm package_ref: ${value}`);
}

function assertPackageVersion(value) {
  if (!/^[a-z0-9][a-z0-9._+~-]{0,127}$/i.test(value)) throw new Error(`Invalid runtime version: ${value}`);
}

function hasVersionSuffix(value) {
  const slash = value.indexOf("/");
  const lastAt = value.lastIndexOf("@");
  return value.startsWith("@") ? lastAt > slash : lastAt > 0;
}

function failedRuntimeResult(result, message) {
  return { ...result, exit_code: 1, stderr: appendLimited(result.stderr, `${message}\n`) };
}

function apiOnlyRuntimeResult(provider, message, installed) {
  return { exit_code: 0, stdout: `${message}\n`, stderr: "", runtime_ref: provider.id, package_ref: provider.package_ref || "", binary_path: null, installed_version: null, installed, changed: false };
}

function installCommandForPlatform(provider) {
  return platformCommand(provider.install || {});
}

function uninstallCommandForPlatform(provider) {
  return platformCommand(provider.uninstall || {});
}

function platformStatusCommand(checkReady) {
  if (!checkReady) return "";
  if (process.platform === "win32") return textValue(checkReady.status_command_win || checkReady.verify_win || checkReady.status_command || checkReady.alt_check);
  return textValue(checkReady.status_command || checkReady.alt_check);
}

function platformVerifyCommand(install) {
  if (!install) return "";
  if (process.platform === "win32") return textValue(install.verify_win || install.verify);
  return textValue(install.verify);
}

function platformCommand(record) {
  const platform = process.platform === "darwin" ? "macos" : process.platform === "win32" ? "windows" : "linux";
  return textValue(record[platform]);
}

function workingDirectory(value) {
  return textValue(value) || process.cwd();
}

function envKeyValue(value) {
  const key = textValue(value).toUpperCase();
  if (!/^[A-Z_][A-Z0-9_]{0,127}$/.test(key)) throw new Error(`Invalid environment variable name: ${value}`);
  return key;
}

function expandHome(value) {
  const text = textValue(value);
  if (text === "~") return os.homedir();
  if (text.startsWith("~/")) return path.join(os.homedir(), text.slice(2));
  return text;
}

function runtimeVersionMatches(output, requestedVersion) {
  const requested = textValue(requestedVersion);
  if (!requested) return false;
  return new Set(textValue(output).split(/[^a-z0-9._+~-]+/i).filter(Boolean)).has(requested);
}

function detectedVersion(output) {
  const text = textValue(output);
  if (!text) return null;
  const match = /\b\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?\b/.exec(text);
  if (match) return match[0];
  return text.split(/\r?\n/).map((line) => line.trim()).filter(Boolean)[0] ?? null;
}

function compareVersions(left, right) {
  const leftParts = versionParts(left);
  const rightParts = versionParts(right);
  for (let index = 0; index < Math.max(leftParts.length, rightParts.length); index += 1) {
    const leftPart = leftParts[index] ?? 0;
    const rightPart = rightParts[index] ?? 0;
    if (leftPart > rightPart) return 1;
    if (leftPart < rightPart) return -1;
  }
  return 0;
}

function versionParts(value) {
  return textValue(value).split(".").map((part) => Number.parseInt(part, 10)).map((part) => Number.isFinite(part) ? part : 0);
}

function appendLimited(current, next) {
  const value = `${current}${next}`;
  if (Buffer.byteLength(value, "utf8") <= MAX_CAPTURE_BYTES) return value;
  return value.slice(-MAX_CAPTURE_BYTES);
}

function textValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

module.exports = { listRuntimeProviders, getRuntimeProvider, discoverRuntimeProviders, runtimeProviderStatus, runtimeProviderReadiness, runtimeEffectiveEnv, runtimeEnvForState, setRuntimeEnv, installRuntimeProvider, uninstallRuntimeProvider, whichBinary };
