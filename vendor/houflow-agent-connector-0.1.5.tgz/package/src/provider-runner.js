const fs = require("node:fs");
const http = require("node:http");
const https = require("node:https");
const path = require("node:path");
const { spawn } = require("node:child_process");
const { activeProcessSnapshot, stopActiveProcesses, trackProcess } = require("./process-manager.js");
const { getRuntimeProvider, runtimeEffectiveEnv, runtimeProviderStatus, whichBinary } = require("./runtime-registry.js");
const { listInstalledSkills } = require("./skill-installer.js");

const MAX_CAPTURE_BYTES = 256 * 1024;

function providerRunnerAvailable(runtimeProvider) {
  return Boolean(getRuntimeProvider(runtimeProvider)?.runner);
}

async function runProviderAction(localAgent, action, command, env = process.env, onLine = () => {}, store = null) {
  if (action === "agent_status") return providerStatus(localAgent, env, onLine, store);
  if (action === "agent_stop") return providerStop(localAgent, onLine);
  if (action === "agent_restart") return providerRestart(localAgent, store, onLine);
  if (action === "dispatch" || action === "workspace_message") return providerDispatch(localAgent, action, command, env, onLine, store);
  throw new Error(`Unsupported provider runner action: ${action}`);
}

function providerStatus(localAgent, env, onLine, store) {
  const status = runtimeProviderStatus(requiredRuntimeProvider(localAgent).id, env, store?.loadState ? store.loadState() : null);
  const active = activeProcessSnapshot(localAgent.local_agent_ref);
  const installText = status.install?.api_only
    ? (status.ready ? "configured" : "not configured")
    : (status.installed ? `installed at ${status.binary_path}` : "not installed");
  const output = {
    ...status,
    runtime_runner: true,
    active_process_count: active.active_process_count,
    pids: active.pids,
  };
  onLine(`${status.label}: ${installText}`);
  onLine(`Active local process count: ${active.active_process_count}`);
  return {
    exit_code: 0,
    stdout: `${JSON.stringify(output, null, 2)}\n`,
    stderr: "",
    ...output,
  };
}

async function providerStop(localAgent, onLine) {
  const result = await stopActiveProcesses(localAgent.local_agent_ref);
  onLine(`Stopped ${result.stopped} active process(es).`);
  return {
    exit_code: 0,
    stdout: `${JSON.stringify(result, null, 2)}\n`,
    stderr: "",
    ...result,
  };
}

async function providerRestart(localAgent, store, onLine) {
  const stopped = await stopActiveProcesses(localAgent.local_agent_ref);
  const cleared = clearProviderSessions(store, localAgent.local_agent_ref);
  onLine(`Stopped ${stopped.stopped} active process(es).`);
  onLine(`Cleared ${cleared.removed_paths} provider session path(s).`);
  return {
    exit_code: 0,
    stdout: `${JSON.stringify({ ...stopped, ...cleared }, null, 2)}\n`,
    stderr: "",
    ...stopped,
    ...cleared,
  };
}

async function providerDispatch(localAgent, action, command, env, onLine, store) {
  const provider = requiredRuntimeProvider(localAgent);
  if (!provider.runner) throw new Error(`Runtime provider ${provider.id} does not define a connector runner.`);
  switch (provider.runner.kind) {
    case "cli-jsonl":
      return runCliJsonl(localAgent, provider, action, command, env, onLine, store);
    case "stream-json-cli":
      return runStreamJsonCli(localAgent, provider, action, command, env, onLine, store);
    case "opencode-json":
      return runOpenCodeJson(localAgent, provider, action, command, env, onLine, store);
    case "openclaw-json":
      return runOpenClawJson(localAgent, provider, action, command, env, onLine, store);
    case "text-cli":
      return runTextCli(localAgent, provider, action, command, env, onLine, store);
    case "direct-openai-chat":
      return runDirectOpenAiChat(localAgent, provider, action, command, env, onLine, store);
    case "pi-json":
      return runPiJson(localAgent, provider, action, command, env, onLine, store);
    default:
      throw new Error(`Runtime provider ${provider.id} runner kind is unsupported: ${provider.runner.kind}`);
  }
}

async function runCliJsonl(localAgent, provider, action, command, env, onLine, store) {
  const binaryName = provider.runner.command || provider.binary;
  const binaryPath = whichBinary(binaryName, env) || whichBinary(provider.binary, env);
  const runtimeEnv = runtimeEffectiveEnv(provider.id, store?.loadState ? store.loadState() : null, env);
  if (provider.id === "codex" && shouldUseCodexDirect(binaryPath, runtimeEnv)) {
    return runCodexDirect(localAgent, action, command, runtimeEnv, onLine);
  }
  if (!binaryPath) throw new Error(`Runtime binary ${binaryName} was not found on PATH.`);
  const session = providerSession(store, localAgent.local_agent_ref, sessionKey(action, command));
  const args = cliJsonlArgs(provider, action, command, session, runtimeEnv);
  const message = runnerPrompt(localAgent, provider, action, command, commandMessage(action, command.input));
  const responseTexts = [];
  const result = await runJsonlProcess({
    localAgentRef: localAgent.local_agent_ref,
    command: binaryPath,
    args,
    stdin: message,
    cwd: localAgent.working_directory || process.cwd(),
    env: {
      ...runtimeEnv,
      HOUFLOW_AGENT_CONNECTOR_ACTION: action,
      HOUFLOW_AGENT_CONNECTOR_COMMAND_ID: command.id,
      HOUFLOW_CONNECTED_AGENT_ID: command.connected_agent_id,
      HOUFLOW_LOCAL_AGENT_REF: command.local_agent_ref,
      HOUFLOW_AGENT_CONNECTOR_INPUT: JSON.stringify(commandInputForEnvironment(command.input)),
    },
    onLine,
    commandId: command.id,
    onJsonLine: (event) => {
      const sessionId = cliJsonlSessionId(event);
      if (provider.runner.session && sessionId) session.save(sessionId);
      const outputText = cliJsonlOutputText(provider, event);
      if (outputText) responseTexts.push(outputText);
      const summary = cliJsonlEventSummary(provider, event);
      if (summary) onLine(summary);
    },
  });
  const stdout = responseTexts.join("\n").trim();
  return stdout ? { ...result, stdout: `${stdout}\n` } : result;
}

async function runCodexDirect(localAgent, action, command, env, onLine) {
  const message = runnerPrompt(localAgent, { id: "codex" }, action, command, commandMessage(action, command.input));
  const responseText = await callOpenAiChatCompletions({
    baseUrl: requiredText(env.OPENAI_BASE_URL, "OPENAI_BASE_URL"),
    apiKey: requiredText(env.OPENAI_API_KEY, "OPENAI_API_KEY"),
    model: textValue(env.CODEX_MODEL || env.OPENCLAW_MODEL || command.input?.model || command.input?.metadata?.model) || "gpt-4o",
    message,
    onLine,
  });
  return {
    exit_code: 0,
    stdout: responseText ? `${responseText}\n` : "",
    stderr: "",
  };
}

function shouldUseCodexDirect(binaryPath, env) {
  const apiKey = textValue(env.OPENAI_API_KEY);
  const baseUrl = textValue(env.OPENAI_BASE_URL).toLowerCase();
  if (!apiKey || !baseUrl) return false;
  if (!binaryPath) return true;
  return !baseUrl.includes("api.openai.com");
}

async function runStreamJsonCli(localAgent, provider, action, command, env, onLine, store) {
  const binaryPath = providerBinaryPath(provider, env);
  const runtimeEnv = runtimeEffectiveEnv(provider.id, store?.loadState ? store.loadState() : null, env);
  const session = providerSession(store, localAgent.local_agent_ref, sessionKey(action, command));
  const message = runnerPrompt(localAgent, provider, action, command, commandMessage(action, command.input));
  const args = streamJsonCliArgs(provider, localAgent, command, session, runtimeEnv, message);
  const responseTexts = [];
  const result = await runJsonlProcess({
    localAgentRef: localAgent.local_agent_ref,
    command: binaryPath,
    args,
    cwd: textValue(command.input?.working_directory || command.input?.cwd || localAgent.working_directory) || process.cwd(),
    env: runnerEnv(runtimeEnv, action, command),
    onLine,
    commandId: command.id,
    onJsonLine: (event) => {
      const sessionId = streamJsonSessionId(event);
      if (sessionId) session.save(sessionId);
      const outputText = streamJsonOutputText(provider, event);
      if (outputText) responseTexts.push(outputText);
      const summary = streamJsonEventSummary(provider, event);
      if (summary) onLine(summary);
    },
  });
  const stdout = joinedOutput(provider, responseTexts);
  return stdout ? { ...result, stdout: `${stdout}\n` } : result;
}

async function runDirectOpenAiChat(localAgent, provider, action, command, env, onLine, store) {
  const runtimeEnv = runtimeEffectiveEnv(provider.id, store?.loadState ? store.loadState() : null, env);
  const message = runnerPrompt(localAgent, provider, action, command, commandMessage(action, command.input));
  const responseText = await callOpenAiChatCompletions({
    baseUrl: directRunnerBaseUrl(provider, runtimeEnv),
    apiKey: directRunnerApiKey(provider, runtimeEnv),
    model: directRunnerModel(provider, runtimeEnv, command),
    message,
    onLine,
  });
  return { exit_code: 0, stdout: responseText ? `${responseText}\n` : "", stderr: "" };
}

async function runOpenCodeJson(localAgent, provider, action, command, env, onLine, store) {
  const binaryPath = providerBinaryPath(provider, env);
  const runtimeEnv = runtimeEffectiveEnv(provider.id, store?.loadState ? store.loadState() : null, env);
  const session = providerSession(store, localAgent.local_agent_ref, sessionKey(action, command));
  const agentDir = providerAgentDir(store, localAgent.local_agent_ref, provider.id);
  const args = ["run", "--format", "json", "--dir", agentDir];
  if (session.id) args.push("--session", session.id);
  const message = runnerPrompt(localAgent, provider, action, command, commandMessage(action, command.input));
  const result = await runCapturedProcess({
    localAgentRef: localAgent.local_agent_ref,
    command: binaryPath,
    args,
    stdin: message,
    cwd: agentDir,
    env: runnerEnv(runtimeEnv, action, command),
    onLine,
    commandId: command.id,
  });
  const events = splitJsonObjects(result.stdout);
  const sessionId = lastValue(events, opencodeSessionId);
  if (sessionId) session.save(sessionId);
  const stdout = opencodeOutputText(result.stdout, events);
  if (stdout) {
    for (const line of stdout.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).slice(0, 20)) onLine(line.slice(0, 1000));
    return { ...result, stdout: `${stdout}\n` };
  }
  return result;
}

async function runOpenClawJson(localAgent, provider, action, command, env, onLine, store) {
  const binaryPath = providerBinaryPath(provider, env);
  const runtimeEnv = runtimeEffectiveEnv(provider.id, store?.loadState ? store.loadState() : null, env);
  const message = runnerPrompt(localAgent, provider, action, command, commandMessage(action, command.input));
  const session = providerSession(store, localAgent.local_agent_ref, sessionKey(action, command));
  const openclawSessionId = session.id || `houflow-${safeSegment(command.connected_agent_id || localAgent.local_agent_ref)}-${safeSegment(command.input?.channel_ref || "dispatch")}`;
  const args = ["--log-level", "trace", "agent", "--local", "--agent", textValue(command.input?.agent_id || command.input?.metadata?.agent_id) || "main", "--session-id", openclawSessionId, "--message", message, "--json"];
  const result = await runCapturedProcess({
    localAgentRef: localAgent.local_agent_ref,
    command: binaryPath,
    args,
    cwd: localAgent.working_directory || process.cwd(),
    env: runnerEnv(runtimeEnv, action, command),
    onLine,
    commandId: command.id,
    reportStderr: false,
  });
  if (result.exit_code === 0) session.save(openclawSessionId);
  const stdout = openclawOutputText(`${result.stdout}\n${result.stderr}`);
  if (stdout) {
    for (const line of stdout.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).slice(0, 20)) onLine(line.slice(0, 1000));
    return { ...result, stdout: `${stdout}\n` };
  }
  return result;
}

async function runTextCli(localAgent, provider, action, command, env, onLine, store) {
  const binaryPath = providerBinaryPath(provider, env);
  const runtimeEnv = runtimeEffectiveEnv(provider.id, store?.loadState ? store.loadState() : null, env);
  const session = providerSession(store, localAgent.local_agent_ref, sessionKey(action, command));
  const message = runnerPrompt(localAgent, provider, action, command, commandMessage(action, command.input));
  const args = textCliArgs(provider, message, session);
  const result = await runCapturedProcess({
    localAgentRef: localAgent.local_agent_ref,
    command: binaryPath,
    args,
    cwd: localAgent.working_directory || process.cwd(),
    env: runnerEnv(runtimeEnv, action, command),
    onLine,
    commandId: command.id,
  });
  const parsed = textCliOutput(provider, result.stdout);
  if (parsed.sessionId) session.save(parsed.sessionId);
  if (parsed.text) {
    for (const line of parsed.text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).slice(0, 20)) onLine(line.slice(0, 1000));
    return { ...result, stdout: `${parsed.text}\n` };
  }
  return result;
}

function runnerPrompt(localAgent, provider, action, command, message) {
  const skills = installedSkillsSection(localAgent, provider);
  if (!skills) return message;
  return [
    skills,
    "---",
    `Agent Hub action: ${action}`,
    `Connected agent: ${command.connected_agent_id || "local-preview"}`,
    `Local agent: ${localAgent.local_agent_ref}`,
    "User request:",
    message,
  ].join("\n\n");
}

function installedSkillsSection(localAgent, provider) {
  if (!textValue(localAgent.skills_directory)) return "";
  const skills = listInstalledSkills(localAgent.skills_directory);
  if (skills.length === 0) return "";
  const lines = skills.map((skill) => `- ${skill.id}: read ${skill.skill_md}`);
  return [
    "Installed Agent Hub skills are available on this machine.",
    `${provider.label || provider.id} should use a matching skill by reading its SKILL.md and following it.`,
    ...lines,
  ].join("\n");
}

function cliJsonlArgs(provider, action, command, session, env) {
  const baseArgs = (provider.runner.args || []).map((arg) => String(arg));
  const args = [...baseArgs];
  if (provider.id === "codex") {
    const messageArgIndex = args.indexOf("-");
    const promptArg = messageArgIndex >= 0 ? args.splice(messageArgIndex, 1)[0] : "-";
    const model = textValue(command.input?.model || command.input?.metadata?.model || env.CODEX_MODEL);
    if (model && !args.includes("-m") && !args.includes("--model")) args.push("-m", model);
    const cwd = textValue(command.input?.working_directory || command.input?.cwd);
    if (cwd && !args.includes("-C") && !args.includes("--cd")) args.push("-C", cwd);
    if (provider.runner.session && session.id) {
      return ["exec", "resume", session.id, ...args.filter((arg) => arg !== "exec"), promptArg];
    }
    args.push(promptArg);
  }
  return args;
}

function providerBinaryPath(provider, env) {
  const binaryName = provider.runner.command || provider.binary;
  const binaryPath = whichBinary(binaryName, env) || whichBinary(provider.binary, env) || (provider.binary_aliases || []).map((binary) => whichBinary(binary, env)).find(Boolean);
  if (!binaryPath) throw new Error(`Runtime binary ${binaryName} was not found on PATH.`);
  return binaryPath;
}

function runnerEnv(runtimeEnv, action, command) {
  return {
    ...runtimeEnv,
    HOUFLOW_AGENT_CONNECTOR_ACTION: action,
    HOUFLOW_AGENT_CONNECTOR_COMMAND_ID: command.id,
    HOUFLOW_CONNECTED_AGENT_ID: command.connected_agent_id,
    HOUFLOW_LOCAL_AGENT_REF: command.local_agent_ref,
    HOUFLOW_AGENT_CONNECTOR_INPUT: JSON.stringify(commandInputForEnvironment(command.input)),
  };
}

function streamJsonCliArgs(provider, localAgent, command, session, env, message) {
  const args = templateArgs(provider.runner.args || [], {
    prompt: message,
    message,
    agentHome: textValue(localAgent.working_directory) || process.cwd(),
  });
  const model = textValue(command.input?.model || command.input?.metadata?.model || env[provider.runner.model_env]);
  if (model && provider.runner.model_flag && !args.includes(provider.runner.model_flag)) args.push(provider.runner.model_flag, model);
  const workspace = textValue(command.input?.working_directory || command.input?.cwd || localAgent.working_directory);
  if (workspace && provider.runner.workspace_flag && !args.includes(provider.runner.workspace_flag)) args.push(provider.runner.workspace_flag, workspace);
  if (session.id && provider.runner.session_flag) args.push(provider.runner.session_flag, session.id);
  return args;
}

function textCliArgs(provider, message, session) {
  const args = templateArgs(provider.runner.args || [], { prompt: message, message });
  if (session.id && provider.runner.session_flag) args.push(provider.runner.session_flag, session.id);
  return args;
}

function templateArgs(args, values) {
  return args.map((arg) => String(arg).replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => textValue(values[key]) || ""));
}

function directRunnerApiKey(provider, env) {
  const key = firstEnvValue(env, provider.runner.api_key_env || []);
  return requiredText(key, `${provider.id} API key`);
}

function directRunnerBaseUrl(provider, env) {
  return firstEnvValue(env, provider.runner.base_url_env || []) || requiredText(provider.runner.default_base_url, `${provider.id} base URL`);
}

function directRunnerModel(provider, env, command) {
  return textValue(command.input?.model || command.input?.metadata?.model || firstEnvValue(env, provider.runner.model_env || [])) || requiredText(provider.runner.default_model, `${provider.id} model`);
}

function firstEnvValue(env, keys) {
  for (const key of Array.isArray(keys) ? keys : [keys]) {
    const value = textValue(env[key]);
    if (value) return value;
  }
  return "";
}

async function runCapturedProcess(options) {
  const prepared = prepareSpawn(options.command, options.args);
  const child = trackProcess(options.localAgentRef, spawn(prepared.command, prepared.args, {
    cwd: options.cwd,
    env: options.env,
    shell: false,
    detached: process.platform !== "win32",
    windowsHide: true,
    stdio: [options.stdin === undefined ? "ignore" : "pipe", "pipe", "pipe"],
  }), options.commandId);
  if (options.stdin !== undefined) child.stdin.end(`${options.stdin}\n`);
  let stdout = "";
  let stderr = "";
  child.stdout.on("data", (chunk) => { stdout = appendLimited(stdout, String(chunk)); });
  child.stderr.on("data", (chunk) => {
    const text = String(chunk);
    stderr = appendLimited(stderr, text);
    if (options.reportStderr === false) return;
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean).slice(0, 20)) options.onLine(line.slice(0, 1000));
  });
  const exitCode = await new Promise((resolve) => {
    child.on("error", () => resolve(127));
    child.on("close", (code) => resolve(Number.isInteger(code) ? code : 1));
  });
  return { exit_code: exitCode, stdout, stderr };
}

function providerAgentDir(store, localAgentRef, providerId) {
  const root = store ? store.configDir : path.join(process.cwd(), ".houflow-provider-runtimes");
  const dir = path.join(root, "provider-agents", safeSegment(localAgentRef), safeSegment(providerId));
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  return dir;
}

async function runPiJson(localAgent, provider, action, command, env, onLine, store) {
  const runtimeProvider = requiredCommandRuntimeProvider(command.input?.runtime_provider);
  const binaryPath = whichBinary(provider.binary, env);
  if (!binaryPath) throw new Error(`Runtime binary ${provider.binary} was not found on PATH.`);
  const piProvider = materializePiRuntimeProvider(store, localAgent, command, runtimeProvider);
  const message = commandMessage(action, command.input);
  const session = providerSession(store, localAgent.local_agent_ref, sessionKey(action, command), action === "agent_restart");
  const args = ["--provider", piProvider.providerId, "--model", runtimeProvider.provider_model_id, "--mode", "json", "--session-dir", session.dir];
  if (session.id) args.push("--session", session.id);
  args.push(message);
  const runtimeProviderLogValue = JSON.stringify(runtimeProviderForEnvironment(runtimeProvider));
  return runJsonlProcess({
    localAgentRef: localAgent.local_agent_ref,
    command: binaryPath,
    args,
    cwd: localAgent.working_directory || process.cwd(),
    env: {
      ...env,
      HOUFLOW_AGENT_CONNECTOR_ACTION: action,
      HOUFLOW_AGENT_CONNECTOR_COMMAND_ID: command.id,
      HOUFLOW_CONNECTED_AGENT_ID: command.connected_agent_id,
      HOUFLOW_LOCAL_AGENT_REF: command.local_agent_ref,
      HOUFLOW_AGENT_CONNECTOR_INPUT: JSON.stringify(commandInputForEnvironment(command.input)),
      HOUFLOW_AGENT_RUNTIME_PROVIDER: runtimeProviderLogValue,
      HOUFLOW_MODEL_GATEWAY_BASE_URL: runtimeProvider.base_url,
      HOUFLOW_MODEL_GATEWAY_MODEL: runtimeProvider.provider_model_id,
      HOUFLOW_MODEL_GATEWAY_API_KEY: runtimeProvider.api_key_value,
      PI_CODING_AGENT_DIR: piProvider.agentDir,
      PI_CODING_AGENT_SESSION_DIR: session.dir,
    },
    onLine,
    commandId: command.id,
    onJsonLine: (event) => {
      if (event?.type === "session" && typeof event.id === "string") session.save(event.id);
      const summary = piEventSummary(event);
      if (summary) onLine(summary);
    },
  });
}

function materializePiRuntimeProvider(store, localAgent, command, runtimeProvider) {
  const agentDir = piAgentDir(store, localAgent.local_agent_ref, command.id);
  fs.mkdirSync(agentDir, { recursive: true, mode: 0o700 });
  const providerId = `houflow-${safeSegment(runtimeProvider.id)}`;
  const modelsJson = {
    providers: {
      [providerId]: {
        baseUrl: runtimeProvider.base_url,
        api: runtimeProvider.wire_api,
        apiKey: "$HOUFLOW_MODEL_GATEWAY_API_KEY",
        authHeader: true,
        models: [
          {
            id: runtimeProvider.provider_model_id,
            name: runtimeProvider.model || runtimeProvider.provider_model_id,
          },
        ],
      },
    },
  };
  fs.writeFileSync(path.join(agentDir, "models.json"), `${JSON.stringify(modelsJson, null, 2)}\n`, { mode: 0o600 });
  return { providerId, agentDir };
}

function piAgentDir(store, localAgentRef, commandId) {
  const root = store ? store.configDir : path.join(process.cwd(), ".houflow-provider-runtimes");
  return path.join(root, "runtime-providers", safeSegment(localAgentRef), safeSegment(commandId), "pi-agent");
}

function requiredCommandRuntimeProvider(value) {
  const provider = value && typeof value === "object" && !Array.isArray(value) ? value : null;
  if (!provider) throw new Error("runtime_provider is required for runtime runner dispatch.");
  return {
    id: requiredText(provider.id, "runtime_provider.id"),
    name: requiredText(provider.name, "runtime_provider.name"),
    type: requiredText(provider.type, "runtime_provider.type"),
    base_url: requiredText(provider.base_url, "runtime_provider.base_url"),
    model: requiredText(provider.model, "runtime_provider.model"),
    canonical_model_id: requiredText(provider.canonical_model_id, "runtime_provider.canonical_model_id"),
    provider_model_id: requiredText(provider.provider_model_id, "runtime_provider.provider_model_id"),
    api_key_value: requiredText(provider.api_key_value, "runtime_provider.api_key_value"),
    wire_api: requiredWireApi(provider.wire_api),
    gateway_attribution_ref: optionalText(provider.gateway_attribution_ref),
    entitlement_ref: optionalText(provider.entitlement_ref),
    quota_ref: optionalText(provider.quota_ref),
  };
}

function requiredWireApi(value) {
  const api = requiredText(value, "runtime_provider.wire_api");
  if (api === "openai-responses" || api === "openai-completions" || api === "anthropic-messages" || api === "google-generative-ai") return api;
  throw new Error(`runtime_provider.wire_api is unsupported: ${api}`);
}

function runtimeProviderForEnvironment(provider) {
  const { api_key_value: _apiKeyValue, ...view } = provider;
  return view;
}

function commandInputForEnvironment(input) {
  if (!input || typeof input !== "object" || Array.isArray(input)) return {};
  const runtimeProvider = input.runtime_provider && typeof input.runtime_provider === "object" && !Array.isArray(input.runtime_provider)
    ? runtimeProviderForEnvironment(input.runtime_provider)
    : undefined;
  return {
    ...input,
    ...(runtimeProvider ? { runtime_provider: runtimeProvider } : {}),
  };
}

async function runJsonlProcess(options) {
  const prepared = prepareSpawn(options.command, options.args);
  const child = trackProcess(options.localAgentRef, spawn(prepared.command, prepared.args, {
    cwd: options.cwd,
    env: options.env,
    shell: false,
    detached: process.platform !== "win32",
    windowsHide: true,
    stdio: [options.stdin === undefined ? "ignore" : "pipe", "pipe", "pipe"],
  }), options.commandId);
  if (options.stdin !== undefined) child.stdin.end(`${options.stdin}\n`);
  let stdout = "";
  let stderr = "";
  let lineBuffer = "";
  child.stdout.on("data", (chunk) => {
    const text = String(chunk);
    stdout = appendLimited(stdout, text);
    lineBuffer += text;
    const lines = lineBuffer.split(/\n/);
    lineBuffer = lines.pop() ?? "";
    for (const line of lines) handleJsonl(line, options.onJsonLine);
  });
  child.stderr.on("data", (chunk) => {
    const text = String(chunk);
    stderr = appendLimited(stderr, text);
    for (const line of text.split(/\r?\n/).map((item) => item.trim()).filter(Boolean)) options.onLine(line.slice(0, 1000));
  });
  const exitCode = await new Promise((resolve) => {
    child.on("error", () => resolve(127));
    child.on("close", (code) => resolve(Number.isInteger(code) ? code : 1));
  });
  if (lineBuffer.trim()) handleJsonl(lineBuffer, options.onJsonLine);
  return {
    exit_code: exitCode,
    stdout,
    stderr,
  };
}

function cliJsonlSessionId(event) {
  if (!event || typeof event !== "object") return "";
  if (event.type === "thread.started" && typeof event.thread_id === "string") return event.thread_id.trim();
  if (event.type === "session" && typeof event.id === "string") return event.id.trim();
  if (event.type === "session.started" && typeof event.session_id === "string") return event.session_id.trim();
  for (const key of ["session_id", "conversation_id"]) {
    if (typeof event[key] === "string" && event[key].trim()) return event[key].trim();
  }
  if ((event.type === "session" || event.type === "session.started") && typeof event.session?.id === "string") return event.session.id;
  return "";
}

function cliJsonlOutputText(provider, event) {
  if (provider.id === "codex") return codexOutputText(event);
  if (!event || typeof event !== "object") return "";
  return contentTextValue(event.output || event.message?.content || event.content || event.text);
}

function cliJsonlEventSummary(provider, event) {
  if (provider.id === "codex") return codexEventSummary(event);
  if (!event || typeof event !== "object") return "";
  if (event.type === "raw" && typeof event.text === "string") return event.text.slice(0, 1000);
  if (typeof event.message === "string") return event.message.slice(0, 1000);
  if (typeof event.text === "string") return event.text.slice(0, 1000);
  return "";
}

function streamJsonSessionId(event) {
  if (!event || typeof event !== "object") return "";
  const type = textValue(event.type);
  if (["init", "result", "system", "session", "session.started"].includes(type) && typeof event.session_id === "string") return event.session_id.trim();
  if (type === "session" && typeof event.id === "string") return event.id.trim();
  if ((type === "session" || type === "session.started") && typeof event.session?.id === "string") return event.session.id.trim();
  return "";
}

function streamJsonOutputText(provider, event) {
  if (!event || typeof event !== "object") return "";
  if (provider.id === "gemini") {
    if (event.type === "message" && event.role === "assistant") return contentTextRaw(event.content || event.message?.content || event.text);
    return "";
  }
  if (event.type === "assistant") return contentTextRaw(event.message?.content || event.content || event.text);
  if (event.type === "message" && event.role === "assistant") return contentTextRaw(event.content || event.message?.content || event.text);
  return "";
}

function streamJsonEventSummary(provider, event) {
  if (!event || typeof event !== "object") return "";
  if (event.type === "raw" && typeof event.text === "string") return event.text.slice(0, 1000);
  const text = streamJsonOutputText(provider, event);
  if (text.trim()) return text.trim().slice(0, 1000);
  if (event.type === "tool_use") return toolSummary(event.tool_name || event.name, event.parameters || event.input);
  if (event.type === "tool_call" && event.subtype === "started") return toolSummary(toolName(event.tool_call), toolDetail(event.tool_call));
  if (event.type === "result" && event.is_error) return `${provider.label || provider.id} error: ${contentTextValue(event.result || event.message || event.error).slice(0, 300)}`;
  if (event.type === "system" && typeof event.message === "string" && event.message.trim()) return event.message.trim().slice(0, 1000);
  return "";
}

function joinedOutput(provider, responseTexts) {
  if (provider.id === "gemini") return responseTexts.join("").trim();
  return responseTexts.map((item) => item.trim()).filter(Boolean).join("\n").trim();
}

function toolSummary(name, detail) {
  const tool = textValue(name) || "tool";
  const preview = typeof detail === "string" ? detail : toolDetail(detail);
  return preview ? `${tool} > ${preview}` : tool;
}

function toolName(toolCall) {
  if (!toolCall || typeof toolCall !== "object") return "tool";
  if (toolCall.function?.name) return toolCall.function.name;
  for (const key of Object.keys(toolCall)) {
    if (key.endsWith("ToolCall")) return key.replace(/ToolCall$/, "") || "tool";
  }
  return "tool";
}

function toolDetail(value) {
  if (!value || typeof value !== "object") return textValue(value);
  const input = value.input && typeof value.input === "object" ? value.input : value;
  return textValue(input.command || input.file_path || input.path || input.pattern || input.query || input.url || input.content)
    || JSON.stringify(input).slice(0, 150);
}

function splitJsonObjects(raw) {
  const objects = [];
  const text = String(raw || "").trim();
  let position = 0;
  while (position < text.length) {
    while (position < text.length && /\s/.test(text[position])) position += 1;
    if (text[position] !== "{") {
      position += 1;
      continue;
    }
    let depth = 0;
    let inString = false;
    let escaped = false;
    const start = position;
    let parsed = false;
    for (let index = position; index < text.length; index += 1) {
      const char = text[index];
      if (escaped) {
        escaped = false;
        continue;
      }
      if (char === "\\" && inString) {
        escaped = true;
        continue;
      }
      if (char === '"') {
        inString = !inString;
        continue;
      }
      if (inString) continue;
      if (char === "{") depth += 1;
      if (char === "}") depth -= 1;
      if (depth === 0) {
        try {
          const object = JSON.parse(text.slice(start, index + 1));
          if (object && typeof object === "object" && !Array.isArray(object)) objects.push(object);
        } catch {}
        position = index + 1;
        parsed = true;
        break;
      }
    }
    if (!parsed) break;
  }
  return objects;
}

function lastValue(items, mapper) {
  let value = "";
  for (const item of items) {
    const next = textValue(mapper(item));
    if (next) value = next;
  }
  return value;
}

function opencodeSessionId(event) {
  return textValue(event?.sessionID || event?.session?.id || event?.part?.sessionID);
}

function opencodeOutputText(raw, events) {
  if (!events.length) return textValue(raw);
  const texts = [];
  for (const event of events) {
    if (["step_start", "step_finish", "tool_use"].includes(event.type)) continue;
    const text = contentTextValue(event.part?.text || event.part?.content || event.item?.text || event.item?.content || event.text || event.content);
    if (text) texts.push(text);
  }
  return texts.length ? texts.join("\n").trim() : "";
}

function openclawOutputText(raw) {
  const json = payloadJsonObject(raw);
  if (json) {
    const texts = (json.payloads || []).map((payload) => contentTextValue(payload?.text || payload?.content || payload?.message)).filter(Boolean);
    if (texts.length > 0) return texts.join("\n\n").trim();
  }
  return String(raw || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.includes("embedded run") && !line.startsWith("{") && !/^trace|debug|info/i.test(line))
    .join("\n")
    .trim();
}

function payloadJsonObject(raw) {
  const text = String(raw || "");
  const direct = splitJsonObjects(text).find((object) => Array.isArray(object.payloads));
  if (direct) return direct;
  const payloadMatch = /\{\s*"payloads"/.exec(text);
  if (!payloadMatch) return null;
  const start = payloadMatch.index;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let index = start; index < text.length; index += 1) {
    const char = text[index];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char === "\\" && inString) {
      escaped = true;
      continue;
    }
    if (char === '"') {
      inString = !inString;
      continue;
    }
    if (inString) continue;
    if (char === "{") depth += 1;
    if (char === "}") depth -= 1;
    if (depth === 0) {
      try {
        const object = JSON.parse(text.slice(start, index + 1));
        return Array.isArray(object.payloads) ? object : null;
      } catch {
        return null;
      }
    }
  }
  return null;
}

function textCliOutput(provider, stdout) {
  let body = String(stdout || "");
  let sessionId = "";
  const pattern = textValue(provider.runner.session_regex);
  if (pattern) {
    const match = new RegExp(pattern).exec(body);
    if (match?.[1]) {
      sessionId = match[1];
      body = body.replace(match[0], "");
    }
  }
  const text = body
    .split(/\r?\n/)
    .filter((line) => {
      const stripped = line.trim();
      return stripped && !/Resumed session/i.test(stripped);
    })
    .join("\n")
    .trim();
  return { text, sessionId };
}

function codexEventSummary(event) {
  if (!event || typeof event !== "object") return "";
  if (event.type === "thread.started" && typeof event.thread_id === "string") return `Codex session ${event.thread_id.slice(0, 12)} started.`;
  if (event.type === "turn.started" || event.type === "turn_start") return "Codex turn started.";
  if (event.type === "turn.completed" || event.type === "turn_end") return "Codex turn completed.";
  if (event.type === "turn.failed") return `Codex turn failed: ${errorMessage(event.error) || "unknown error"}`;
  if (event.type === "item.completed") return codexItemSummary(event.item);
  if (event.type === "raw" && typeof event.text === "string") return event.text.slice(0, 1000);
  if (typeof event.text === "string" && event.text.trim()) return event.text.trim().slice(0, 1000);
  if (typeof event.message === "string" && event.message.trim()) return event.message.trim().slice(0, 1000);
  const contentText = contentTextValue(event.message?.content || event.content || event.delta || event.output);
  return contentText ? contentText.slice(0, 1000) : "";
}

function codexOutputText(event) {
  if (!event || typeof event !== "object") return "";
  if (event.type === "item.completed") {
    const item = event.item;
    if (item?.type === "agent_message") return contentTextValue(item.text || item.content || item.message);
    if (item?.type === "message") return contentTextValue(item.message?.content || item.content);
  }
  return contentTextValue(event.message?.content || event.output_text || event.final_response || "");
}

function codexItemSummary(item) {
  if (!item || typeof item !== "object") return "";
  if (item.type === "agent_message") return contentTextValue(item.text || item.content || item.message).slice(0, 1000);
  if (item.type === "message") return contentTextValue(item.message?.content || item.content).slice(0, 1000);
  if (item.type === "command_execution") {
    const command = textValue(item.command || item.cmd || item.name || "command").slice(0, 200);
    const exitCode = item.exit_code ?? item.exitCode;
    return `${command}${exitCode === undefined || exitCode === null ? "" : ` (exit ${exitCode})`}`;
  }
  if (item.type === "file_change") return `Edited ${textValue(item.filename || item.path || "file")}`;
  return contentTextValue(item.text || item.content || item.output).slice(0, 1000);
}

function contentTextValue(value) {
  if (typeof value === "string") return value.trim();
  if (Array.isArray(value)) {
    return value.map((item) => {
      if (typeof item === "string") return item;
      if (!item || typeof item !== "object") return "";
      return contentTextValue(item.text || item.output_text || item.content || item.message);
    }).filter(Boolean).join("\n").trim();
  }
  if (value && typeof value === "object") return contentTextValue(value.text || value.output_text || value.content || value.message);
  return "";
}

function contentTextRaw(value) {
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    return value.map((item) => {
      if (typeof item === "string") return item;
      if (!item || typeof item !== "object") return "";
      return contentTextRaw(item.text || item.output_text || item.content || item.message);
    }).filter(Boolean).join("\n");
  }
  if (value && typeof value === "object") return contentTextRaw(value.text || value.output_text || value.content || value.message);
  return "";
}

function errorMessage(value) {
  if (!value) return "";
  if (typeof value === "string") return value;
  if (typeof value === "object" && !Array.isArray(value)) return textValue(value.message) || JSON.stringify(value).slice(0, 300);
  return String(value);
}

function callOpenAiChatCompletions({ baseUrl, apiKey, model, message, onLine }) {
  const url = `${baseUrl.replace(/\/+$/, "")}/chat/completions`;
  const payload = JSON.stringify({
    model,
    messages: [{ role: "user", content: message }],
    stream: true,
  });
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const client = parsed.protocol === "https:" ? https : http;
    const request = client.request(parsed, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${apiKey}`,
        "content-length": Buffer.byteLength(payload),
      },
      timeout: 300000,
    }, (response) => {
      let fullText = "";
      let toolCallText = "";
      let body = "";
      let buffer = "";
      response.on("data", (chunk) => {
        const text = String(chunk);
        body = appendLimited(body, text);
        if (response.statusCode !== 200) return;
        buffer += text;
        const lines = buffer.split(/\n/);
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          const delta = openAiSseDelta(line);
          if (!delta) continue;
          if (delta.content) {
            fullText += delta.content;
            onLine(delta.content);
          }
          if (delta.toolCallText) toolCallText += delta.toolCallText;
        }
      });
      response.on("end", () => {
        if (response.statusCode !== 200) {
          reject(new Error(`LLM API returned ${response.statusCode}: ${body.slice(0, 300)}`));
          return;
        }
        const fallback = textFromToolCallText(toolCallText);
        resolve((fullText || fallback).trim());
      });
    });
    request.on("timeout", () => request.destroy(new Error("LLM API request timed out")));
    request.on("error", reject);
    request.write(payload);
    request.end();
  });
}

function openAiSseDelta(line) {
  const trimmed = line.trim();
  if (!trimmed || !trimmed.startsWith("data:")) return null;
  const data = trimmed.slice(5).trim();
  if (!data || data === "[DONE]") return null;
  try {
    const parsed = JSON.parse(data);
    const delta = parsed.choices?.[0]?.delta || {};
    const toolCallText = Array.isArray(delta.tool_calls)
      ? delta.tool_calls.map((toolCall) => toolCall?.function?.arguments || "").join("")
      : "";
    return { content: typeof delta.content === "string" ? delta.content : "", toolCallText };
  } catch {
    return null;
  }
}

function textFromToolCallText(value) {
  const text = textValue(value);
  if (!text) return "";
  try {
    const parsed = JSON.parse(text);
    return textValue(parsed.command || parsed.input || parsed.content || parsed.text) || text;
  } catch {
    return text;
  }
}

function handleJsonl(line, onJsonLine) {
  const text = line.trim();
  if (!text) return;
  try {
    onJsonLine(JSON.parse(text));
  } catch {
    onJsonLine({ type: "raw", text });
  }
}

function piEventSummary(event) {
  if (!event || typeof event !== "object") return "";
  if (event.type === "session") return `Pi session ${String(event.id || "").slice(0, 12)} started.`;
  if (event.type === "turn_start") return "Pi turn started.";
  if (event.type === "turn_end") return "Pi turn completed.";
  if (event.type === "agent_end") return "Pi agent completed.";
  if (event.type === "tool_execution_start") return `Tool started: ${String(event.toolName || "unknown")}`;
  if (event.type === "tool_execution_end") return `Tool finished: ${String(event.toolName || "unknown")}${event.isError ? " (error)" : ""}`;
  if (event.type === "message_update") {
    const delta = event.assistantMessageEvent?.delta;
    if (typeof delta === "string" && delta.trim()) return delta.trim().slice(0, 1000);
  }
  if (event.type === "raw" && typeof event.text === "string") return event.text.slice(0, 1000);
  return "";
}

function commandMessage(action, input) {
  if (action === "dispatch") return withAttachmentSection(requiredText(input?.message, "message"), input?.attachments);
  if (action === "workspace_message") {
    const channel = requiredText(input?.channel_ref, "channel_ref");
    return withAttachmentSection(`[channel:${channel}]\n${requiredText(input?.message, "message")}`, input?.attachments);
  }
  return JSON.stringify(input || {});
}

function withAttachmentSection(message, attachments) {
  const items = Array.isArray(attachments) ? attachments.filter((item) => item && typeof item === "object") : [];
  if (items.length === 0) return message;
  const lines = items.map((item, index) => {
    const name = textValue(item.filename || item.name) || textValue(item.file_id) || `attachment-${index + 1}`;
    const mediaType = textValue(item.media_type) || "application/octet-stream";
    const kind = textValue(item.kind) || "file";
    const fileId = textValue(item.file_id);
    const url = textValue(item.url);
    return `${index + 1}. ${name} [${kind}, ${mediaType}]${fileId ? ` file_id=${fileId}` : ""}${url ? ` url=${url}` : ""}`;
  });
  return [message, "Attachments:", ...lines].join("\n");
}

function sessionKey(action, command) {
  if (action === "workspace_message") return `workspace:${requiredText(command.input?.channel_ref, "channel_ref")}`;
  return `dispatch:${requiredText(command.connected_agent_id, "connected_agent_id")}`;
}

function providerSession(store, localAgentRef, key) {
  if (!store) return { dir: path.join(process.cwd(), ".houflow-provider-sessions"), id: "", save() {} };
  const dir = path.join(store.configDir, "provider-sessions", safeSegment(localAgentRef), safeSegment(key));
  const file = path.join(dir, "session.json");
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  let id = "";
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf8"));
    id = typeof parsed.id === "string" ? parsed.id : "";
  } catch {}
  return {
    dir,
    id,
    save(nextId) {
      const value = requiredText(nextId, "session id");
      fs.writeFileSync(file, `${JSON.stringify({ id: value, updated_at: new Date().toISOString() }, null, 2)}\n`, { mode: 0o600 });
    },
  };
}

function clearProviderSessions(store, localAgentRef) {
  if (!store) return { removed_paths: 0 };
  const dir = path.join(store.configDir, "provider-sessions", safeSegment(localAgentRef));
  let removed = 0;
  if (fs.existsSync(dir)) {
    fs.rmSync(dir, { recursive: true, force: true });
    removed = 1;
  }
  return { removed_paths: removed };
}

function requiredRuntimeProvider(localAgent) {
  const provider = getRuntimeProvider(localAgent.runtime_provider);
  if (!provider) throw new Error(`Local agent ${localAgent.local_agent_ref} does not have a valid runtime_provider.`);
  return provider;
}

function prepareSpawn(command, args) {
  if (process.platform !== "win32" || !/\.(cmd|bat)$/i.test(command)) return { command, args };
  return {
    command: process.env.COMSPEC || "cmd.exe",
    args: ["/d", "/s", "/c", [cmdQuote(command), ...args.map((arg) => cmdQuote(arg))].join(" ")],
  };
}

function cmdQuote(value) {
  const text = String(value);
  if (!text) return '""';
  if (!/[\s"&|<>^]/.test(text)) return text;
  return `"${text.replace(/"/g, '\\"')}"`;
}

function safeSegment(value) {
  const text = requiredText(value, "segment").replace(/[^a-z0-9._-]+/gi, "_");
  return text.slice(0, 120);
}

function requiredText(value, field) {
  const text = typeof value === "string" && value.trim() ? value.trim() : "";
  if (!text) throw new Error(`${field} is required`);
  return text;
}

function optionalText(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function textValue(value) {
  return typeof value === "string" && value.trim() ? value.trim() : "";
}

function appendLimited(current, next) {
  const value = `${current}${next}`;
  if (Buffer.byteLength(value, "utf8") <= MAX_CAPTURE_BYTES) return value;
  return value.slice(-MAX_CAPTURE_BYTES);
}

module.exports = { providerRunnerAvailable, runProviderAction };
