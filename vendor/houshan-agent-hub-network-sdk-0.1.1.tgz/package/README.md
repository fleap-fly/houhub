# Agent Hub Network SDK

`@houshan/agent-hub-network-sdk` is the independent TypeScript HTTP client for
Agent Hub deployments. It is separate from `@houshan/agent-hub-sdk`, which stays
contract-only and has no network transport.

Use this package from external tools, connectors, scripts and adopter services
that need to call an Agent Hub HTTP API. Do not use it inside a control service
to call itself.

```bash
npm install @houshan/agent-hub-network-sdk
```

```ts
import { AgentHubNetworkClient } from "@houshan/agent-hub-network-sdk";

const hub = new AgentHubNetworkClient({
  baseUrl: process.env.AGENT_HUB_CONTROL_BASE_URL!,
  apiKey: process.env.AGENT_HUB_API_KEY,
  workspaceId: process.env.AGENT_HUB_WORKSPACE_ID,
});

const agents = await hub.connectedAgents.list({ hosting: "external" });
console.log(agents.data.map((agent) => agent.name));
```

## Connected Agents

The SDK covers the connected-agent control surface exposed by Agent Hub:

- list/get/create/update/archive connected agents
- provision hub-hosted connected agents
- bind external connectors to reported local agents
- queue external commands and dispatches
- dispatch to hub-hosted connected agents
- launch native consoles when the runtime reports support
- list/cancel/delete connector commands

```ts
const created = await hub.connectedAgents.create({
  name: "Local Codex",
  provider: "codex",
  external_agent_ref: "codex://local/default",
  management_mode: "connected_non_managed",
});

await hub.connectedAgents.bindConnector(created.id, {
  connector_id: "cac_local",
  local_agent_ref: "codex:cli",
});

await hub.connectedAgents.dispatch(created.id, {
  message: "Inspect this repository",
  attachments: [{ kind: "file", name: "README.md", file_id: "file_readme" }],
});
```

## Connector Login

Browser login is the preferred local connector flow. The connector starts a
login request from the local host, opens `verification_uri_complete`, polls with
the device code, and stores the returned connector token after the user approves
the request in the Agent Hub console.

```ts
const session = await hub.connectors.startLogin({
  platform: "linux",
  arch: "x64",
  name: "Local development machine",
  host: { hostname: "devbox", os: "linux", arch: "x64" },
});

console.log(session.verification_uri_complete);

const result = await hub.connectors.pollLogin({
  device_code: session.device_code!,
  connector_version: session.connector_version,
  host: { hostname: "devbox", os: "linux", arch: "x64" },
  reported_agents: [
    {
      local_agent_ref: "codex:cli",
      provider: "codex",
      name: "OpenAI Codex CLI",
      status: "available",
      capabilities: { dispatch: true },
    },
  ],
});

if (result.connector?.connector_token) {
  console.log(result.connector.id, result.connector.connector_token);
}
```

## Scripted Enrollment

Scripted enrollment is available for managed deployment pipelines. Create an
enrollment with control-plane auth, install the signed connector package on the
target host, then claim the enrollment from that host.

```ts
const enrollment = await hub.connectors.createEnrollment({ name: "CI host" });
const target = enrollment.install_targets.find((item) => item.platform === "linux");
if (!target || !enrollment.token) throw new Error("missing install target");

const script = await hub.connectors.installScript(target.id, "sh");
const packageBytes = await hub.connectors.packageArtifact(target.package_ref.split("/").pop()!);

const connector = await hub.connectors.claim({
  enrollment_token: enrollment.token,
  install_target_id: target.id,
  platform: target.platform,
  package_ref: target.package_ref,
  package_sha256: target.package_sha256,
  package_signature_ref: target.package_signature_ref,
  package_signature_sha256: target.package_signature_sha256,
  package_signature_algorithm: target.package_signature_algorithm,
  connector_version: target.version,
  host: { hostname: "ci-host", os: "linux", arch: "x64" },
});

console.log(script.length, packageBytes.byteLength, connector.id);
```

## Command Loop

Connector-scoped methods use `X-Agent-Hub-Connector-Token` and do not require a
user API key. A connector normally sends heartbeat, polls one command, executes
it locally, and records command events.

```ts
await hub.connectors.heartbeat(connector.id, connector.connector_token!, {
  connector_version: "0.1.3",
  reported_agents: [
    {
      local_agent_ref: "codex:cli",
      provider: "codex",
      name: "OpenAI Codex CLI",
      status: "available",
      capabilities: { dispatch: true },
    },
  ],
});

const { command } = await hub.connectors.pollCommand(connector.id, connector.connector_token!);
if (command) {
  await hub.connectors.recordCommandEvent(connector.id, connector.connector_token!, command.id, {
    type: "started",
    message: "Running local command",
  });
}
```

## Auth

The client supports three auth shapes:

- `apiKey`: sends `X-Api-Key` for API clients.
- `sessionCookie` plus `csrfToken`: supports browser/BFF-style session calls.
- connector token arguments: connector-scoped methods send
  `X-Agent-Hub-Connector-Token` and set request auth to `none`.

`baseUrl` is required and deployment-specific. The SDK does not hard-code a
Houflow or hosted endpoint.
