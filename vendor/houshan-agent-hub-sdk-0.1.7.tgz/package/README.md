# Agent Hub TypeScript SDK

`@houshan/agent-hub-sdk` is the TypeScript framework contract package for Agent
Hub core. It exports canonical Agent Hub types, session event helpers and
harness/coordinator contracts.

It does not export an HTTP client, a control service, UI code, persistence
adapters, billing logic, product workflows or host-specific integration code.
Control planes implement the Agent Hub contracts directly; they do not use this
package to call themselves.

```bash
npm install @houshan/agent-hub-sdk
```

```ts
import {
  PRIMARY_SESSION_THREAD_ID,
  comparePendingEvents,
  type SessionEvent,
  type SessionPendingEvent,
} from "@houshan/agent-hub-sdk";

const event: SessionEvent = {
  id: "evt_1",
  type: "user.message",
  session_thread_id: PRIMARY_SESSION_THREAD_ID,
  content: [{ type: "text", text: "hello" }],
  processed_at: null,
  created_at: new Date().toISOString(),
};

const pending: SessionPendingEvent = {
  id: "pend_1",
  type: "session_pending_event",
  session_id: "ses_1",
  event_id: event.id,
  pending_seq: 1,
  enqueued_at: Date.now(),
  event,
  session_thread_id: PRIMARY_SESSION_THREAD_ID,
  status: "queued",
  promoted_run_id: null,
  promoted_at: null,
  cancelled_at: null,
  created_at: event.created_at,
  updated_at: event.created_at,
};

console.log([... [pending]].sort(comparePendingEvents));
```

Session creation accepts the Claude Managed Agents-style
`agent_with_overrides` reference without creating a second persisted agent:

```ts
import type { SessionCreateParams } from "@houshan/agent-hub-sdk";

const session: SessionCreateParams = {
  agent: {
    type: "agent_with_overrides",
    id: "agt_support",
    model: { id: "openai/gpt-test" },
    system: "Answer using the current support policy.",
    tools: [{ type: "custom", name: "search", description: "Search support docs" }],
  },
  environment_id: "env_runtime",
  resources: [{ type: "file", file_id: "file_issue", mount_path: "/workspace/issue.md" }],
};
```

`AgentTarget`, `AgentDispatchParams` and `AgentDispatchResult` define the shared
managed/hosted/external dispatch contract. They remain transport-neutral.

`AGENT_TEAM_DELEGATE_TOOL_NAME`, `AGENT_TEAM_DELEGATE_INPUT_SCHEMA`,
`AgentTeamDelegationContext` and `AgentTeamDelegateResult` define the single
supervisor-to-member delegation contract used by managed, hosted resident and
external connected supervisors. Runtime callback URLs, worker addresses and
transport credentials are not part of this core contract.

Use `@houshan/agent-hub-network-sdk`, a product BFF, service API client or
generated OpenAPI client outside this package when an application needs HTTP
transport.
